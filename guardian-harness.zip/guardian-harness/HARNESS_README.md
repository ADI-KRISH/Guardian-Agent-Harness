# Supply Chain Guardian: agent harness bundle

Self-contained copy of the full Guardian harness (code only: no .venv, no scan workspace, no secrets).

## Setup
    python -m venv .venv && .venv\Scripts\activate      (Python 3.11+)
    pip install -e .
    copy .env.example .env        (set GUARDIAN_API_KEY; model chain is configured in guardian/agents/llm.py and guardian/config.py)
    guardian --help               (CLI entry point: guardian.cli:main)
    run-demo.bat | run-live.bat | run-ui.bat

External scanners (Syft, OSV-Scanner, zizmor, actionlint, GuardDog) are fetched by setup-tools.ps1 into .tools/ (not bundled).

## Map
| Area | Where |
|---|---|
| Core contracts: finding schema, run context, module registry | guardian/core/ + schemas/ |
| Module plug-ins (analysis, detectors, docker checks, history, remediation, report, validation, stretch) | guardian/modules/ + modules.yaml |
| LLM agents: lead, investigator, verifier, fixer, validator, suggest, vuln, change, backdoor, discovery, CI container | guardian/agents/ |
| LLM router and failover | guardian/agents/llm.py, guardian/config.py |
| Memory and learning | guardian/memory.py |
| Orchestration | guardian/orchestrator.py, guardian/runner.py, guardian/agents/pipeline.py |
| Scoring and evidence | guardian/agents/evidence.py, guardian/modules/analysis.py |
| Planning and remediation | guardian/remediate.py, guardian/agents/fixer.py, guardian/modules/remediation.py |
| Validation (sandbox, rescan, canaries) | guardian/agents/validator.py, guardian/agents/containers.py, guardian/canary.py, guardian/modules/validation.py |
| Scanner wrappers and git tools | guardian/tools/ |
| API server and UI | guardian/api/, guardian/serve.py, ui/ |
| Reports (md, html, json, SARIF, SBOM) | guardian/report.py, guardian/modules/report.py |
| Evaluation and scoreboard | guardian/eval/ |
| Tests | tests/ |
| Demo fixtures | demo/, guardian/api/fixtures/ |

See CLAUDE.md for conventions.

## Fix workflow: from finding to pull request (human approves, then it ships)
1. Fix known in OSV/Trivy -> `guardian propose` picks the version by a fixed rule (no AI chooses it).
   No fix anywhere -> `guardian nofix <run> <finding>` runs the agents: Investigator (finds the vulnerable call sites, file:line) -> Alternatives scout (replacements checked in OSV) -> Strategist (AI: replace / isolate / remove) -> Patch author (AI: edits ONLY at the lines found) -> Verifier (applies on a sandbox branch, searches again, rejects anything else touched).
2. Human approves (`guardian approve <id> --by NAME --reason TEXT`, or the Review screen).
3. Dependency fixes are built and tested in the Docker sandbox (`guardian validate <id>`); the AI patch is statically verified only.
4. Publish: `guardian publish <id> --by NAME --reason TEXT` (validated fix) or `guardian publish-patch <run> <finding> --by NAME --reason TEXT` (AI patch, always a DRAFT PR).
   Off by default. Turn on with GUARDIAN_ALLOW_PUSH=1 and GUARDIAN_GITHUB_TOKEN (fine-grained token, Contents + Pull requests write, ONE repo).
   For a project you do not own, fork it and set GUARDIAN_PUSH_REMOTE=https://github.com/YOU/REPO.
   Only guardian/* branches are pushed; never the default branch, never forced, never merged. Code: guardian/agents/publisher.py, tests/test_publisher.py.
   In the API: POST /plans/<finding>/publish, POST /scans/<scan>/workflow/publish, or approve at gate 6 with "ship": true to publish automatically once the result is verified.


## Use it inside your own codebase
The harness is one installable Python package (`guardian`) with no reference to the folder it sits in; state goes to `GUARDIAN_WORKSPACE` (default `./workspace`).
1. Copy this folder next to your code (or add it as a git submodule) and run `pip install -e ./guardian-harness`.
2. Point it at any repo: `guardian mscan <path-or-url> --base <tag> --head HEAD` (Day 1: inventory, changes, risks), then `guardian propose|approve|validate|publish` (Day 2: fix, human approval, sandbox, PR).
3. From code: `from guardian import runner; runner.scan(src, base, head)`; add your own detector by writing a module class with `id, needs, provides, run(ctx)` and listing it in `modules.yaml`.
4. As a service: `guardian api` (HTTP) or `guardian serve` (presenter UI). LLM agents are configured in `.env` (`GUARDIAN_API_KEY`, model chain, `GUARDIAN_FALLBACK_n`); with no key everything deterministic still runs and AI steps are reported as not run.
Day 1 and Day 2 design and plan: CLAUDE.md and README.md in this folder.
