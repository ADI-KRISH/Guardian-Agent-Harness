"""RunContext: the only thing a module touches. Read inputs from it; write through emit() / artifact()."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from .schema import Finding


@dataclass
class RunContext:
    repo_path: Path
    out_dir: Path
    base_ref: str | None = None
    head_ref: str | None = None
    snapshot_base: dict | None = None
    snapshot_head: dict | None = None
    config: dict = field(default_factory=dict)
    memory: Any = None
    tools: Any = None
    project: str = ""
    run_id: str = ""
    git_repo: Path | None = None       # full clone (for diffs); repo_path is the head checkout
    base_dir: Path | None = None       # baseline checkout, if any
    legacy: list[dict] = field(default_factory=list)   # ponytail: detectors park old-format findings here; M7 verifies, scores, converts
    comparison: dict = field(default_factory=dict)     # how the baseline was chosen: kind (approved-baseline | previous-scan | git-ref), ref, trusted
    blocked: str = ""                                  # set by the M8 self-check: a failed detector blocks the run
    gaps: list[str] = field(default_factory=list)      # what was NOT checked and why; shown in Coverage, never hidden
    partial: dict[str, str] = field(default_factory=dict)  # module id -> coverage gap that stops it doing its main job: status 'partial', never 'ok'
    findings: list[Finding] = field(default_factory=list)
    artifacts: dict[str, Any] = field(default_factory=dict)

    def emit(self, findings: list[Finding]) -> None:
        seen = {f.fingerprint for f in self.findings}
        for f in findings:
            f.validate()                      # a bad finding fails loudly at the module that made it
            if f.fingerprint not in seen:
                seen.add(f.fingerprint)
                self.findings.append(f)

    def artifact(self, name: str, data: Any) -> None:
        self.artifacts[name] = data
        self.out_dir.mkdir(parents=True, exist_ok=True)
        p = self.out_dir / name
        p.write_text(data if isinstance(data, str) else json.dumps(data, indent=2, default=str), encoding="utf-8")


class Module(Protocol):
    id: str
    needs: list[str]       # e.g. ["snapshot_base", "artifact:snapshot"]
    provides: list[str]    # e.g. ["findings"] or ["artifact:graph"]

    def run(self, ctx: RunContext) -> None: ...
