"""Registry: order modules by needs/provides (topological), refuse cycles and unmet needs, run them.

A need is satisfied by an earlier module's `provides`, or by a context field in BASE_INPUTS. Modules never import each other.
"""
from __future__ import annotations

from graphlib import CycleError, TopologicalSorter

import yaml

from .context import Module, RunContext

BASE_INPUTS = {"repo_path", "base_ref", "head_ref", "snapshot_base", "snapshot_head", "config", "memory", "tools", "out_dir"}


class RegistryError(RuntimeError):
    pass


def order(modules: list[Module]) -> list[Module]:
    by_id = {m.id: m for m in modules}
    if len(by_id) != len(modules):
        raise RegistryError("duplicate module id")
    provider = {}
    for m in modules:
        for p in m.provides:
            if p != "findings":                      # many modules provide findings; nobody needs them by name
                provider[p] = m.id
    ts = TopologicalSorter()
    for m in modules:
        deps = set()
        for n in m.needs:
            if n in BASE_INPUTS:
                continue
            if n not in provider:
                raise RegistryError(f"{m.id} needs {n!r}, which no enabled module provides")
            deps.add(provider[n])
        ts.add(m.id, *deps)
    try:
        return [by_id[i] for i in ts.static_order()]
    except CycleError as e:
        raise RegistryError(f"dependency cycle: {e.args[1]}") from e


def enabled(modules_yaml: str, available: dict[str, Module]) -> list[Module]:
    """modules.yaml: `enabled: [M3.change, ...]`. Unknown ids are an error, not a silent skip."""
    ids = (yaml.safe_load(modules_yaml) or {}).get("enabled", [])
    missing = [i for i in ids if i not in available]
    if missing:
        raise RegistryError(f"modules.yaml lists unknown modules: {missing}")
    return [available[i] for i in ids]


def run_all(modules: list[Module], ctx: RunContext, on_stage=None) -> dict[str, str]:
    """Run in dependency order. A crashing module is recorded as 'failed', never as clean; later modules still run."""
    status: dict[str, str] = {}
    import time
    for m in order(modules):
        t0 = time.time()
        if on_stage:
            on_stage(m.id, "running", 0.0, "")
        try:
            m.run(ctx)
            status[m.id] = f"partial: {ctx.partial[m.id]}" if m.id in ctx.partial else "ok"
        except Exception as e:  # noqa: BLE001 - surfaced in the report as a coverage gap
            status[m.id] = f"failed: {type(e).__name__}: {e}"
        if on_stage:
            on_stage(m.id, "ok" if status[m.id] == "ok" else status[m.id].split(":")[0], time.time() - t0, "" if status[m.id] == "ok" else status[m.id])
    return status
