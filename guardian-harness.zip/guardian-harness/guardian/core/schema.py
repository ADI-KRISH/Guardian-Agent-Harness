"""Finding contract (BUILD_PLAN "The two contracts"). One shape for every module; validated on emit."""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field

TYPES = {
    "known_vulnerability", "typosquat", "unexpected_dependency", "integrity_change", "install_script",
    "backdoor_signal", "unpinned_action", "untrusted_image", "provenance_missing", "policy_violation",
    "history_anomaly", "secret_exposed", "artifact_mismatch", "suspicious_update", "canary_missed",
    "dockerfile_issue", "workflow_issue",
}
SEVERITIES = ("critical", "high", "medium", "low", "unknown")   # unknown: the source gave no rating (never shown as Low)
CONFIDENCE = ("high", "medium", "low")
VERDICTS = ("confirmed", "needs_validation", "rejected")
STATUSES = ("open", "accepted", "fixed", "suppressed")
EVIDENCE_KINDS = ("tool_output", "diff", "file_line", "advisory")
# Guardrail: never suppressible, whatever a lesson says.
UNSUPPRESSIBLE = {"backdoor_signal", "integrity_change", "typosquat", "canary_missed", "artifact_mismatch"}


class SchemaError(ValueError):
    pass


def fingerprint(ftype: str, package: dict | None, location: dict | None) -> str:
    p, l = package or {}, location or {}
    src = "|".join([ftype, p.get("ecosystem", ""), p.get("name", ""), p.get("version", ""), l.get("file", ""), str(l.get("line", ""))])
    return hashlib.sha256(src.encode()).hexdigest()


@dataclass
class Finding:
    type: str
    title: str
    detector: str                      # module id, e.g. "M3.change"
    package: dict = field(default_factory=dict)      # {ecosystem, name, version}
    location: dict = field(default_factory=dict)     # {file, line, snippet}
    evidence: list[dict] = field(default_factory=list)       # [{kind, ref}]
    dependency_paths: list[list[str]] = field(default_factory=list)
    advisory_ids: list[str] = field(default_factory=list)
    fixed_versions: list[str] = field(default_factory=list)
    severity: str = "medium"
    score: float = 0.0
    confidence: str = "medium"
    score_reasons: list[str] = field(default_factory=list)
    ai_inference: dict | None = None   # {text, model, is_evidence: False}
    verdict: str = "needs_validation"
    missing_fact: str = ""
    suppressible: bool | None = None   # None -> derived from type
    status: str = "open"
    fingerprint: str = ""

    def __post_init__(self) -> None:
        if self.suppressible is None:
            self.suppressible = self.type not in UNSUPPRESSIBLE
        if not self.fingerprint:
            self.fingerprint = fingerprint(self.type, self.package, self.location)

    def validate(self) -> "Finding":
        def need(ok: bool, msg: str) -> None:
            if not ok:
                raise SchemaError(f"{self.type or '?'}/{self.title[:40]!r}: {msg}")
        need(self.type in TYPES, f"unknown type {self.type!r}")
        need(bool(self.title.strip()), "empty title")
        need(bool(self.detector), "detector required")
        need(self.severity in SEVERITIES, f"bad severity {self.severity!r}")
        need(self.confidence in CONFIDENCE, f"bad confidence {self.confidence!r}")
        need(self.verdict in VERDICTS, f"bad verdict {self.verdict!r}")
        need(self.status in STATUSES, f"bad status {self.status!r}")
        need(0.0 <= self.score <= 10.0, "score out of 0..10")
        need(all(e.get("kind") in EVIDENCE_KINDS and e.get("ref") for e in self.evidence), "evidence needs kind and ref")
        need(not (self.type in UNSUPPRESSIBLE and self.suppressible), "this type must not be suppressible")
        need(not self.ai_inference or self.ai_inference.get("is_evidence") is False, "AI text must be marked is_evidence=false")
        return self

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_legacy(cls, f: dict) -> "Finding":
        """Map the pre-M0 agent finding dict to the new contract."""
        sev = "unknown" if f.get("severity_unknown") else (f.get("risk_level") or "Medium").lower()
        ftype = {"new_dependency": "unexpected_dependency", "new_install_script": "install_script",
                 "malicious_package_heuristic": "backdoor_signal", "version_downgrade": "suspicious_update",
                 "origin_change": "suspicious_update", "untrusted_registry": "suspicious_update",
                 "unpinned_image": "untrusted_image", "workflow_issue": "unpinned_action",
                 "build_script_change": "suspicious_update", "prompt_injection_attempt": "backdoor_signal"}.get(f["type"], f["type"])
        comp = f.get("component") or ""
        eco, colon, rest = comp.partition(":")
        if not colon or "/" in eco or "@" in eco:   # not "eco:name@ver" (e.g. "detector:x" or a bare name)
            eco, rest = "", comp
        name, _, ver = rest.rpartition("@") if "@" in rest.lstrip("@") else (rest, "", "")
        ai = f.get("ai_inference") or None
        if isinstance(ai, list):
            ai = {"text": " ".join(map(str, ai)), "model": "", "is_evidence": False} if ai else None
        return cls(
            type=ftype, title=f["title"], detector=f.get("detector", "legacy"),
            package={"ecosystem": eco, "name": name, "version": ver} if name else {}, location=f.get("location") or {},
            advisory_ids=f.get("advisory_ids") or [], fixed_versions=f.get("fixed_versions") or [],
            fingerprint=hashlib.sha256(f["fingerprint"].encode()).hexdigest() if f.get("fingerprint") else "",
            evidence=[{"kind": "tool_output", "ref": str(e)} for e in f.get("verified_evidence", [])],
            dependency_paths=f.get("dependency_paths") or [], severity=sev if sev in SEVERITIES else "medium",
            score=float(f.get("score", 0.0)), confidence=f.get("confidence", "medium"),
            score_reasons=([f["score_explanation"]] if f.get("score_explanation") else []) + ([f["suppressed_by"]] if f.get("suppressed_by") else []),
            status="suppressed" if f.get("suppressed_by") else "open", ai_inference=ai,
            verdict=f.get("verdict") or ("confirmed" if f.get("verified_evidence") else "needs_validation"),
            missing_fact=f.get("missing_fact") or ("" if f.get("verified_evidence") else "no verified evidence attached"),
        )


def json_schema() -> dict:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "finding.v1", "type": "object",
        "required": ["fingerprint", "type", "title", "detector", "severity", "confidence", "verdict", "status"],
        "properties": {
            "fingerprint": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
            "type": {"enum": sorted(TYPES)}, "title": {"type": "string", "minLength": 1}, "detector": {"type": "string"},
            "package": {"type": "object"}, "location": {"type": "object"},
            "evidence": {"type": "array", "items": {"type": "object", "required": ["kind", "ref"],
                                                      "properties": {"kind": {"enum": list(EVIDENCE_KINDS)}}}},
            "dependency_paths": {"type": "array", "items": {"type": "array", "items": {"type": "string"}}},
            "advisory_ids": {"type": "array", "items": {"type": "string"}},
            "fixed_versions": {"type": "array", "items": {"type": "string"}},
            "severity": {"enum": list(SEVERITIES)}, "score": {"type": "number", "minimum": 0, "maximum": 10},
            "confidence": {"enum": list(CONFIDENCE)}, "score_reasons": {"type": "array", "items": {"type": "string"}},
            "ai_inference": {"type": ["object", "null"]}, "verdict": {"enum": list(VERDICTS)},
            "missing_fact": {"type": "string"}, "suppressible": {"type": "boolean"}, "status": {"enum": list(STATUSES)},
        },
    }
