# Guardian scoreboard

## Planted attacks: 7 of 7 caught

| Case | Planted | Must produce | Result |
| --- | --- | --- | --- |
| typosquat | lockfile gains 'lodahs' (swapped letters of lodash) | `typosquat` | CAUGHT |
| install-script | new dependency 'evil-hook' with an install script | `install_script` | CAUGHT |
| integrity | express keeps its version but its lockfile hash changes | `integrity_change` | CAUGHT |
| untrusted-image | Dockerfile base image moves to an unknown registry, :latest | `untrusted_image` | CAUGHT |
| encoded-exec | source gains eval(Buffer.from(<base64>)) | `backdoor_signal` | CAUGHT |
| unpinned-action | workflow gains an action pinned by a movable tag | `unpinned_action` | CAUGHT |
| secret | source gains an AWS-style access key | `secret_exposed` | CAUGHT |

False positives on decoys: 0 
Modules not ok: none
