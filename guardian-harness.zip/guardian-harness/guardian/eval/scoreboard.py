"""M15 scoreboard: measured results, one command. `guardian eval` (planted) or `guardian eval --real` (repos.yaml too)."""
from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path

import yaml

from .. import runner
from . import planted

REPOS = Path(__file__).with_name("repos.yaml")


def run_planted() -> dict:
    d = Path(tempfile.mkdtemp(prefix="planted-"))     # unique folder name = unique project name
    planted.build(d)
    r = runner.scan(str(d), "v1", "HEAD", Path(tempfile.mkdtemp()) / "out")
    types = {}
    for f in r["findings"]:
        types.setdefault(f.type, []).append(f.title)
    caught = [(cid, what, t, t in types) for cid, what, t in planted.CASES]
    fps = [(t, bad) for t, bad in planted.DECOYS if any(bad in title for title in types.get(t, []))]
    bad_modules = {k: v for k, v in r["status"].items() if v != "ok"}
    shutil.rmtree(d, ignore_errors=True)
    return {"caught": caught, "false_positives": fps, "modules_not_ok": bad_modules, "total_findings": len(r["findings"])}


def run_real(only: str | None = None) -> list[dict]:
    out = []
    for e in yaml.safe_load(REPOS.read_text(encoding="utf-8"))["repos"]:
        if only and e["name"] != only:
            continue
        r = runner.scan(e["url"], e.get("base"), e.get("head"))
        titles = [(f.type, f.title.lower()) for f in r["findings"]]
        key = [(t, s, any(ft == t and s.lower() in ti for ft, ti in titles)) for t, s in e.get("answer_key", [])]
        out.append({"name": e["name"], "findings": len(r["findings"]), "answer_key": key, "report": str(r["out"] / "report.md"),
                    "modules_not_ok": {k: v for k, v in r["status"].items() if v != "ok"}})
    return out


def table(p: dict, real: list[dict] | None = None) -> str:
    n_ok = sum(1 for *_, ok in p["caught"] if ok)
    lines = ["# Guardian scoreboard", "", f"## Planted attacks: {n_ok} of {len(p['caught'])} caught", "",
             "| Case | Planted | Must produce | Result |", "| --- | --- | --- | --- |"]
    lines += [f"| {c} | {w} | `{t}` | {'CAUGHT' if ok else 'MISSED'} |" for c, w, t, ok in p["caught"]]
    lines += ["", f"False positives on decoys: {len(p['false_positives'])} {p['false_positives'] or ''}",
              f"Modules not ok: {p['modules_not_ok'] or 'none'}"]
    for r in real or []:
        k = sum(1 for *_, ok in r["answer_key"] if ok)
        lines += ["", f"## {r['name']}: {r['findings']} findings, answer key {k} of {len(r['answer_key'])}", ""]
        lines += [f"- {'FOUND' if ok else 'MISSED'} `{t}` containing '{s}'" for t, s, ok in r["answer_key"]]
    return "\n".join(lines) + "\n"


JSON_PATH = Path(__file__).parent / "scoreboard.json"


def load() -> dict:
    """Last saved scoreboard (planted suite + benchmark repos) plus the live deterministic regression suite. Nothing here is computed for display."""
    from .regression import evaluate
    saved = json.loads(JSON_PATH.read_text(encoding="utf-8")) if JSON_PATH.exists() else {"planted": None, "repos": [], "last_run": None}
    return {**saved, "regression": evaluate()}


def main(real: bool = False, only: str | None = None) -> str:
    import time
    p = run_planted()
    repos = run_real(only) if real else []
    txt = table(p, repos or None)
    (Path(__file__).parent / "scoreboard.md").write_text(txt, encoding="utf-8")
    old = json.loads(JSON_PATH.read_text(encoding="utf-8")) if JSON_PATH.exists() else {}
    JSON_PATH.write_text(json.dumps({"planted": {"caught": [{"case": c, "planted": w, "must_produce": t, "caught": ok} for c, w, t, ok in p["caught"]],
                                                 "false_positives": p["false_positives"], "modules_not_ok": p["modules_not_ok"], "total_findings": p["total_findings"]},
                                     "repos": repos or old.get("repos", []), "last_run": time.strftime("%Y-%m-%dT%H:%M:%S")}, indent=2), encoding="utf-8")
    return txt
