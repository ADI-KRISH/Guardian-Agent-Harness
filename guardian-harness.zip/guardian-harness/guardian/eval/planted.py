"""Planted attacks and decoys, built in a throw-away local git repo (never pushed). Each case names the finding it must produce."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

LOCK = {"name": "demo", "lockfileVersion": 3, "requires": True, "packages": {
    "": {"name": "demo", "dependencies": {"lodash": "4.17.21", "express": "4.21.2"}},
    "node_modules/lodash": {"version": "4.17.21", "resolved": "https://registry.npmjs.org/lodash/-/lodash-4.17.21.tgz", "integrity": "sha512-aaa"},
    "node_modules/express": {"version": "4.21.2", "resolved": "https://registry.npmjs.org/express/-/express-4.21.2.tgz", "integrity": "sha512-eee"}}}
WORKFLOW_BASE = "name: ci\non: push\njobs:\n  b:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo hi\n"
WORKFLOW_BAD = WORKFLOW_BASE + "      - uses: some-org/some-action@v1\n"

# (id, what is planted, finding type it must produce)
CASES = [
    ("typosquat", "lockfile gains 'lodahs' (swapped letters of lodash)", "typosquat"),
    ("install-script", "new dependency 'evil-hook' with an install script", "install_script"),
    ("integrity", "express keeps its version but its lockfile hash changes", "integrity_change"),
    ("untrusted-image", "Dockerfile base image moves to an unknown registry, :latest", "untrusted_image"),
    ("encoded-exec", "source gains eval(Buffer.from(<base64>))", "backdoor_signal"),
    ("unpinned-action", "workflow gains an action pinned by a movable tag", "unpinned_action"),
    ("secret", "source gains an AWS-style access key", "secret_exposed"),
]
# decoys must NOT produce these (type, text that must not appear in the title)
DECOYS = [("typosquat", "'lodash' looks"), ("backdoor_signal", "decoy.js")]      # the real lodash must not be called a typosquat


def _git(d: Path, *a: str) -> None:
    subprocess.run(["git", "-C", str(d), "-c", "user.email=eval@x.io", "-c", "user.name=eval", *a], check=True, capture_output=True)


def build(dest: Path) -> Path:
    dest.mkdir(parents=True, exist_ok=True)
    _git(dest, "init", "-q")
    (dest / ".github" / "workflows").mkdir(parents=True)
    (dest / "package.json").write_text(json.dumps({"name": "demo", "dependencies": {"lodash": "4.17.21", "express": "4.21.2"}}), encoding="utf-8")
    (dest / "package-lock.json").write_text(json.dumps(LOCK), encoding="utf-8")
    (dest / "Dockerfile").write_text("FROM node:22-slim\nCOPY . .\n", encoding="utf-8")
    (dest / ".github" / "workflows" / "ci.yml").write_text(WORKFLOW_BASE, encoding="utf-8")
    _git(dest, "add", "-A"); _git(dest, "commit", "-qm", "base"); _git(dest, "tag", "v1")
    lock = json.loads(json.dumps(LOCK))
    lock["packages"][""]["dependencies"].update({"lodahs": "1.0.0", "evil-hook": "1.0.0"})
    lock["packages"]["node_modules/lodahs"] = {"version": "1.0.0", "resolved": "https://registry.npmjs.org/lodahs/-/lodahs-1.0.0.tgz", "integrity": "sha512-ttt"}
    lock["packages"]["node_modules/evil-hook"] = {"version": "1.0.0", "resolved": "https://registry.npmjs.org/evil-hook/-/evil-hook-1.0.0.tgz",
                                                  "integrity": "sha512-hhh", "hasInstallScript": True}
    lock["packages"]["node_modules/express"]["integrity"] = "sha512-CHANGED"
    (dest / "package-lock.json").write_text(json.dumps(lock), encoding="utf-8")
    (dest / "Dockerfile").write_text("FROM evilcorp.example/base:latest\nCOPY . .\n", encoding="utf-8")
    (dest / ".github" / "workflows" / "ci.yml").write_text(WORKFLOW_BAD, encoding="utf-8")
    (dest / "app.js").write_text("eval(Buffer.from('Y29uc29sZS5sb2coMSk=', 'base64').toString())\n", encoding="utf-8")
    (dest / "conf.js").write_text('const k = "AKIAABCDEFGHIJKLMNOP";\n', encoding="utf-8")
    (dest / "decoy.js").write_text("const proxy = process.env.HTTPS_PROXY || '';\n", encoding="utf-8")   # decoy: must not alert
    _git(dest, "add", "-A"); _git(dest, "commit", "-qm", "head")
    return dest
