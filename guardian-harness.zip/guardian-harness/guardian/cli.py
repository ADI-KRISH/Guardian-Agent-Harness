"""guardian CLI.

  guardian scan <repo-url-or-path> [--base REF] [--head REF] [--no-llm] [--fail-on High]
  guardian approve-baseline <repo-url-or-path> <ref> --by NAME --reason TEXT
  guardian label <project> <finding-id> <confirmed|false_positive|accepted|open> --by NAME --reason TEXT
  guardian add-lesson <project> --rule TYPE_OR_RULE --scope GLOB --by NAME --reason TEXT [--days 30]
  guardian tags <repo-url-or-path>
Exit codes: 0 ok, 1 findings at or above --fail-on, 2 usage error.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import config
from .agents import discovery
from .memory import Memory
from .tools import git


def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):   # LLM text has non-cp1252 characters; a log line must never kill a scan on Windows
        getattr(stream, "reconfigure", lambda **k: None)(errors="replace")
    ap = argparse.ArgumentParser(prog="guardian", description="Software Supply Chain Guardian")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan"); s.add_argument("repo"); s.add_argument("--base"); s.add_argument("--head")
    s.add_argument("--no-llm", action="store_true"); s.add_argument("--fail-on", choices=["Critical", "High", "Medium", "Low"])
    m = sub.add_parser("mscan", help="modular scan (registry + M1..M10 modules)"); m.add_argument("repo")
    m.add_argument("--base"); m.add_argument("--head"); m.add_argument("--out", type=Path)
    fx = sub.add_parser("fix", help="M11/M12: propose a fix for a finding of a modular run"); fx.add_argument("out"); fx.add_argument("finding")
    mv = sub.add_parser("mvalidate", help="M12: validate an APPROVED fix (modular run) in Docker"); mv.add_argument("proposal")
    mv.add_argument("--test", default=os.getenv("GUARDIAN_VALIDATE_TEST", ""))
    iv = sub.add_parser("investigate", help="M9/M19: AI investigation of the top findings of a modular run, claims checked"); iv.add_argument("out")
    mo = sub.add_parser("monitor", help="S6: re-check a stored SBOM against today's advisories"); mo.add_argument("out")
    ad = sub.add_parser("artifact-diff", help="S7: diff a published npm package against its source tree"); ad.add_argument("spec"); ad.add_argument("source_dir")
    bh = sub.add_parser("behaviour", help="S8: run a package's install scripts in the sandbox under strace, network off"); bh.add_argument("spec")
    ev = sub.add_parser("eval", help="M15: scoreboard (planted attacks; --real adds repos.yaml)"); ev.add_argument("--real", action="store_true"); ev.add_argument("--only")
    ap_ = sub.add_parser("api", help="Guardian API for the console (127.0.0.1:48200; GUARDIAN_DEMO=1 serves the saved Juice Shop scan)"); ap_.add_argument("--port", type=int, default=48200)
    nf = sub.add_parser("nofix", help="run the no-fix agentic workflow for one finding of a run folder (investigate, find alternatives, strategy, patch, verify)")
    nf.add_argument("out"); nf.add_argument("finding")
    b = sub.add_parser("approve-baseline"); b.add_argument("repo"); b.add_argument("ref"); b.add_argument("--by", required=True); b.add_argument("--reason", required=True)
    l = sub.add_parser("label"); l.add_argument("project"); l.add_argument("finding"); l.add_argument("status")
    l.add_argument("--by", required=True); l.add_argument("--reason", required=True)
    le = sub.add_parser("add-lesson"); le.add_argument("project"); le.add_argument("--rule", required=True); le.add_argument("--scope", required=True)
    le.add_argument("--by", required=True); le.add_argument("--reason", required=True); le.add_argument("--days", type=int, default=30)
    t = sub.add_parser("tags"); t.add_argument("repo")
    pr = sub.add_parser("propose", help="Day 2: propose a fix for one finding of the latest scan")
    pr.add_argument("project"); pr.add_argument("finding"); pr.add_argument("--run")
    for nm in ("approve", "reject"):
        x = sub.add_parser(nm, help=f"Day 2: a named human {nm}s a fix proposal"); x.add_argument("proposal")
        x.add_argument("--by", required=True); x.add_argument("--reason", required=True)
    va = sub.add_parser("validate", help="Day 2: build and test an APPROVED fix in the Docker sandbox, rescan, write the report")
    va.add_argument("proposal"); va.add_argument("--test", default=os.getenv("GUARDIAN_VALIDATE_TEST", ""), help="project test command to run in the sandbox")
    pb = sub.add_parser("publish", help="Day 2: push a VALIDATED, approved fix and open the pull request (needs GUARDIAN_ALLOW_PUSH=1; never merges)")
    pb.add_argument("proposal"); pb.add_argument("--by", required=True); pb.add_argument("--reason", required=True)
    pp = sub.add_parser("publish-patch", help="push the patch drafted by the no-fix agents as a DRAFT pull request (needs GUARDIAN_ALLOW_PUSH=1; never merges)")
    pp.add_argument("out"); pp.add_argument("finding"); pp.add_argument("--by", required=True); pp.add_argument("--reason", required=True)
    sv = sub.add_parser("serve", help="live presenter page: paste a repo link and watch the harness work")
    sv.add_argument("--port", type=int, default=8765); sv.add_argument("--no-open", action="store_true")
    a = ap.parse_args(argv)

    try:
        if a.cmd == "scan":
            from .agents.orchestrator import Run
            from .report import write
            r = Run(a.repo, a.base, a.head, use_llm=not a.no_llm).execute()
            out = write(r)
            s = r["summary"]
            print(f"\nDone in {s['seconds']} s: {s['findings']} findings {s['by_level']}")
            print(f"Report: {out / 'report.html'}")
            if a.fail_on:
                order = ["Low", "Medium", "High", "Critical"]
                if any(order.index(f["risk_level"]) >= order.index(a.fail_on) for f in r["findings"] if not f.get("suppressed_by")):
                    return 1
        elif a.cmd == "mscan":
            from . import runner
            r = runner.scan(a.repo, a.base, a.head, a.out)
            bad = {k: v for k, v in r["status"].items() if v != "ok"}
            print(f"{len(r['findings'])} findings. Report: {r['out'] / 'report.html'}  SARIF: {r['out'] / 'report.sarif'}")
            viol = [f for f in r["findings"] if f.type == "policy_violation"]
            if viol:
                print(f"POLICY GATE: BLOCKED by {len(viol)} rule violation(s): {sorted({v.title.split(':')[0] for v in viol})}")
            if bad:
                print(f"modules not ok: {bad}")
                return 1
            if viol:
                return 3
        elif a.cmd == "fix":
            from .modules import validation
            p = validation.propose(Memory(), Path(a.out).resolve(), a.finding)
            if not p["ok"]:
                print(f"No automatic fix: {p['reason']}"); return 1
            print(f"Proposal {p['id']}: {p['change']}\nNext: guardian approve {p['id']} --by NAME --reason TEXT ; guardian mvalidate {p['id']}")
        elif a.cmd == "mvalidate":
            from .modules import validation
            res = validation.validate(Memory(), a.proposal, a.test)
            print(f"Verdict: {res['verdict']} - {res['verdict_reason']}\nReport: {Path(res['report_dir']) / 'remediation.html'}")
            return 0 if res["verdict"] != "not-verified" else 1
        elif a.cmd == "investigate":
            from .agents import lead
            print(lead.run(Path(a.out).resolve(), Memory())["summary"])
        elif a.cmd in ("monitor", "artifact-diff", "behaviour"):
            from .modules import ondemand
            res = (ondemand.monitor(Path(a.out)) if a.cmd == "monitor" else ondemand.artifact_diff(a.spec, Path(a.source_dir))
                   if a.cmd == "artifact-diff" else ondemand.behaviour(a.spec))
            print(json.dumps(res, indent=2))
        elif a.cmd == "eval":
            from .eval import scoreboard
            print(scoreboard.main(a.real, a.only))
        elif a.cmd == "api":
            from .api.server import serve as serve_api
            serve_api(a.port)
        elif a.cmd == "nofix":
            from .api.service import ApiError, Backend
            try:
                rec = Backend([Path(a.out).resolve()]).run_workflow(Path(a.out).resolve().name, a.finding, on_step=lambda ag, st, secs, note: print(f"  [{ag}] {st} ({secs:.1f}s) {note[:150]}"))
            except ApiError as e:
                print(f"error: {e.message}", file=sys.stderr); return 2
            print(f"\nOutcome: {rec['outcome']}" + (f" ({rec['stop_reason']})" if rec["stop_reason"] else ""))
            print(rec.get("recommendation", ""))
            for g_ in rec["human_gates"]:
                print(f"  waiting: {g_}")
        elif a.cmd == "approve-baseline":
            proj = git.project_name(a.repo)
            repo = git.clone(a.repo, config.WORKSPACE / "repos" / proj)
            d = git.checkout(repo, a.ref, config.WORKSPACE / "checkouts" / proj / a.ref.replace("/", "_"))
            snap = discovery.snapshot(d, run_syft=False)
            Memory().approve_baseline(proj, a.ref, snap, a.by, a.reason)
            print(f"Baseline {a.ref} for {proj} approved by {a.by} ({len(snap['packages'])} packages).")
        elif a.cmd == "label":
            Memory().label(a.project, a.finding, a.status, a.by, a.reason)
            print("Label saved and logged.")
        elif a.cmd == "add-lesson":
            Memory().add_lesson(a.project, "suppress", a.rule, a.scope, a.reason, a.by, a.days)
            print("Lesson saved (expires in %d days)." % a.days)
        elif a.cmd == "propose":
            from . import remediate
            p = remediate.propose(Memory(), a.project, a.finding, a.run)
            if not p["ok"]:
                print(f"No automatic fix: {p['reason']}")
                return 1
            print(f"\nProposal {p['id']}: {p['change']}\n  resolves {len(p['resolves'])} finding(s): {p['expected_risk_reduction']['levels']}\n"
                  f"  compatibility: {p['compatibility_note']}\n  rollback: {p['rollback']}\n"
                  f"Next: guardian approve {p['id']} --by NAME --reason TEXT   then   guardian validate {p['id']}")
        elif a.cmd in ("approve", "reject"):
            Memory().decide_proposal(a.proposal, "approved" if a.cmd == "approve" else "rejected", a.by, a.reason)
            print(f"Fix {a.proposal} {a.cmd}d by {a.by} (logged).")
        elif a.cmd == "validate":
            from . import remediate
            res = remediate.validate(Memory(), a.proposal, a.test)
            print(f"\nVerdict: {res['verdict']} - {res['verdict_reason']}\nReport: {Path(res['report_dir']) / 'remediation.html'}")
            return 0 if res["verdict"] != "not-verified" else 1
        elif a.cmd == "publish":
            from .agents import publisher
            mem = Memory()
            p = mem.get_proposal(a.proposal)
            res = p.get("result") or {}
            if p["status"] != "approved" or res.get("verdict") not in publisher.OK_VERDICTS:
                print("error: only an approved fix with a 'verified' result is published (approve it, then validate it)", file=sys.stderr); return 1
            text = Path(res.get("report_dir", "")) / "pr-body.md"
            out = publisher.publish(Path(res["sandbox"]), res["branch"], f"guardian: {p['change']}", text.read_text(encoding="utf-8") if text.is_file() else p["change"], a.by, a.reason,
                                    base_sha=p.get("head_sha", ""), draft=res["verdict"] != "verified", mem=mem, run_id=f"fix-{p['id']}", project=p["project"])
            print(f"Pushed {out['branch']} to {out['repo']}\nPull request ({'draft' if out['draft'] else 'ready'}): {out['pull_request']}\nThe Guardian never merges.")
        elif a.cmd == "publish-patch":
            from .api.service import ApiError, Backend
            try:
                out = Backend([Path(a.out).resolve()]).publish_workflow(Path(a.out).resolve().name, {"finding_id": a.finding, "actor": a.by, "reason": a.reason})
            except ApiError as e:
                print(f"error: {e.message}", file=sys.stderr); return 2
            print(f"Pushed {out['branch']} to {out['repo']}\nDraft pull request: {out['pull_request']}\nThe Guardian never merges.")
        elif a.cmd == "serve":
            from .serve import serve
            serve(a.port, not a.no_open)
        elif a.cmd == "tags":
            proj = git.project_name(a.repo)
            repo = git.clone(a.repo, config.WORKSPACE / "repos" / proj)
            print("\n".join(git.latest_tags(repo, 20)))
    except (ValueError, KeyError, RuntimeError, PermissionError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
