"""Modular scan: plan the comparison, check out head/base, build a RunContext, run the enabled modules through the registry.

`guardian mscan <repo> [--base REF] [--head REF] [--out DIR]`, or the Guardian API. Outputs the M10 report set.

Baseline choice (ported from GuardianAI day1 (team): history/baseline logic), in this order, always labelled in the report:
  1. an explicit ref from the operator                      -> kind "git-ref", untrusted
  2. a human-approved baseline in memory                    -> kind "approved-baseline", trusted
  3. the previous scan's commit                             -> kind "previous-scan", untrusted (it was never approved by a person)
  4. the latest release tag                                 -> kind "git-ref", untrusted
"""
from __future__ import annotations

import re
import time
from pathlib import Path

from . import config
from .core import RunContext, enabled, run_all
from .memory import Memory
from .modules import AVAILABLE
from .tools import git

DEFAULT_MODULES = Path(__file__).resolve().parent.parent / "modules.yaml"
QUICK_SKIP = {"M17.history", "M18.secrets", "S3.provenance", "S4.pkgintel"}      # profile "quick": detectors only, no history/secret/registry lookups


def _safe(ref: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", ref)


def plan_comparison(mem: Memory, project: str, repo: Path, base_arg: str | None, head_ref: str, run_id: str = "") -> tuple[str | None, dict]:
    head_sha = git.resolve(repo, head_ref)
    if base_arg:
        return base_arg, {"kind": "git-ref", "ref": base_arg, "trusted": False, "note": "chosen by the operator; not a human-approved baseline"}
    approved = mem.get_baseline(project)
    if approved and git.resolve(repo, approved[0]) != head_sha:
        return approved[0], {"kind": "approved-baseline", "ref": approved[0], "trusted": True, "note": "approved by a named person"}
    last = mem.last_run(project, run_id)
    sha = (last or {}).get("summary", {}).get("head_sha")
    if sha and sha != head_sha and git.resolve(repo, sha):
        return sha, {"kind": "previous-scan", "ref": sha[:12], "trusted": False, "note": "the previous scan, never approved by a person: it shows change, not trust"}
    tags = git.latest_tags(repo)
    tag = next((t for t in tags if git.resolve(repo, t) != head_sha), None)
    if tag:
        return tag, {"kind": "git-ref", "ref": tag, "trusted": False, "note": "latest release tag; not a human-approved baseline"}
    return None, {"kind": "none", "ref": None, "trusted": False, "note": "no baseline, no previous scan and no tags: this scan establishes an observation, not trust"}


def scan(src: str, base: str | None = None, head: str | None = None, out: Path | None = None, modules_yaml: Path = DEFAULT_MODULES,
         options: dict | None = None, on_stage=None) -> dict:
    """options: profile (quick|standard|deep), offline, scan_images, ai. on_stage(module_id, state, seconds, detail) reports progress."""
    opts = options or {}
    ws, project = config.WORKSPACE, git.project_name(src)
    mem = Memory()
    t0 = time.time()
    repo = git.clone(src, ws / "repos" / project)
    head_ref = head or ("HEAD" if Path(src).exists() else "origin/HEAD")
    run_id = (out.name if out else time.strftime("%Y%m%d-%H%M%S"))
    base_ref, comparison = plan_comparison(mem, project, repo, base, head_ref, run_id)
    if base_ref and git.resolve(repo, base_ref) == git.resolve(repo, head_ref):
        base_ref, comparison = None, {"kind": "none", "ref": None, "trusted": False, "note": "baseline equals head"}
    head_dir = git.checkout(repo, head_ref, ws / "checkouts" / project / _safe(head_ref))
    base_dir = git.checkout(repo, base_ref, ws / "checkouts" / project / _safe(base_ref)) if base_ref else None
    out = out or ws / "mreports" / project / run_id
    cfg = config.load(head_dir) | {"offline": bool(opts.get("offline")), "scan_images": bool(opts.get("scan_images")), "profile": opts.get("profile", "standard")}
    ctx = RunContext(repo_path=head_dir, out_dir=out, project=project, run_id=run_id, base_ref=base_ref, head_ref=head_ref, config=cfg,
                     git_repo=repo, base_dir=base_dir, memory=mem, comparison=comparison)
    mem.start_run(run_id, project, base_ref or "", head_ref)
    mem.decide(run_id, project, "orchestrator", f"compare {base_ref} -> {head_ref}" if base_ref else "scan without a comparison", comparison["note"], comparison, rule="plan")
    mods = enabled(modules_yaml.read_text(encoding="utf-8"), AVAILABLE)
    if cfg["profile"] == "quick":
        mods = [m for m in mods if m.id not in QUICK_SKIP]

    def stage(module_id: str, state: str, seconds: float = 0.0, detail: str = "") -> None:
        if state != "running":                       # every finished stage writes an audit line: agent, decision, reason
            mem.decide(run_id, project, module_id, f"stage {state}", detail or f"{seconds:.1f}s", rule="stage")
        if on_stage:
            on_stage(module_id, state, seconds, detail)
    status = run_all(mods, ctx, on_stage=stage)
    head_sha = git.resolve(repo, head_ref)
    ctx.artifact("legacy_report.json", {"run_id": run_id, "project": project, "source": src, "base_ref": base_ref, "head_ref": head_ref,
                                        "head_commit": git.commit_info(repo, head_ref), "comparison": comparison,
                                        "findings": ctx.artifacts.get("legacy_findings.json", [])})
    ctx.artifact("module-status.json", status)
    ctx.artifact("scan-meta.json", {"run_id": run_id, "project": project, "source": src, "head_sha": head_sha, "comparison": comparison,
                                    "seconds": round(time.time() - t0, 1), "created": time.strftime("%Y-%m-%dT%H:%M:%S"), "blocked": ctx.blocked,
                                    "options": {k: opts.get(k) for k in ("profile", "offline", "scan_images", "ai")}})
    mem.save_findings(run_id, project, ctx.artifacts.get("legacy_findings.json", []))
    mem.finish_run(run_id, {"head_sha": head_sha, "findings": len(ctx.findings), "blocked": ctx.blocked})
    return {"out": out, "status": status, "findings": ctx.findings, "blocked": ctx.blocked, "comparison": comparison}
