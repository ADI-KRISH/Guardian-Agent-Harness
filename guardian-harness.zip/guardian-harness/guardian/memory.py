"""Memory: one SQLite file with five stores.

baselines  - trusted snapshots; written ONLY by a human approval (approve_baseline)
findings   - every finding of every run, with status set by humans
decisions  - append-only audit log: every decision by an agent or a human, with its reason
lessons    - human-approved rules learned from labels (scoped, with expiry)
cache      - knowledge cache (tool/registry lookups) with fetch time
Working memory for a run lives in the Run object and only its summary is stored.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

from .config import WORKSPACE

SCHEMA = """
CREATE TABLE IF NOT EXISTS baselines (project TEXT, ref TEXT, snapshot TEXT, approved_by TEXT, reason TEXT, ts REAL,
  PRIMARY KEY (project, ref));
CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, project TEXT, base_ref TEXT, head_ref TEXT, started REAL, finished REAL, summary TEXT);
CREATE TABLE IF NOT EXISTS findings (id TEXT, run_id TEXT, project TEXT, fingerprint TEXT, data TEXT,
  status TEXT DEFAULT 'open', label_by TEXT, label_reason TEXT, PRIMARY KEY (id, run_id));
CREATE TABLE IF NOT EXISTS decisions (seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, project TEXT, actor TEXT,
  decision TEXT, why TEXT, inputs TEXT, rule TEXT, confidence TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS lessons (id INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT, kind TEXT, rule TEXT, scope TEXT,
  reason TEXT, approved_by TEXT, expires REAL, ts REAL);
CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS reviews (run_id TEXT, finding_id TEXT, status TEXT, actor TEXT, reason TEXT, ts REAL, PRIMARY KEY (run_id, finding_id));
CREATE TABLE IF NOT EXISTS proposals (id TEXT PRIMARY KEY, project TEXT, run_id TEXT, finding_id TEXT, data TEXT,
  status TEXT DEFAULT 'proposed', decided_by TEXT, decided_reason TEXT, result TEXT, ts REAL);
CREATE TRIGGER IF NOT EXISTS decisions_append_only_u BEFORE UPDATE ON decisions BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS decisions_append_only_d BEFORE DELETE ON decisions BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
"""

# Finding types a lesson may never suppress (guardrail).
UNSUPPRESSIBLE = {"backdoor_signal", "integrity_change", "typosquat", "canary_missed", "artifact_mismatch"}
# Rule ids (not types) that are protected as well: a lesson that names one of them is refused.
PROTECTED_RULES = {"exec-encoded", "secret-exfiltration", "bidi-source", "integrity-change", "obfuscated-execution", "download-and-run",
                   "env-exfil", "secret-file-read", "install-hook"}
REVIEW_STATUSES = {"open", "confirmed", "false_positive", "accepted"}


def is_protected(rule: str) -> bool:
    return rule in UNSUPPRESSIBLE or rule in PROTECTED_RULES


class Memory:
    def __init__(self, path: Path | None = None):
        path = path or WORKSPACE / "guardian.db"
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.executescript(SCHEMA)
        for col, ddl in (("state", "TEXT DEFAULT 'active'"), ("path", "TEXT"), ("evaluation", "TEXT"), ("source_finding", "TEXT")):
            try:                                   # additive migration for databases created before lesson states existed
                self.db.execute(f"ALTER TABLE lessons ADD COLUMN {col} {ddl}")
            except sqlite3.OperationalError:
                pass
        self.db.commit()

    # ---------- audit log ----------
    def decide(self, run_id: str, project: str, actor: str, decision: str, why: str,
               inputs: dict | None = None, rule: str = "", confidence: str = "") -> None:
        self.db.execute(
            "INSERT INTO decisions (run_id, project, actor, decision, why, inputs, rule, confidence, ts) VALUES (?,?,?,?,?,?,?,?,?)",
            (run_id, project, actor, decision, why, json.dumps(inputs or {}, default=str), rule, confidence, time.time()))
        self.db.commit()

    def decisions(self, run_id: str) -> list[dict]:
        cur = self.db.execute("SELECT seq, actor, decision, why, inputs, rule, confidence, ts FROM decisions WHERE run_id=? ORDER BY seq", (run_id,))
        return [dict(zip(["seq", "actor", "decision", "why", "inputs", "rule", "confidence", "ts"], r)) for r in cur]

    # ---------- baselines (human-only writes) ----------
    def approve_baseline(self, project: str, ref: str, snapshot: dict, approved_by: str, reason: str) -> None:
        if not approved_by or not reason:
            raise ValueError("A baseline can only be approved by a named human with a reason.")
        self.db.execute("INSERT OR REPLACE INTO baselines VALUES (?,?,?,?,?,?)",
                        (project, ref, json.dumps(snapshot), approved_by, reason, time.time()))
        self.db.commit()
        self.decide("-", project, f"human:{approved_by}", f"approve baseline {ref}", reason, rule="baseline-human-only")

    def get_baseline(self, project: str, ref: str | None = None) -> tuple[str, dict] | None:
        q = "SELECT ref, snapshot FROM baselines WHERE project=?" + (" AND ref=?" if ref else "") + " ORDER BY ts DESC LIMIT 1"
        row = self.db.execute(q, (project, ref) if ref else (project,)).fetchone()
        return (row[0], json.loads(row[1])) if row else None

    # ---------- runs and findings ----------
    def start_run(self, run_id: str, project: str, base_ref: str, head_ref: str) -> None:
        self.db.execute("INSERT INTO runs VALUES (?,?,?,?,?,?,?)", (run_id, project, base_ref, head_ref, time.time(), None, None))
        self.db.commit()

    def finish_run(self, run_id: str, summary: dict) -> None:
        self.db.execute("UPDATE runs SET finished=?, summary=? WHERE id=?", (time.time(), json.dumps(summary), run_id))
        self.db.commit()

    def save_findings(self, run_id: str, project: str, findings: list[dict]) -> None:
        for f in findings:
            prev = self.db.execute("SELECT status, label_by, label_reason FROM findings WHERE project=? AND fingerprint=? AND status!='open' ORDER BY rowid DESC LIMIT 1",
                                   (project, f["fingerprint"])).fetchone()
            status = prev or ("open", None, None)
            f["status"] = status[0]
            self.db.execute("INSERT OR REPLACE INTO findings VALUES (?,?,?,?,?,?,?,?)",
                            (f["id"], run_id, project, f["fingerprint"], json.dumps(f, default=str), *status))
        self.db.commit()

    def label(self, project: str, finding_id: str, status: str, by: str, reason: str) -> None:
        if status not in {"confirmed", "false_positive", "accepted", "open"}:
            raise ValueError("status must be confirmed | false_positive | accepted | open")
        if not by or not reason:
            raise ValueError("A label needs the reviewer's name and a reason.")
        n = self.db.execute("UPDATE findings SET status=?, label_by=?, label_reason=? WHERE project=? AND id=?",
                            (status, by, reason, project, finding_id)).rowcount
        self.db.commit()
        if not n:
            raise KeyError(f"No finding {finding_id} in {project}")
        self.decide("-", project, f"human:{by}", f"label {finding_id} as {status}", reason, rule="human-label")

    # ---------- lessons ----------
    def active_lessons(self, project: str) -> list[dict]:
        cur = self.db.execute("SELECT id, kind, rule, scope, reason, approved_by, expires FROM lessons WHERE project=? AND state='active' AND (expires IS NULL OR expires>?)",
                              (project, time.time()))
        return [dict(zip(["id", "kind", "rule", "scope", "reason", "approved_by", "expires"], r)) for r in cur]

    def add_lesson(self, project: str, kind: str, rule: str, scope: str, reason: str, approved_by: str, days: int = 30) -> None:
        if kind == "suppress" and is_protected(rule):
            raise ValueError(f"Guardrail: findings of type '{rule}' can never be suppressed by a lesson.")
        if not approved_by:
            raise ValueError("Lessons need human approval.")
        self.db.execute("INSERT INTO lessons (project, kind, rule, scope, reason, approved_by, expires, ts) VALUES (?,?,?,?,?,?,?,?)",
                        (project, kind, rule, scope, reason, approved_by, time.time() + days * 86400, time.time()))
        self.db.commit()
        self.decide("-", project, f"human:{approved_by}", f"approve lesson {kind}:{rule} on {scope}", reason, rule="lesson-human-approval")

    # ---------- named reviews (gate 2) and lesson proposals (M20). Ported from GuardianAI day1 (team): store.py ----------
    @staticmethod
    def identity(actor: str, reason: str) -> None:
        if not str(actor).strip() or not str(reason).strip():
            raise ValueError("A reviewer name and a written reason are required")

    def review(self, run_id: str, project: str, finding_id: str, status: str, actor: str, reason: str, rule: str = "", file: str = "") -> int | None:
        """Records a human label as an overlay on the finding. A false positive on an unprotected rule also proposes a scoped,
        30-day lesson (state 'proposed'); it does nothing until `approve_lesson` runs its regression evaluation. Returns the lesson id."""
        self.identity(actor, reason)
        if status not in REVIEW_STATUSES:
            raise ValueError("status must be one of: " + ", ".join(sorted(REVIEW_STATUSES)))
        self.db.execute("INSERT OR REPLACE INTO reviews VALUES (?,?,?,?,?,?)", (run_id, finding_id, status, actor.strip(), reason.strip(), time.time()))
        self.db.commit()
        self.decide(run_id, project, f"human:{actor.strip()}", f"review {finding_id}: {status}", reason.strip(), rule="human-review")
        if status == "false_positive" and rule and file and not is_protected(rule):
            cur = self.db.execute("INSERT INTO lessons (project, kind, rule, scope, path, reason, approved_by, expires, ts, state, source_finding) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                                  (project, "suppress", rule, file, file, reason.strip(), "", time.time() + 30 * 86400, time.time(), "proposed", finding_id))
            self.db.commit()
            self.decide(run_id, project, "learning-agent", f"propose a scoped 30-day suppression of {rule} on {file}",
                        "human false-positive label; approval and the regression evaluation are still required", rule="lesson-proposal")
            return cur.lastrowid
        return None

    def reviews(self, run_id: str) -> dict[str, dict]:
        cur = self.db.execute("SELECT finding_id, status, actor, reason, ts FROM reviews WHERE run_id=?", (run_id,))
        return {r[0]: dict(zip(["finding_id", "status", "actor", "reason", "ts"], r)) for r in cur}

    def lessons_by_state(self, project: str | None = None) -> list[dict]:
        q = "SELECT id, project, kind, rule, scope, reason, approved_by, expires, state, evaluation, source_finding FROM lessons" + (" WHERE project=?" if project else "") + " ORDER BY id DESC"
        cur = self.db.execute(q, (project,) if project else ())
        cols = ["id", "project", "kind", "rule", "scope", "reason", "approved_by", "expires", "state", "evaluation", "source_finding"]
        out = []
        for r in cur:
            d = dict(zip(cols, r))
            d["evaluation"] = json.loads(d["evaluation"]) if d["evaluation"] else None
            d["protected"] = is_protected(d["rule"])
            out.append(d)
        return out

    def approve_lesson(self, lesson_id: int, actor: str, reason: str) -> dict:
        """Gate 8. Refuses protected rules and expired lessons, runs the planted regression suite WITH the lesson applied,
        and activates it only if every planted case is still detected."""
        self.identity(actor, reason)
        row = next((l for l in self.lessons_by_state() if l["id"] == lesson_id), None)
        if not row or row["state"] != "proposed":
            raise ValueError("Lesson not found or not waiting for approval")
        if row["protected"]:
            raise ValueError("Lesson targets a protected rule")
        if row["expires"] and row["expires"] <= time.time():
            raise ValueError("Lesson has expired")
        from .eval.regression import evaluate
        result = evaluate({"rule": row["rule"], "path": row["scope"]})
        self.db.execute("UPDATE lessons SET evaluation=? WHERE id=?", (json.dumps({"passed": result["passed"], "passing": result["passing"], "total": result["total"]}), lesson_id))
        if not result["passed"]:
            self.db.commit()
            self.decide("-", row["project"], f"human:{actor.strip()}", f"lesson {lesson_id} refused", "the regression evaluation failed: the lesson would hide a planted case", rule="lesson-evaluation")
            raise ValueError("Lesson failed the regression evaluation")
        self.db.execute("UPDATE lessons SET state='active', approved_by=? WHERE id=?", (actor.strip(), lesson_id))
        self.db.commit()
        self.decide("-", row["project"], f"human:{actor.strip()}", f"approve lesson {lesson_id}", reason.strip() + "; regression evaluation passed", rule="lesson-human-approval")
        return result

    def reject_lesson(self, lesson_id: int, actor: str, reason: str) -> None:
        self.identity(actor, reason)
        n = self.db.execute("UPDATE lessons SET state='rejected' WHERE id=? AND state='proposed'", (lesson_id,)).rowcount
        self.db.commit()
        if not n:
            raise ValueError("Lesson not found or not waiting for approval")
        self.decide("-", "", f"human:{actor.strip()}", f"reject lesson {lesson_id}", reason.strip(), rule="lesson-human-approval")

    def promote_baseline(self, project: str, ref: str, snapshot: dict, run_id: str, actor: str, reason: str, findings: list[dict] | None = None) -> None:
        """Gate 1. A baseline needs a complete inventory and no unreviewed Critical finding."""
        self.identity(actor, reason)
        if not snapshot.get("packages"):
            raise ValueError("An empty or incomplete inventory cannot become a trusted baseline")
        reviewed = {fid for fid, r in self.reviews(run_id).items() if r["status"] != "open"}
        rows = findings if findings is not None else [json.loads(d) for (d,) in self.db.execute("SELECT data FROM findings WHERE run_id=? AND project=?", (run_id, project))]
        open_crit = [f["id"] for f in rows if f.get("risk_level") == "Critical" and not f.get("suppressed_by") and f["id"] not in reviewed]
        if open_crit:
            raise ValueError(f"Review all open Critical findings before promoting a baseline ({len(open_crit)} open)")
        self.approve_baseline(project, ref, snapshot, actor, reason)

    def last_run(self, project: str, exclude_run: str = "") -> dict | None:
        row = self.db.execute("SELECT id, head_ref, summary FROM runs WHERE project=? AND finished IS NOT NULL AND id!=? ORDER BY started DESC LIMIT 1", (project, exclude_run)).fetchone()
        return {"id": row[0], "head_ref": row[1], "summary": json.loads(row[2] or "{}")} if row else None

    # ---------- fix proposals (human approval gate) ----------
    def save_proposal(self, p: dict) -> None:
        self.db.execute("INSERT OR REPLACE INTO proposals (id, project, run_id, finding_id, data, status, ts) VALUES (?,?,?,?,?,'proposed',?)",
                        (p["id"], p["project"], p["run_id"], p["finding_id"], json.dumps(p, default=str), time.time()))
        self.db.commit()

    def get_proposal(self, pid: str) -> dict:
        row = self.db.execute("SELECT data, status, decided_by, decided_reason, result FROM proposals WHERE id=?", (pid,)).fetchone()
        if not row:
            raise KeyError(f"No fix proposal {pid}")
        p = json.loads(row[0])
        p.update(status=row[1], decided_by=row[2], decided_reason=row[3], result=json.loads(row[4]) if row[4] else None)
        return p

    def list_proposals(self, project: str, run_id: str | None = None) -> list[dict]:
        q, a = "SELECT id FROM proposals WHERE project=?" + (" AND run_id=?" if run_id else "") + " ORDER BY ts DESC", ((project, run_id) if run_id else (project,))
        return [self.get_proposal(r[0]) for r in self.db.execute(q, a).fetchall()]

    def decide_proposal(self, pid: str, status: str, by: str, reason: str) -> None:
        """Only a named human can approve or reject a fix; nothing is built or tested before approval."""
        if status not in {"approved", "rejected"}:
            raise ValueError("status must be approved | rejected")
        if not by.strip() or not reason.strip():
            raise ValueError("A fix can only be approved or rejected by a named human with a reason.")
        p = self.get_proposal(pid)
        self.db.execute("UPDATE proposals SET status=?, decided_by=?, decided_reason=? WHERE id=?", (status, by.strip(), reason.strip(), pid))
        self.db.commit()
        self.decide(f"fix-{pid}", p["project"], f"human:{by.strip()}", f"{status} fix {pid} ({p['package']} {p['from']} -> {p['to']})",
                    reason.strip(), rule="human-approval", confidence="")

    def save_result(self, pid: str, result: dict) -> None:
        self.db.execute("UPDATE proposals SET result=? WHERE id=?", (json.dumps(result, default=str), pid))
        self.db.commit()

    # ---------- knowledge cache ----------
    def cache_get(self, key: str, max_age_s: float = 86400):
        row = self.db.execute("SELECT value, ts FROM cache WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row and time.time() - row[1] < max_age_s else None

    def cache_put(self, key: str, value) -> None:
        self.db.execute("INSERT OR REPLACE INTO cache VALUES (?,?,?)", (key, json.dumps(value, default=str), time.time()))
        self.db.commit()
