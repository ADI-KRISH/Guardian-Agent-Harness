"""M2 dependency graph, M7 risk scoring, M16 coverage ledger."""
from __future__ import annotations

from ..agents import evidence, verifier
from ..core import Finding, RunContext

DETECTED = ["artifact:changes", "artifact:vulns", "artifact:cicd", "artifact:backdoor", "artifact:canary"]


class Graph:                                        # M2
    id, needs, provides = "M2.graph", ["artifact:snapshot"], ["artifact:graph"]

    def run(self, ctx: RunContext) -> None:
        s = ctx.snapshot_head
        nodes = [{"id": k, "scope": p["scope"], "ecosystem": p["ecosystem"]} for k, p in s["packages"].items()]
        edges = [{"from": a, "to": b} for a, bs in s["graph"].items() for b in bs]
        roots = sorted({k for v in s["roots"].values() for k in v})
        ctx.artifact("graph.json", {"nodes": nodes, "edges": edges, "direct": roots})


def evidence_problem(f: dict, head_dir) -> str:
    """Ported from GuardianAI day1 (team): verifier.verify. Evidence whose file is missing or whose line is out of range is rejected."""
    loc = f.get("location") or {}
    if not loc.get("file") or f["type"] in ("known_vulnerability", "canary_missed"):
        return ""
    p = head_dir / loc["file"]
    if not p.is_file():
        return "evidence file is missing from the scan snapshot"
    line = loc.get("line")
    if isinstance(line, int):
        n = len(p.read_text(encoding="utf-8", errors="replace").splitlines())
        if line < 1 or line > max(1, n):
            return f"evidence line {line} is outside the file ({n} lines)"
    return ""


class Scoring:                                      # M7
    """Verify evidence, merge duplicates, score with a reason, convert to the new schema, emit.

    ponytail: wraps the legacy verifier/scorer so Day-1 behaviour is unchanged; severity anchors and reachability land here later.
    """
    id, needs, provides = "M7.scoring", ["artifact:snapshot", *DETECTED], ["artifact:scored"]

    def check(self, ctx: RunContext):
        kept, rejected = [], []
        for f in ctx.legacy:
            why = evidence_problem(f, ctx.repo_path)
            (rejected if why else kept).append((f, why) if why else f)
        for f, why in rejected:
            if ctx.memory:
                ctx.memory.decide(ctx.run_id, ctx.project, "verifier-agent", f"reject {f['id']}", why, {"title": f["title"][:120]}, rule="verify-evidence")
        legacy, stats = verifier.verify(kept, ctx.repo_path, ctx.snapshot_head)
        stats["rejected_missing_evidence"] = len(rejected)
        stats["rejected_ids"] = [f["id"] for f, _ in rejected]
        return legacy, stats

    def run(self, ctx: RunContext) -> None:
        legacy, stats = self.check(ctx)
        evidence.score(legacy, ctx.snapshot_head)
        if ctx.memory:                       # M20: active, human-approved, evaluated lessons; protected rules are skipped inside apply_lessons
            evidence.apply_lessons(legacy, ctx.memory.active_lessons(ctx.project), ctx.memory, ctx.run_id, ctx.project)
        ctx.emit([Finding.from_legacy(f) for f in legacy])
        ctx.artifact("verification.json", stats)
        ctx.artifact("legacy_findings.json", legacy)   # Day-2 agents (fixer, validator) still read this shape


class Coverage:                                     # M16
    """So "no findings" never reads as "clean": state which detectors ran and which surfaces they saw."""
    id, needs, provides = "M16.coverage", ["artifact:scored"], ["artifact:coverage"]

    def run(self, ctx: RunContext) -> None:
        s = ctx.snapshot_head
        surfaces = {"lockfiles": sorted({l for p in s["packages"].values() for l in p["lockfiles"]}),
                    "workflow_steps": len(s["workflows"]), "images": len(s["images"])}
        gaps = []
        if not ctx.snapshot_base:
            gaps.append("no baseline: change detection and backdoor diff did not run")
        gaps += s["notes"] + ctx.gaps
        ctx.artifact("coverage.json", {"surfaces": surfaces, "gaps": gaps,
                                       "statement": "Absence of findings is not absence of a backdoor."})
