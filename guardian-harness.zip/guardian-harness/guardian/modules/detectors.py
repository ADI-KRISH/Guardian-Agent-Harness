"""Detector modules M1, M3, M4, M5, M6 and the M8 canary: thin plugs over the proven agent code.

Each is deterministic (no LLM) and leaves old-format findings in ctx.legacy for M7 to verify, score and convert.
Modules never import each other; they share only the RunContext.
"""
from __future__ import annotations

import hashlib

from .. import canary
from ..agents import backdoor, change, ci_container, discovery, flow, reputation, vuln
from ..agents.formats import bounded_read
from ..tools import git
from ..agents import finding
from ..core import Finding, RunContext
from ..tools import scanners


FLOW_SUFFIXES = (".py", ".js", ".ts", ".mjs", ".cjs", ".sh", ".go", ".java", ".rs")


class Inventory:                                    # M1
    id, needs, provides = "M1.inventory", [], ["artifact:snapshot"]

    def run(self, ctx: RunContext) -> None:
        ctx.snapshot_head = discovery.snapshot(ctx.repo_path)
        if ctx.base_dir:
            ctx.snapshot_base = discovery.snapshot(ctx.base_dir)
        head = ctx.snapshot_head
        ctx.artifact("inventory.json", {k: head[k] for k in ("packages", "graph", "roots", "workflows", "images", "notes", "generated_locks", "resolution", "unchecked")})
        if head.get("sbom"):
            ctx.artifact("sbom.cdx.json", head["sbom"])
            spdx = scanners.syft_sbom(ctx.repo_path, fmt="spdx-json")
            if spdx.ok and '"spdxVersion"' in spdx.stdout:
                ctx.artifact("sbom.spdx.json", spdx.stdout)
            else:
                ctx.gaps.append(f"M1 SBOM: SPDX output not produced ({spdx.stderr[-120:].strip() or 'syft failed'})")


class Change:                                       # M3
    id, needs, provides = "M3.change", ["artifact:snapshot"], ["artifact:changes"]

    def run(self, ctx: RunContext) -> None:
        if not ctx.snapshot_base:
            ctx.artifact("changes.json", {"note": "no baseline: nothing to compare"})
            return
        summary, fs = change.diff(ctx.snapshot_base, ctx.snapshot_head, ctx.config)
        # The legacy diff only checks packages added since the baseline; a lookalike already in the tree (ngy-cookie) must be found too.
        have = {f["component"] for f in fs if f["type"] == "typosquat"}
        names = {p["name"].lower() for p in ctx.snapshot_head["packages"].values()}
        for k, p in ctx.snapshot_head["packages"].items():
            sim = change.lookalike(p["name"], p["ecosystem"], names) if k not in have else None
            if sim:
                fs.append(finding("typosquat", f"'{p['name']}' looks like a typosquat of '{sim}'", component=k, detector="change-agent",
                                  change="present in tree", verified_evidence=[f"name '{p['name']}' is one edit (or only punctuation) away from popular package '{sim}'"],
                                  recommendation=f"Remove '{p['name']}'; use '{sim}' if that was intended.", extra={"similar_to": sim}))
        # Ported from GuardianAI day1 (team): detectors.changes lists changed source files too, and the comparison is labelled.
        summary["typosquat_reputation"] = reputation.apply(fs, ctx.memory, budget=0 if ctx.config.get("offline") else 60)   # an established package is not a typosquat
        ctx.legacy += fs                                       # after apply(): dropped lookalikes are no longer in fs
        if summary.get("partial"):
            ctx.partial[self.id] = summary["partial"]
        if ctx.config.get("offline") and any(f["type"] == "typosquat" for f in fs):
            ctx.gaps.append("M3 typosquat reputation: offline, so the registry was not asked whether lookalike names are established packages")
        summary["comparison"] = ctx.comparison or {"kind": "git-ref", "ref": ctx.base_ref, "trusted": False}
        summary["files"] = [{"path": p, "change": {"A": "added", "D": "removed"}.get(st, "modified")}
                            for st, p in git.changed_files(ctx.git_repo, ctx.base_ref, ctx.head_ref)
                            if ctx.git_repo and ctx.base_ref and ctx.head_ref] if ctx.git_repo else []
        ctx.artifact("changes.json", summary)


class Vulnerabilities:                              # M4
    id, needs, provides = "M4.vuln", ["artifact:snapshot"], ["artifact:vulns"]

    def run(self, ctx: RunContext) -> None:
        fs, cov = vuln.scan_all(ctx.repo_path, ctx.snapshot_head, None if (ctx.snapshot_base or {}).get("lock_errors") else ctx.snapshot_base, ctx.memory, bool(ctx.config.get("offline")))
        ctx.artifact("vuln-coverage.json", cov)
        if not cov["complete"]:
            ctx.gaps.append(f"M4 vulnerabilities: check incomplete ({cov['checked']} of {cov['total']} components checked): {cov['reason']}")
        if not cov["complete"]:
            ctx.partial[self.id] = cov["reason"]
        ctx.legacy += fs


class CiContainer:                                  # M5
    id, needs, provides = "M5.cicd", ["artifact:snapshot"], ["artifact:cicd"]

    def run(self, ctx: RunContext) -> None:
        fs, _metas = ci_container.scan(ctx.repo_path, ctx.snapshot_head, ctx.snapshot_base, ctx.config)
        ctx.legacy += fs


class Backdoor(object):                             # M6
    id, needs, provides = "M6.backdoor", ["artifact:snapshot"], ["artifact:backdoor"]

    def run(self, ctx: RunContext) -> None:
        if not (ctx.git_repo and ctx.base_ref and ctx.head_ref):
            ctx.artifact("backdoor.json", {"note": "no baseline: nothing to diff"})
            return
        fs, stats = backdoor.scan_diff(ctx.git_repo, ctx.base_ref, ctx.head_ref, ctx.repo_path, ctx.config)
        ctx.legacy += fs
        # Ported from GuardianAI day1 (team): flow.py. Bounded secret-to-network matching on the changed source files.
        flows = 0
        for status, path in git.changed_files(ctx.git_repo, ctx.base_ref, ctx.head_ref):
            if status == "D" or not path.endswith(FLOW_SUFFIXES):
                continue
            text = bounded_read(ctx.repo_path / path)
            for hit in (flow.exfiltration_flows(text) if text else []):
                flows += 1
                f = Finding(type="backdoor_signal", title=f"{path}:{hit['line']} sensitive value flows into an outbound network call (static candidate)",
                            detector="M6.flow", location={"file": path, "line": hit["line"], "snippet": hit["excerpt"][:200]},
                            evidence=[{"kind": "file_line", "ref": f"{path}:{hit['line']}: {hit['sink']}(...) receives a sensitive value ({hit['method']}; source line {hit['source_line']})"}],
                            severity="high", score=8.0, confidence="medium", verdict="confirmed",
                            score_reasons=["limited static flow analysis: a sensitive source appears inside a network call; no runtime proof"],
                            fingerprint=hashlib.sha256(f"flow|{path}|{hit['line']}".encode()).hexdigest())
                ctx.emit([f])
        stats["flow_findings"] = flows
        ctx.artifact("backdoor.json", stats)


class Canary:                                       # M8
    id, needs, provides = "M8.canary", [], ["artifact:canary"]

    def run(self, ctx: RunContext) -> None:
        results, missed = canary.run()
        ctx.legacy += missed
        failed = [r["detector"] for r in results if r.get("state") == "fail"]
        if failed:
            ctx.blocked = "A detector failed its self-check: " + ", ".join(failed) + ". Results cannot be trusted until it is fixed."
        ctx.artifact("canary.json", results)
