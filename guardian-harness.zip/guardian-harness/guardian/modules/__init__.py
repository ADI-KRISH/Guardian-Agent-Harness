"""All available modules by id. modules.yaml chooses which are enabled."""
from .analysis import Coverage, Graph, Scoring
from .dockerchecks import DockerChecks, ImageInspect
from .detectors import Backdoor, Canary, Change, CiContainer, Inventory, Vulnerabilities
from .history import GitHistory, Secrets
from .remediation import Remediation
from .report import Report
from .stretch import PackageIntel, Policy, Provenance, Reachability

AVAILABLE = {m.id: m for m in (Inventory(), Graph(), Change(), Vulnerabilities(), CiContainer(), DockerChecks(), ImageInspect(), Backdoor(), Canary(),
                               Scoring(), Coverage(), Remediation(), GitHistory(), Secrets(), Reachability(), Provenance(), PackageIntel(), Policy(), Report())}
