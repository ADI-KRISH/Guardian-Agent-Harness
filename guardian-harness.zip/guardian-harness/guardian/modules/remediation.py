"""M11 remediation planner: a fixed recipe per finding type. The LLM never writes the change, only (optionally) its explanation.

Every plan states what to do, expected risk reduction, compatibility and rollback. Vulnerability upgrades reuse the proven
version-pick rule (lowest fixed version on the same major, else the next one).
"""
from __future__ import annotations

import re

from ..agents import fixer
from ..core import RunContext

AUTO = {"known_vulnerability"}       # only these can be applied and validated automatically (M12)
ROLLBACK = "Nothing is merged or pushed by the Guardian. To undo: revert the commit on the fix branch / `git apply -R patch.diff`."


def _plan(f: dict, action: str, change: str, why: str, compat: str, auto: bool = False, rollback: str = ROLLBACK) -> dict:
    return {"finding_id": f["id"], "type": f["type"], "severity": f["risk_level"], "action": action, "change": change,
            "expected_risk_reduction": why, "compatibility": compat, "rollback": rollback, "automatic": auto, "needs_human": True,
            "advisory_ids": f.get("advisory_ids", [])}


def recipe(f: dict, report: dict, inv: dict) -> dict:
    t, comp, loc = f["type"], f.get("component", ""), (f.get("location") or {}).get("file", "")
    loc = loc or next(iter((inv.get("packages", {}).get(comp) or {}).get("lockfiles") or []), "")   # e.g. typosquat has no file of its own
    name = comp.split(":", 1)[-1].rpartition("@")[0] or comp
    if t == "known_vulnerability":
        p = fixer.propose(report, inv, f["id"])
        if p["ok"]:
            return _plan(f, "upgrade", p["change"], p["expected_risk_reduction"]["explanation"], p["compatibility_note"], True,
                         p["rollback"]) | {"proposal": p}
        return _plan(f, "replace or isolate", f"no automatic fix: {p['reason']}",
                     "removes the finding only if the package is replaced or the vulnerable feature is isolated", "human decision", False)
    if t == "typosquat":
        real = (re.search(r"popular package '([^']+)'", " ".join(f.get("verified_evidence", []))) or re.search(r"typosquat of '([^']+)'", f["title"]))
        real = real.group(1) if real else "the intended package"
        return _plan(f, "replace", f"{loc}: replace {name} with {real}; remove {name} from the manifest and lockfile",
                     "removes a likely malicious package", f"{real} is the package the name imitates; check the import names")
    if t == "integrity_change":
        return _plan(f, "block and revert", f"git checkout {report.get('base_ref') or '<baseline>'} -- {loc}  (restore the lockfile), then investigate who changed the hash",
                     "removes tampered content from the tree", "none expected: restores the baseline lockfile")
    if t in ("unpinned_action",):
        return _plan(f, "pin", f"{loc}: replace the action tag with the full commit SHA it points to today (`uses: owner/repo@<sha> # tag`)",
                     "a moved tag can no longer change what CI runs", "same code as the tag points to now")
    if t in ("untrusted_image", "unpinned_image"):
        return _plan(f, "pin image", f"{loc}: pin the base image by digest (`FROM image@sha256:...`) from a trusted registry",
                     "the image can no longer change silently", "same image content as the tag points to now")
    if t in ("backdoor_signal", "install_script", "suspicious_update"):
        return _plan(f, "remove and escalate", f"remove or pin the dependency/change at {loc or comp}; escalate to the security owner",
                     "removes code that should not be in a dependency", "may break features that rely on the package; needs human review")
    return _plan(f, "review", f"human review of {loc or comp}", "depends on the finding", "n/a")


class Remediation:
    id, needs, provides = "M11.remediation", ["artifact:scored"], ["artifact:plans"]

    def run(self, ctx: RunContext) -> None:
        legacy = ctx.artifacts.get("legacy_findings.json", [])
        inv = ctx.artifacts.get("inventory.json", {})
        report = {"run_id": ctx.run_id, "project": ctx.project, "base_ref": ctx.base_ref, "head_ref": ctx.head_ref,
                  "head_commit": {}, "findings": legacy}
        plans = [recipe(f, report, inv) for f in legacy if not f.get("suppressed_by")]
        for p in plans:
            p.pop("proposal", None)        # plans.json stays small; the proposal is rebuilt when a human asks for it
        ctx.artifact("plans.json", plans)
        crit = {p["finding_id"] for p in plans}
        missing = [f["id"] for f in legacy if f["risk_level"] == "Critical" and not f.get("suppressed_by") and f["id"] not in crit]
        assert not missing, f"Critical findings without a plan: {missing}"     # plan rule: every Critical has a plan
