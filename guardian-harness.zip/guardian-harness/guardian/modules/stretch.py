"""Stretch modules S1 (reachability), S3 (provenance), S4 (package intelligence), S5 (policy-as-code).

They plug in beside M3..M7 through the same registry and can be switched off in modules.yaml. S1/S5 run after scoring and
adjust or add findings; every adjustment adds a plain reason. Network lookups (S4) go only to the public registry and are cached.
"""
from __future__ import annotations

import hashlib
import json
import re
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from ..agents.discovery import SKIP_DIRS
from ..agents.evidence import TEST_PATH
from ..core import Finding, RunContext
from ..tools import run

LEVELS = (("critical", 8.0), ("high", 6.0), ("medium", 4.0), ("low", 0.0))


def _level(score: float) -> str:
    return next(n for n, t in LEVELS if score >= t)


# ---------------------------------------------------------------- S1 reachability
def _import_rx(eco: str, name: str) -> re.Pattern | None:
    n = re.escape(name)
    if eco == "npm":
        return re.compile(rf"""(require\(\s*|from\s+|import\s+|import\(\s*)['"]{n}(/[^'"]*)?['"]""")
    if eco == "PyPI":
        mod = re.escape(name.lower().replace("-", "_"))
        return re.compile(rf"^\s*(import|from)\s+{mod}\b", re.M)
    return None


class Reachability:                                 # S1
    id, needs, provides = "S1.reachability", ["artifact:scored"], ["artifact:reach"]

    def run(self, ctx: RunContext) -> None:
        files = [p for p in ctx.repo_path.rglob("*") if p.is_file() and p.suffix in (".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs", ".py")
                 and not any(part in SKIP_DIRS for part in p.relative_to(ctx.repo_path).parts) and p.stat().st_size < 2_000_000]
        text = {p: p.read_text(encoding="utf-8", errors="replace") for p in files}
        for f in ctx.findings:
            if f.type != "known_vulnerability" or not f.package.get("name"):
                continue
            if re.search(r"malware|malicious", f.title, re.I):     # installing it is the harm: never discount for "not imported"
                f.score_reasons.append("malicious-package advisory: not lowered for reachability")
                continue
            direct = any(len(p) == 2 for p in f.dependency_paths)
            rx = _import_rx(f.package.get("ecosystem", ""), f.package["name"])
            if rx is None:
                continue
            hit = next(((p, m) for p, t in text.items() if not TEST_PATH.search(p.relative_to(ctx.repo_path).as_posix())
                        for m in [rx.search(t)] if m), None)
            if hit:
                rel = hit[0].relative_to(ctx.repo_path).as_posix()
                line = text[hit[0]][: hit[1].start()].count("\n") + 1
                f.score_reasons.append(f"reachable: imported in {rel}:{line}")
                f.evidence.append({"kind": "file_line", "ref": f"{rel}:{line} imports {f.package['name']}"})
            elif direct:
                f.score = round(max(0.0, f.score - 1.5), 1)
                f.severity = _level(f.score)
                f.score_reasons.append("not reachable: direct dependency never imported by application source (tests excluded), score -1.5")
            else:
                f.score_reasons.append("transitive dependency: reachability depends on how its dependents use it (not lowered)")


# ---------------------------------------------------------------- S3 provenance
class Provenance:                                   # S3
    id, needs, provides = "S3.provenance", ["artifact:scored"], ["artifact:provenance"]

    def run(self, ctx: RunContext) -> None:
        imgs = ctx.snapshot_head.get("images", [])
        if imgs and ctx.config.get("require_provenance"):
            c = run("cosign", ["version"], timeout=30)
            if not c.ok:
                ctx.gaps.append("S3 provenance: cosign not installed, image signatures were not verified")
        elif imgs:
            ctx.gaps.append("S3 provenance: image signature verification is off (set require_provenance: true and install cosign)")
        if (ctx.repo_path / "node_modules").exists():
            r = run("npm", ["audit", "signatures"], cwd=ctx.repo_path, timeout=300)
            if not r.ok and "missing" in (r.stdout + r.stderr).lower():
                ctx.emit([Finding(type="provenance_missing", title="npm packages without registry signatures or provenance", detector=self.id,
                                  evidence=[{"kind": "tool_output", "ref": (r.stdout + r.stderr)[-300:]}], severity="medium", score=4.0,
                                  verdict="confirmed", confidence="medium", score_reasons=["npm audit signatures reported missing attestations"],
                                  fingerprint=hashlib.sha256(b"prov-npm").hexdigest())])
        else:
            ctx.gaps.append("S3 provenance: npm signatures need an installed tree; they are checked in the M12 sandbox, not on the host")


# ---------------------------------------------------------------- S4 package intelligence
def _registry(ctx: RunContext, name: str) -> dict | None:
    key = f"npmreg:{name}"
    if ctx.memory and (c := ctx.memory.cache_get(key, 6 * 3600)) is not None:
        return c or None
    try:
        with urllib.request.urlopen(f"https://registry.npmjs.org/{name.replace('/', '%2f')}", timeout=15) as r:
            d = json.load(r)
    except Exception:  # noqa: BLE001 - registry down or 404 is information, not a crash
        d = None
    if ctx.memory:
        ctx.memory.cache_put(key, d or {})
    return d


def _ts(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


class PackageIntel:                                 # S4
    id, needs, provides = "S4.pkgintel", ["artifact:changes"], ["artifact:pkgintel"]

    def run(self, ctx: RunContext) -> None:
        ch = ctx.artifacts.get("changes.json", {})
        names = sorted({a.split(":", 1)[-1].rpartition("@")[0] for a in ch.get("added", []) if a.startswith("npm:")})
        internal = set(ctx.config.get("internal_names", []))
        names = sorted(set(names) | {n for n in (ctx.snapshot_head["packages"][k]["name"] for k in ctx.snapshot_head["packages"]) if n in internal})
        out, now = [], datetime.now(timezone.utc)

        def add(kind: str, name: str, why: str, sev: str, score: float, ftype: str = "suspicious_update") -> None:
            out.append(Finding(type=ftype, title=f"{kind}: {name}", detector=self.id, package={"ecosystem": "npm", "name": name},
                               evidence=[{"kind": "tool_output", "ref": f"registry.npmjs.org/{name}: {why}"}], severity=sev, score=score,
                               confidence="medium", verdict="confirmed", score_reasons=[why],
                               fingerprint=hashlib.sha256(f"intel|{kind}|{name}".encode()).hexdigest()))
        for n in names[:40]:                         # budget: registry calls are cached and capped per run
            if n in internal or any(n.startswith(p) for p in ctx.config.get("internal_scopes", [])):
                if _registry(ctx, n):
                    add("dependency confusion", n, "an internal-looking name also exists on the public registry", "critical", 9.5, "unexpected_dependency")
                continue
            d = _registry(ctx, n)
            if not d:
                continue
            t = {k: v for k, v in d.get("time", {}).items() if k not in ("created", "modified")}
            if t:
                newest = max(t, key=lambda k: _ts(t[k]))
                if (now - _ts(t[newest])).days < 7:
                    add("very recent release", n, f"version {newest} was published {(now - _ts(t[newest])).days} day(s) ago", "medium", 5.0)
                days = [_ts(v).date() for v in t.values()]
                if any(days.count(x) >= 3 for x in set(days)):
                    add("several releases in one day", n, "3 or more versions published on a single day", "low", 3.0)
            vs = d.get("versions", {})
            pubs = [(v, (vs[v].get("_npmUser") or {}).get("name")) for v in sorted(vs, key=lambda k: _ts(t[k]) if k in t else now)]
            if len(pubs) >= 2 and pubs[-1][1] and pubs[-2][1] and pubs[-1][1] != pubs[-2][1] and pubs[-1][1] not in {m.get("name") for m in d.get("maintainers", [])}:
                add("publisher changed", n, f"{pubs[-1][0]} was published by {pubs[-1][1]}, not by earlier maintainers", "high", 7.0)
        if not names:
            ctx.gaps.append("S4 pkgintel: no newly added npm packages to look up")
        ctx.emit(out)


# ---------------------------------------------------------------- S5 policy
POLICY_PATH = Path(__file__).resolve().parents[2].parent / "policies" / "supply-chain.rego"


def evaluate(findings: list[dict], plans: list[dict], require_provenance: bool = False) -> list[dict]:
    """Python mirror of policies/supply-chain.rego (used when conftest is not installed). Each rule has a stable name."""
    planned = {a for p in plans for a in p.get("advisory_ids", [])}
    out = []
    for f in findings:
        t = f["type"]
        if t == "integrity_change":
            out.append({"rule": "deny_integrity_change", "finding": f["fingerprint"], "msg": f["title"]})
        elif t == "typosquat":
            out.append({"rule": "deny_typosquat", "finding": f["fingerprint"], "msg": f["title"]})
        elif t == "untrusted_image":
            out.append({"rule": "deny_unpinned_or_untrusted_image", "finding": f["fingerprint"], "msg": f["title"]})
        elif t == "artifact_mismatch":
            out.append({"rule": "deny_artifact_mismatch", "finding": f["fingerprint"], "msg": f["title"]})
        elif t == "provenance_missing" and require_provenance:
            out.append({"rule": "deny_unsigned_when_required", "finding": f["fingerprint"], "msg": f["title"]})
        elif f["severity"] == "critical" and f["fixed_versions"] and not (set(f["advisory_ids"]) & planned):
            out.append({"rule": "deny_critical_with_fix_but_no_plan", "finding": f["fingerprint"], "msg": f["title"]})
    return out


class Policy:                                       # S5
    id, needs, provides = "S5.policy", ["artifact:scored", "artifact:plans"], ["artifact:policy"]

    def run(self, ctx: RunContext) -> None:
        fs = [f.to_dict() for f in ctx.findings if f.type != "policy_violation"]
        plans = ctx.artifacts.get("plans.json", [])
        c = run("conftest", ["--version"], timeout=30)
        if c.ok:                                      # real OPA path: same rules, evaluated by conftest
            ctx.artifact("policy-input.json", {"findings": fs, "plans": plans})
            r = run("conftest", ["test", str(ctx.out_dir / "policy-input.json"), "-p", str(POLICY_PATH.parent), "-o", "json"], timeout=120, ok_codes=(0, 1))
            res = [{"rule": x["metadata"].get("rule", "policy"), "finding": x["metadata"].get("finding", ""), "msg": x["msg"]}
                   for blk in (json.loads(r.stdout) if r.stdout.strip() else []) for x in blk.get("failures", [])]
        else:
            ctx.gaps.append("S5 policy: conftest not installed, evaluated with the built-in mirror of policies/supply-chain.rego")
            res = evaluate(fs, plans, bool(ctx.config.get("require_provenance")))
        ctx.emit([Finding(type="policy_violation", title=f"policy {v['rule']}: {v['msg'][:80]}", detector=self.id, severity="high", score=8.0,
                          confidence="high", verdict="confirmed", evidence=[{"kind": "tool_output", "ref": f"policy rule {v['rule']} on {v['finding'][:12]}"}],
                          score_reasons=[f"blocked by rule {v['rule']}"], fingerprint=hashlib.sha256(f"pol|{v['rule']}|{v['finding']}".encode()).hexdigest())
                  for v in res])
        ctx.artifact("policy.json", res)
