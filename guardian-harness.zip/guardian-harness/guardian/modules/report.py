"""M10 supply-chain report: report.json (schema 1.1), report.md, report.sarif. Sections follow the slide order."""
from __future__ import annotations

import html
import json

from ..core import RunContext

SARIF_LEVEL = {"critical": "error", "high": "error", "medium": "warning", "low": "note", "unknown": "note"}


def sarif(findings: list[dict]) -> dict:
    rules = {f["type"]: {"id": f["type"], "name": f["type"], "shortDescription": {"text": f["type"].replace("_", " ")}} for f in findings}
    results = []
    for f in findings:
        loc = f["location"] or {}
        pkg = f["package"] or {}
        r = {"ruleId": f["type"], "level": SARIF_LEVEL[f["severity"]], "message": {"text": f["title"]},
             "partialFingerprints": {"guardian/v1": f["fingerprint"]},
             "properties": {"score": f["score"], "confidence": f["confidence"], "score_reasons": f["score_reasons"],
                            "package": f"{pkg.get('name', '')}@{pkg.get('version', '')}".strip("@"), "verdict": f["verdict"]}}
        if loc.get("file"):
            r["locations"] = [{"physicalLocation": {"artifactLocation": {"uri": loc["file"]},
                                                    "region": {"startLine": int(loc.get("line") or 1)}}}]
        results.append(r)
    return {"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "Supply Chain Guardian", "rules": list(rules.values())}}, "results": results}]}


def markdown(rep: dict) -> str:
    s = rep["summary"]
    out = ["# Supply Chain Guardian report", "",
                              f"Compared `{rep['base_ref'] or 'no baseline'}` -> `{rep['head_ref']}`.", "",
                              "## What is in it", f"{s['packages']} packages ({s['direct']} direct), {s['workflow_steps']} workflow steps, {s['images']} base images.", "",
                              "## What changed",
                              (f"{rep['changes'].get('added_count', 0)} added, {rep['changes'].get('removed_count', 0)} removed, "
                               f"{rep['changes'].get('updated_count', 0)} updated.") if "added_count" in rep["changes"] else "No baseline.", "",
                              f"## What is risky ({s['findings']} findings: {s['by_severity']})"]
    for f in rep["findings"]:
        p = f["package"]
        out += ["", f"### [{f['severity'].upper()} {f['score']}] {f['title']}",
                f"- type `{f['type']}`, confidence {f['confidence']}, verdict {f['verdict']}, detector {f['detector']}",
                *(f"- evidence: {e['ref']}" for e in f["evidence"]),
                *(f"- path: {' > '.join(p_)}" for p_ in f["dependency_paths"][:2]),
                f"- why this score: {'; '.join(f['score_reasons'])}" if f["score_reasons"] else "",
                f"- fixed in: {', '.join(f['fixed_versions'])}" if f["fixed_versions"] else ""]
    out += ["", "## Self-check (canary)", *(f"- {'PASS' if c['caught'] else 'FAIL'} {c['detector']}: {c['detail']}" for c in rep["canary"]),
            "", "## Coverage and limits", *(f"- {g}" for g in rep["coverage"].get("gaps", [])), f"- {rep['coverage'].get('statement', '')}"]
    return "\n".join(out)


CSS = ("body{font:15px/1.5 system-ui,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#1a1a1a;background:#fff}"
       "@media(prefers-color-scheme:dark){body{color:#e8e8e8;background:#16181c}.card{border-color:#333}}"
       ".card{border:1px solid #ddd;border-radius:8px;padding:.6rem 1rem;margin:.6rem 0}.critical{border-left:6px solid #c0392b}"
       ".high{border-left:6px solid #e67e22}.medium{border-left:6px solid #d4ac0d}.low{border-left:6px solid #7f8c8d}"
       ".ok{color:#1e8449}.bad{color:#c0392b}code{font-size:13px}small{opacity:.75}")


def html_report(rep: dict) -> str:
    e, s = html.escape, rep["summary"]
    ch = rep["changes"]
    cards = []
    for f in rep["findings"]:
        why = "; ".join(f["score_reasons"])
        cards.append(f'<div class="card {f["severity"]}"><b>[{f["severity"].upper()} {f["score"]}]</b> {e(f["title"])}<br>'
                     f'<small>{e(f["type"])} | confidence {f["confidence"]} | verdict {f["verdict"]} | {e(f["detector"])}</small>'
                     + "".join(f"<br>evidence: <code>{e(x['ref'])}</code>" for x in f["evidence"][:4])
                     + "".join(f"<br>path: <code>{e(' > '.join(p))}</code>" for p in f["dependency_paths"][:1])
                     + (f"<br>why this score: {e(why)}" if why else "")
                     + (f"<br>fixed in: {e(', '.join(f['fixed_versions']))}" if f["fixed_versions"] else "")
                     + (f"<br><em>AI note (inference, not evidence): {e(f['ai_inference']['text'])}</em>" if f.get("ai_inference") else "") + "</div>")
    canary = "".join(f'<li class="{"ok" if c["caught"] else "bad"}">{"&#10003;" if c["caught"] else "&#10007;"} {e(c["detector"])}: {e(c["detail"])}</li>' for c in rep["canary"])
    gaps = "".join(f"<li>{e(g)}</li>" for g in rep["coverage"].get("gaps", []))
    inc = '<p class="bad"><b>INCOMPLETE: a detector failed its self-check, so this report may be missing findings.</b></p>' if rep["incomplete"] else ""
    return (f'<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Supply Chain Guardian report</title><style>{CSS}</style>'
            f'<h1>Supply Chain Guardian report</h1><p>Compared <code>{e(str(rep["base_ref"] or "no baseline"))}</code> to <code>{e(str(rep["head_ref"]))}</code></p>{inc}'
            f'<h2>What is in it</h2><p>{s["packages"]} packages ({s["direct"]} direct), {s["workflow_steps"]} workflow steps, {s["images"]} base images.</p>'
            f'<h2>What changed</h2><p>{ch.get("added_count", 0)} added, {ch.get("removed_count", 0)} removed, {ch.get("updated_count", 0)} updated.</p>'
            f'<h2>What is risky ({s["findings"]} findings)</h2><p>{e(str(s["by_severity"]))}</p>{"".join(cards)}'
            f'<h2>Self-check (canary)</h2><ul>{canary}</ul><h2>Coverage and limits</h2><ul>{gaps}</ul>'
            f'<p><small>{e(rep["coverage"].get("statement", ""))}</small></p>')


class Report:
    id, needs, provides = "M10.report", ["artifact:scored", "artifact:coverage", "artifact:graph"], ["artifact:report"]

    def run(self, ctx: RunContext) -> None:
        fs = [f.to_dict() for f in sorted(ctx.findings, key=lambda f: -f.score)]
        head = ctx.snapshot_head
        by = {lvl: sum(1 for f in fs if f["severity"] == lvl and f["verdict"] != "needs_validation") for lvl in ("critical", "high", "medium", "low", "unknown")}
        by["needs_validation"] = sum(1 for f in fs if f["verdict"] == "needs_validation")
        canary = ctx.artifacts.get("canary.json", [])
        rep = {"schema": "1.1", "base_ref": ctx.base_ref, "head_ref": ctx.head_ref,
               "summary": {"packages": len(head["packages"]), "direct": len({k for v in head["roots"].values() for k in v}),
                           "workflow_steps": len(head["workflows"]), "images": len(head["images"]),
                           "findings": len(fs), "by_severity": by},
               "changes": ctx.artifacts.get("changes.json", {}), "findings": fs, "canary": canary,
               "incomplete": any(c.get("state", "pass" if c["caught"] else "fail") != "pass" for c in canary),
               "blocked": ctx.blocked, "comparison": ctx.comparison,     # a failed canary makes the whole run Incomplete
               "coverage": ctx.artifacts.get("coverage.json", {})}
        ctx.artifact("report.json", rep)
        ctx.artifact("report.sarif", sarif(fs))
        ctx.artifact("report.md", markdown(rep))
        ctx.artifact("report.html", html_report(rep))
