"""M12 validation gate and M13 human approval.

propose -> (named human approves) -> validate in a no-network container -> rescan -> Verified only if every rule holds.
The sandbox work is the proven validator agent; this module adds the plan's stricter verdict rules and the approval record.
"""
from __future__ import annotations

import json
import re
import time
from datetime import date, timedelta
from pathlib import Path

from .. import config, remediate
from ..agents import fixer, validator
from ..tools import scanners


def _load(out_dir: Path) -> tuple[dict, dict]:
    return (json.loads((out_dir / "legacy_report.json").read_text(encoding="utf-8")),
            json.loads((out_dir / "inventory.json").read_text(encoding="utf-8")))


def propose(mem, out_dir: Path, finding_id: str, log=print) -> dict:
    report, inv = _load(out_dir)
    p = fixer.propose(report, inv, finding_id)
    if not p["ok"]:
        mem.decide(f"fix-{finding_id}", report["project"], "fix-agent", f"no automatic fix for {finding_id}", p["reason"], rule="fix-proposal")
        return p
    p["out_dir"] = str(out_dir)
    mem.save_proposal(p)
    mem.decide(f"fix-{p['id']}", p["project"], "fix-agent", f"propose {p['change']}", p["expected_risk_reduction"]["explanation"],
               {"finding": finding_id}, rule="fix-proposal")
    log(f"  [fix-agent] {p['id']}: {p['change']}")
    return p


# ---------- M13 approval ----------
def approve(mem, pid: str, by: str, reason: str) -> None:
    mem.decide_proposal(pid, "approved", by, reason)      # raises unless a named human gives a reason


def reject(mem, pid: str, by: str, reason: str, days: int = 30) -> dict:
    """Rejected -> accepted risk with an expiry, recorded next to the run."""
    mem.decide_proposal(pid, "rejected", by, reason)
    p = mem.get_proposal(pid)
    rec = {"finding": p["finding_id"], "status": "accepted-risk", "by": by, "reason": reason,
           "expires": (date.today() + timedelta(days=days)).isoformat()}
    f = Path(p["out_dir"]) / "decisions.json"
    cur = json.loads(f.read_text(encoding="utf-8")) if f.exists() else []
    f.write_text(json.dumps(cur + [rec], indent=2), encoding="utf-8")
    return rec


def vex_not_affected(out_dir: Path, finding: dict, by: str, reason: str) -> Path:
    """An accepted 'not affected' decision also becomes an OpenVEX statement so other tools honour it."""
    pkg = finding.get("component", "")
    doc = {"@context": "https://openvex.dev/ns/v0.2.0", "@id": f"https://guardian.local/vex/{finding['id']}", "author": by,
           "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "version": 1,
           "statements": [{"vulnerability": {"name": (finding.get("advisory_ids") or [finding["id"]])[0]},
                           "products": [{"@id": f"pkg:{pkg}"}], "status": "not_affected",
                           "justification": "vulnerable_code_not_in_execute_path", "impact_statement": reason}]}
    p = out_dir / f"openvex-{finding['id']}.json"
    p.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return p


# ---------- M12 validation ----------
def gate(res: dict, canary_incomplete: bool, docker_ran: bool) -> tuple[str, str]:
    """The plan's verdict rules on top of the validator's own: never Verified without the container, nor with a failed canary."""
    v, why = res["verdict"], res["verdict_reason"]
    if v != "not-verified" and not docker_ran:
        return "not-verified", "no container runtime: nothing was run in the sandbox"
    if v != "not-verified" and canary_incomplete:
        return "not-verified", "a canary failed, so this run is Incomplete and cannot be trusted as Verified"
    if v != "not-verified" and res["after"]["count"] >= res["before"]["count"]:
        return "not-verified", "no improvement: the finding count did not go down"
    if v != "not-verified" and res.get("introduced"):
        return "verified-with-gaps", why + f"; {len(res['introduced'])} other finding(s) are new or still present, review them"
    return v, why


def validate(mem, pid: str, test_cmd: str = "", log=print) -> dict:
    p = mem.get_proposal(pid)
    if p["status"] != "approved" or not p.get("decided_by"):
        raise PermissionError(f"Fix {pid} is '{p['status']}': it must be approved by a named human before anything is built or tested.")
    out_dir = Path(p["out_dir"])
    report, inv = _load(out_dir)
    src = report.get("source", "")
    repo = Path(src).resolve() if src and Path(src).exists() else config.WORKSPACE / "repos" / p["project"]
    rdir = out_dir / f"remediation-{pid}"
    res = validator.validate(p, repo, report, inv, mem, rdir, test_cmd, log)
    docker_ran = any(s["name"] == "docker build" and s["status"] == "pass" for s in res["steps"])
    canary_bad = bool(json.loads((out_dir / "report.json").read_text(encoding="utf-8")).get("incomplete")) if (out_dir / "report.json").exists() else False
    res["verdict"], res["verdict_reason"] = gate(res, canary_bad, docker_ran) if "before" in res else (res["verdict"], res["verdict_reason"])
    (rdir / "sbom.before.cdx.json").write_text((out_dir / "sbom.cdx.json").read_text(encoding="utf-8") if (out_dir / "sbom.cdx.json").exists() else "{}", encoding="utf-8")
    res.update(report_dir=str(rdir), approval={"by": p["decided_by"], "reason": p["decided_reason"]}, decisions=mem.decisions(f"fix-{pid}"))
    mem.save_result(pid, res)
    remediate.write_report(res, rdir)
    (rdir / "pr-body.md").write_text(pr_body(p, res), encoding="utf-8")
    return res


def pr_body(p: dict, res: dict) -> str:
    """S2: everything a reviewer needs in the pull request."""
    b, a = res.get("before", {}), res.get("after", {})
    return "\n".join([
        f"## {p['change']}", "", f"**Finding:** {p['finding_id']} ({', '.join(p.get('advisories', [])[:4])})",
        f"**Why:** {p['expected_risk_reduction']['explanation']}",
        f"**Validation:** {res['verdict'].upper()}: {res['verdict_reason']}",
        f"**Before / after:** {b.get('count', '?')} -> {a.get('count', '?')} known vulnerabilities; "
        f"packages {b.get('packages', '?')} -> {a.get('packages', '?')}",
        f"**Compatibility:** {p['compatibility_note']}",
        f"**Rollback:** {p['rollback']}",
        f"**Approved by:** {res['approval']['by']}: {res['approval']['reason']}",
        "", "SBOMs: `sbom.before.cdx.json`, `sbom.after.cdx.json`. Nothing is merged automatically.", ""])
