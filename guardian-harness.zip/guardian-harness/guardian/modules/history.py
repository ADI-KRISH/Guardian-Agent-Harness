"""M17 git history and M18 secrets. Both read git only; nothing from the repo is executed.

M17 flags what the diff alone cannot show: who changed what. M18 finds credentials in added lines, always masked
(only type, file, line and a hash are kept, never the value).
"""
from __future__ import annotations

import hashlib
import json
import re

from ..core import Finding, RunContext
from ..tools import run

SENSITIVE = re.compile(r"(^|/)(\.github/|Dockerfile|docker-compose|package(-lock)?\.json|yarn\.lock|pnpm-lock|requirements.*\.txt|setup\.py|"
                       r"pyproject\.toml|Makefile|.*auth.*|.*login.*|\.npmrc)", re.I)
# A first-time contributor matters on files that decide what runs or who gets in: CI, build, lockfiles, auth. Demo exploits and tests do not count.
FIRST_TIME = re.compile(r"(^|/)(\.github/(workflows|actions)/.*|Jenkinsfile|Dockerfile[^/]*|docker-compose[^/]*|Makefile|setup\.py|pyproject\.toml|requirements[^/]*\.txt|"
                        r"package(-lock)?\.json|yarn\.lock|pnpm-lock\.yaml|\.npmrc|[^/]*(auth|login)[^/]*)$", re.I)
NOT_SENSITIVE = re.compile(r"(^|/)(exploits?|tests?[^/]*|__tests__|specs?|e2e|fixtures?)/", re.I)
PICKAXE = r"eval\(|child_process|base64|discord(app)?\.com/api/webhooks|hooks\.slack\.com|\b[0-9]{1,3}(\.[0-9]{1,3}){3}\b"


def _git(ctx: RunContext, *args: str) -> str:
    return run("git", ["-C", str(ctx.git_repo), *args], timeout=300).stdout


class GitHistory:                                   # M17
    id, needs, provides = "M17.history", ["artifact:snapshot"], ["artifact:history"]

    def run(self, ctx: RunContext) -> None:
        if not (ctx.git_repo and ctx.base_ref and ctx.head_ref):
            ctx.gaps.append("M17 git history: no baseline, so no commits to inspect")
            return
        rng = f"{ctx.base_ref}..{ctx.head_ref}"
        known = set(_git(ctx, "log", ctx.base_ref, "--format=%ae").split())
        base_total = max(1, len(_git(ctx, "log", ctx.base_ref, "--format=%H", "-n", "200").split()))
        base_unsigned = _git(ctx, "log", ctx.base_ref, "--format=%G?", "-n", "200").split().count("N")
        usually_signed = base_unsigned / base_total < 0.5
        out = []
        newcomers: dict[str, list] = {}                # author email -> [(sha, subject, files)], one finding per person

        def add(sha: str, subj: str, kind: str, why: str, sev: str, score: float) -> None:
            out.append(Finding(type="history_anomaly", title=f"{kind}: {subj[:70]} ({sha[:8]})", detector=self.id,
                               location={"file": f"commit {sha[:12]}"}, evidence=[{"kind": "tool_output", "ref": f"git log {rng}: {sha[:12]} {why}"}],
                               severity=sev, score=score, confidence="medium", verdict="confirmed",
                               score_reasons=[why], fingerprint=hashlib.sha256(f"hist|{kind}|{sha}".encode()).hexdigest()))

        for line in _git(ctx, "log", rng, "--format=%H\x1f%an\x1f%ae\x1f%cn\x1f%ce\x1f%G?\x1f%s").splitlines():
            sha, an, ae, cn, ce, sig, subj = (line.split("\x1f") + [""] * 7)[:7]
            files = _git(ctx, "show", "--name-only", "--format=", sha).split()
            touched = [f for f in files if SENSITIVE.search(f)]
            if ae and ce and ae != ce and cn.lower() != "github":
                add(sha, subj, "author and committer differ", f"author {an} <{ae}> but committer {cn} <{ce}>", "low", 3.0)
            if usually_signed and sig == "N":
                add(sha, subj, "unsigned commit in a signed repo", "most earlier commits are signed, this one is not", "medium", 5.0)
            hot = [f for f in files if FIRST_TIME.search(f) and not NOT_SENSITIVE.search(f)]
            if ae not in known and hot:
                newcomers.setdefault(ae, []).append((sha, subj, hot))
            if len(files) > 40:
                add(sha, subj, "large mixed commit", f"{len(files)} files in one commit", "low", 3.0)
        for ae, commits in newcomers.items():
            files = sorted({f for _, _, fs in commits for f in fs})
            add(commits[0][0], commits[0][1], f"first-time contributor changed CI, build, lockfile or auth files ({len(commits)} commit(s))",
                f"new author {ae} changed {', '.join(files[:4])}" + (f" and {len(files) - 4} more" if len(files) > 4 else ""), "medium", 5.0)
        for sha_subj in _git(ctx, "log", rng, f"-G{PICKAXE}", "--format=%H\x1f%s").splitlines():
            sha, _, subj = sha_subj.partition("\x1f")
            add(sha, subj, "commit adds eval/exec/base64/webhook/IP", f"pickaxe -G matched {PICKAXE[:40]}...", "medium", 5.0)

        # tags moved or re-pointed between runs (tj-actions pattern): compare stored tag SHAs
        tags = dict(l.split(" ", 1)[::-1] for l in _git(ctx, "for-each-ref", "refs/tags", "--format=%(objectname) %(refname:short)").splitlines() if " " in l)
        key = f"tags:{ctx.project}"
        old = ctx.memory.cache_get(key, max_age_s=10**9) if ctx.memory else None
        for t, sha in tags.items():
            if old and t in old and old[t] != sha:
                out.append(Finding(type="history_anomaly", title=f"tag {t} was moved", detector=self.id, location={"file": f"tag {t}"},
                                   evidence=[{"kind": "tool_output", "ref": f"tag {t}: {old[t][:12]} -> {sha[:12]}"}], severity="critical", score=9.0,
                                   confidence="high", verdict="confirmed", score_reasons=["a moved release tag changes what consumers get"],
                                   fingerprint=hashlib.sha256(f"tagmove|{t}|{sha}".encode()).hexdigest()))
        if ctx.memory:
            ctx.memory.cache_put(key, tags)
        ctx.emit(out)


SECRET_PATTERNS = {
    "aws-access-key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "private-key": re.compile(r"-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "github-token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"),
    "slack-token": re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"),
    "generic-api-key": re.compile(r"""(?i)\b(api[_-]?key|secret|passwd|password|token)\b["']?\s*[:=]\s*["'][A-Za-z0-9/+_\-]{20,}["']"""),
}


class Secrets:                                      # M18
    id, needs, provides = "M18.secrets", ["artifact:snapshot"], ["artifact:secrets"]

    def run(self, ctx: RunContext) -> None:
        if not ctx.git_repo:
            return
        g = run("gitleaks", ["version"], timeout=30)
        if not g.ok:
            ctx.gaps.append("M18 secrets: gitleaks not installed, used built-in patterns on added lines only (no history or image layers)")
        rng = f"{ctx.base_ref}..{ctx.head_ref}" if ctx.base_ref and ctx.head_ref else (ctx.head_ref or "HEAD")
        patch = _git(ctx, "log", "-p", "-U0", "--format=commit %H", rng)
        sha, file, line, out = "", "", 0, []
        for l in patch.splitlines():
            if l.startswith("commit "):
                sha = l[7:19]
            elif l.startswith("+++ b/"):
                file = l[6:]
            elif l.startswith("@@"):
                m = re.search(r"\+(\d+)", l)
                line = int(m.group(1)) - 1 if m else 0
            elif l.startswith("+") and not l.startswith("+++"):
                line += 1
                for kind, rx in SECRET_PATTERNS.items():
                    m = rx.search(l)
                    if m:
                        h = hashlib.sha256(m.group(0).encode()).hexdigest()[:12]
                        out.append(Finding(
                            type="secret_exposed", title=f"possible {kind} in {file}:{line} (value masked)", detector=self.id,
                            location={"file": file, "line": line, "snippet": "<masked>"},
                            evidence=[{"kind": "file_line", "ref": f"{file}:{line} matches {kind}; sha256 prefix {h}; commit {sha}"}],
                            severity="high", score=7.5, confidence="medium", verdict="needs_validation",
                            missing_fact="the secret has not been checked against its provider, so it is not marked Critical",
                            score_reasons=["credential pattern in an added line", "only verified secrets are Critical"],
                            fingerprint=hashlib.sha256(f"secret|{kind}|{file}|{h}".encode()).hexdigest()))
        ctx.emit(out)
