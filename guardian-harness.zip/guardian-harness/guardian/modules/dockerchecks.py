"""M5 (extension): Dockerfile, compose and workflow checklist, written as plain rules because hadolint and trivy are not bundled.

Read-only text rules over files tracked in the head checkout. Each hit is a finding with file:line evidence; nothing is executed.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from ..agents.discovery import SKIP_DIRS
from ..core import Finding, RunContext

SECRET_NAME = re.compile(r"(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY)", re.I)
INJECTABLE = re.compile(r"\$\{\{\s*github\.(event\.(issue|pull_request|comment|review|head_commit|commits|pages|discussion)|head_ref)[^}]*\}\}")

# (rule id, severity, score, message)
DOCKER_RULES = {
    "no-user": ("medium", 5.0, "no USER instruction: the container runs as root"),
    "pipe-to-shell": ("high", 7.0, "downloads and pipes to a shell (curl | sh)"),
    "add-url": ("medium", 5.0, "ADD from a URL: contents are not verified"),
    "secret-in-env": ("high", 7.5, "secret-looking value baked into ENV/ARG (kept in image layers)"),
    "latest-tag": ("medium", 4.5, "base image uses :latest or no tag"),
    "chmod-777": ("medium", 5.0, "chmod 777 makes files world-writable"),
    "copy-all-no-dockerignore": ("low", 3.0, "COPY . . without a .dockerignore can ship .git and secrets"),
    "debug-port": ("low", 3.0, "debug or remote-access port exposed"),
}
COMPOSE_RULES = {
    "privileged": ("critical", 8.5, "privileged container: full host access"),
    "docker-sock": ("critical", 8.5, "mounts docker.sock: container can control the host"),
    "host-network": ("high", 7.0, "host network namespace"),
    "host-pid-ipc": ("high", 7.0, "host PID or IPC namespace"),
    "host-root-mount": ("high", 7.5, "mounts the host root or a sensitive host path"),
}
WORKFLOW_RULES = {
    "prt-checkout": ("critical", 9.0, "pull_request_target checks out the pull request's code: untrusted code runs with secrets"),
    "expression-injection": ("high", 8.0, "untrusted ${{ github.event.* }} used inside run: (script injection)"),
    "write-all": ("high", 7.0, "permissions: write-all gives the token every scope"),
}


def _tracked(root: Path, pred) -> list[Path]:
    return [p for p in root.rglob("*") if p.is_file() and pred(p) and not any(part in SKIP_DIRS for part in p.relative_to(root).parts)]


def check_dockerfile(text: str, has_dockerignore: bool) -> list[tuple[str, int]]:
    hits, last_user, froms = [], None, 0
    for n, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        up = line.upper()
        if up.startswith("FROM "):
            froms += 1
            last_user = None
            img = line.split()[1] if len(line.split()) > 1 else ""
            if img.lower() != "scratch" and not img.startswith("$") and (img.endswith(":latest") or (":" not in img.split("/")[-1] and "@" not in img)):
                hits.append(("latest-tag", n))
        if up.startswith("USER "):
            last_user = line.split()[1] if len(line.split()) > 1 else None
        if re.search(r"(curl|wget)\b[^|\n]*\|\s*(sudo\s+)?(ba)?sh\b", line):
            hits.append(("pipe-to-shell", n))
        if re.match(r"ADD\s+https?://", line, re.I):
            hits.append(("add-url", n))
        m = re.match(r"(ENV|ARG)\s+([A-Za-z0-9_]+)(?:\s*=\s*|\s+)(\S+)", line, re.I)
        if m and SECRET_NAME.search(m.group(2)) and m.group(3).strip("\"'") not in ("", "''", '""'):
            hits.append(("secret-in-env", n))
        if re.search(r"chmod\s+(-R\s+)?0?777", line):
            hits.append(("chmod-777", n))
        if re.match(r"COPY\s+\.\s+\.", line, re.I) and not has_dockerignore:
            hits.append(("copy-all-no-dockerignore", n))
        if up.startswith("EXPOSE ") and re.search(r"\b(22|23|3389|5005|5858|9229)\b", line):
            hits.append(("debug-port", n))
    if froms and last_user in (None, "root", "0"):
        hits.append(("no-user", max(1, text.count("\n"))))
    return hits


def check_compose(text: str) -> list[tuple[str, int]]:
    hits = []
    for n, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if re.match(r"privileged:\s*true", s):
            hits.append(("privileged", n))
        if "docker.sock" in s:
            hits.append(("docker-sock", n))
        if re.match(r"network_mode:\s*[\"']?host", s):
            hits.append(("host-network", n))
        if re.match(r"(pid|ipc):\s*[\"']?host", s):
            hits.append(("host-pid-ipc", n))
        if re.match(r"-\s*[\"']?(/|/etc|/root|/home|/var/run)[\"']?\s*:", s):
            hits.append(("host-root-mount", n))
    return hits


def check_workflow(text: str) -> list[tuple[str, int]]:
    hits, lines = [], text.splitlines()
    prt = bool(re.search(r"^\s*(on:\s*)?.*\bpull_request_target\b", text, re.M))
    for n, line in enumerate(lines, 1):
        if re.match(r"\s*permissions:\s*write-all", line):
            hits.append(("write-all", n))
        if prt and re.search(r"ref:\s*\$\{\{\s*github\.(event\.pull_request\.head\.(sha|ref)|head_ref)", line):
            hits.append(("prt-checkout", n))
        if re.search(r"^\s*-?\s*run:", line) or (n > 1 and re.match(r"\s{6,}\S", line) and any(re.match(r"\s*-?\s*run:\s*[|>]", lines[k]) for k in range(max(0, n - 12), n - 1))):
            if INJECTABLE.search(line):
                hits.append(("expression-injection", n))
    return hits


class DockerChecks:
    id, needs, provides = "M5.dockerfile", ["artifact:snapshot"], ["artifact:dockerchecks"]

    def run(self, ctx: RunContext) -> None:
        root, out = ctx.repo_path, []

        def add(kind: str, table: dict, rule: str, rel: str, line: int, text: str) -> None:
            sev, score, msg = table[rule]
            snippet = text.splitlines()[line - 1].strip()[:120] if 0 < line <= len(text.splitlines()) else ""
            out.append(Finding(type=kind, title=f"{rel}:{line} {msg}", detector=self.id, location={"file": rel, "line": line, "snippet": snippet},
                               evidence=[{"kind": "file_line", "ref": f"{rel}:{line}: {snippet}"}], severity=sev, score=score, confidence="high",
                               verdict="confirmed", score_reasons=[f"rule {rule}"],
                               fingerprint=hashlib.sha256(f"{kind}|{rule}|{rel}|{line}".encode()).hexdigest()))
        for p in _tracked(root, lambda p: p.name.lower().startswith("dockerfile") or p.name.lower().endswith(".dockerfile")):
            t, rel = p.read_text(encoding="utf-8", errors="replace"), p.relative_to(root).as_posix()
            for rule, n in check_dockerfile(t, (p.parent / ".dockerignore").exists()):
                add("dockerfile_issue", DOCKER_RULES, rule, rel, n, t)
        for p in _tracked(root, lambda p: re.match(r"(docker-)?compose.*\.ya?ml$", p.name, re.I)):
            t, rel = p.read_text(encoding="utf-8", errors="replace"), p.relative_to(root).as_posix()
            for rule, n in check_compose(t):
                add("dockerfile_issue", COMPOSE_RULES, rule, rel, n, t)
        for p in _tracked(root, lambda p: p.suffix in (".yml", ".yaml") and ".github/workflows" in p.as_posix()):
            t, rel = p.read_text(encoding="utf-8", errors="replace"), p.relative_to(root).as_posix()
            for rule, n in check_workflow(t):
                add("workflow_issue", WORKFLOW_RULES, rule, rel, n, t)
        ctx.emit(out)


class ImageInspect:                                 # M5 images (ported from GuardianAI day1: containers.py)
    id, needs, provides = "M5.images", ["artifact:snapshot"], ["artifact:images"]

    def run(self, ctx: RunContext) -> None:
        from ..agents import containers
        findings, info = containers.inspect(ctx.repo_path, bool(ctx.config.get("scan_images")), bool(ctx.config.get("offline")), self.id)
        ctx.artifact("images.json", info)
        ctx.emit(findings)
        if not info["requested"]:
            ctx.gaps.append("M5 images: image CVE scanning was not requested (digest pins and root user were still checked)")
        elif info["image_scanner"] == "not installed":
            ctx.gaps.append("M5 images: Not run: Trivy is not installed, so image CVEs were not checked")
        ctx.gaps.extend(info["warnings"])
