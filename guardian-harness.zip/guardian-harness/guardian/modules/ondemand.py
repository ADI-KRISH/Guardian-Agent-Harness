"""On-demand stretch tools: S6 monitoring, S7 artifact diff, S8 behaviour check. Run by CLI (or a 0security Sentinel), not per scan.

S6 re-checks a stored SBOM against today's advisories without touching code. S7 compares the published npm tarball with the
source tree. S8 runs an install under strace in the sandbox with no network. None of them executes package code on the host.
"""
from __future__ import annotations

import json
import re
import shutil
import tarfile
import tempfile
from pathlib import Path

from ..tools import run, scanners

DOCS = re.compile(r"(^|/)(README|LICENSE|CHANGELOG|HISTORY|NOTICE|AUTHORS)", re.I)
BUILT = re.compile(r"(^|/)(dist|lib|build|esm|cjs|umd|types|typings|bin)/|\.(d\.ts|map|min\.js)$", re.I)


# ---------------------------------------------------------------- S6
def monitor(out_dir: Path) -> dict:
    """Re-query advisories for the stored SBOM. New advisories since the scan are reported; findings are not rewritten."""
    out_dir = Path(out_dir)
    sbom = out_dir / "sbom.cdx.json"
    if not sbom.exists():
        return {"ok": False, "reason": "no stored SBOM (run a scan first)"}
    r = run("osv-scanner", ["scan", "--sbom", str(sbom), "--format", "json"], timeout=600, ok_codes=(0, 1))
    data = r.json() or {}
    now = {(p["package"]["name"], p["package"]["version"], v["id"]) for res in data.get("results", []) for p in res.get("packages", [])
           for v in p.get("vulnerabilities", [])}
    seen = {(f["component"].split(":", 1)[-1].rpartition("@")[0], f["component"].rpartition("@")[2], a)
            for f in json.loads((out_dir / "legacy_findings.json").read_text(encoding="utf-8")) if f["type"] == "known_vulnerability"
            for a in f.get("advisory_ids", [])}
    new = sorted(now - seen)
    res = {"ok": r.ok or r.returncode == 1, "checked_sbom": str(sbom), "known_now": len(now), "new_advisories": [list(x) for x in new]}
    (out_dir / "monitor.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
    return res


# ---------------------------------------------------------------- S7
def _safe_extract(tar: tarfile.TarFile, dest: Path) -> None:
    """No symlinks, hard links, devices or paths that leave dest: a hostile tarball cannot write outside."""
    for m in tar.getmembers():
        p = (dest / m.name).resolve()
        if not m.isfile() and not m.isdir():
            continue
        if dest.resolve() not in p.parents and p != dest.resolve():
            raise ValueError(f"unsafe path in tarball: {m.name}")
        tar.extract(m, dest, filter="data")


def artifact_diff(spec: str, source_dir: Path) -> dict:
    """spec = 'name@version'. Files only in the published package (not docs, not build output) are artifact_mismatch candidates."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        r = run("npm", ["pack", spec, "--ignore-scripts", "--silent", "--pack-destination", str(td)], timeout=300)
        tgz = next(td.glob("*.tgz"), None)
        if not r.ok or not tgz:
            return {"ok": False, "reason": f"npm pack failed: {r.stderr[-200:]}"}
        out = td / "x"
        with tarfile.open(tgz) as t:
            _safe_extract(t, out)
        pkg = out / "package"
        only, changed = [], []
        for f in sorted(p for p in pkg.rglob("*") if p.is_file()):
            rel = f.relative_to(pkg).as_posix()
            if DOCS.search(rel) or rel == "package.json" or BUILT.search(rel):
                continue
            src = Path(source_dir) / rel
            if not src.exists():
                only.append(rel)
            elif src.read_bytes() != f.read_bytes():
                changed.append(rel)
        return {"ok": True, "spec": spec, "only_in_published": only, "differs_from_source": changed,
                "verdict": "artifact_mismatch" if only or changed else "match",
                "note": "build output (dist/lib/types/bin) and docs are ignored; review the rest by hand"}


# ---------------------------------------------------------------- S8
STRACE_FILE = "FROM node:22-slim\nRUN apt-get update && apt-get install -y --no-install-recommends strace && rm -rf /var/lib/apt/lists/*\n"
CRED_PATH = re.compile(r"(\.ssh|\.aws|id_rsa|\.git-credentials|/credentials)")   # even an attempt is suspicious
CONFIG_PATH = re.compile(r"(\.npmrc|\.env\b)")                                    # only a successful read is


def behaviour(spec: str, timeout: int = 600) -> dict:
    """Install `spec` in the sandbox with scripts ON but network OFF, under strace, with dummy credentials. Flags what it tries."""
    if not scanners.docker_available():
        return {"ok": False, "reason": "no container runtime: behaviour check not run (never run on the host)"}
    work = Path(tempfile.mkdtemp())
    (work / "Dockerfile").write_text(STRACE_FILE, encoding="utf-8")
    base = "guardian-sandbox/strace-node"
    b = scanners.docker_build(work, base, timeout=900)
    if not b.ok:
        return {"ok": False, "reason": f"could not build the strace image: {b.stderr[-200:]}"}
    # phase A (network on, scripts off): fetch the tarball only; phase B (network off): run the install scripts under strace
    pack = work / "pack"
    pack.mkdir()
    r = run("npm", ["pack", spec, "--ignore-scripts", "--silent", "--pack-destination", str(pack)], timeout=300)
    tgz = next(pack.glob("*.tgz"), None)
    if not r.ok or not tgz:
        return {"ok": False, "reason": f"npm pack failed: {r.stderr[-200:]}"}
    shutil.copy2(tgz, work / "pkg.tgz")
    sh = ("mkdir -p /tmp/p && cd /tmp/p && tar xzf /work/pkg.tgz && cd package && "
          "strace -f -e trace=network,process,file -o /tmp/trace.txt sh -c 'npm run --if-present preinstall; npm run --if-present install; "
          "npm run --if-present postinstall' >/dev/null 2>&1; head -3000 /tmp/trace.txt")
    t = scanners.docker_run_sandboxed(base, ["sh", "-c", sh], timeout=timeout, read_only=False, mounts=((str(work), "/work"),))
    lines = t.stdout.splitlines()
    conns = [l for l in lines if "connect(" in l and "AF_UNIX" not in l and "ENOENT" not in l]
    shells = [l for l in lines if "execve(" in l and re.search(r'"/(usr/)?bin/(sh|bash|curl|wget|nc)"', l) and "--if-present" not in l]  # not our wrapper
    reads = [l for l in lines if "openat(" in l and (CRED_PATH.search(l) or (CONFIG_PATH.search(l) and "ENOENT" not in l))]
    return {"ok": True, "spec": spec, "attempted_connections": conns[:10], "spawned_shells_or_downloaders": shells[:10],
            "sensitive_reads": reads[:10], "verdict": "suspicious" if (conns or reads or shells) else "no suspicious behaviour seen"}
