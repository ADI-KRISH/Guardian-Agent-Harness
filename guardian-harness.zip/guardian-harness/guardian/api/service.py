"""Guardian API logic. One method per endpoint; each calls a real module function and invents no display numbers.

The HTTP layer (server.py) only routes, checks the Host/Origin/token and caps the body. Scans live in run folders
(`report.json`, `legacy_report.json`, `inventory.json`, ...) written by `runner.scan`; reviews, lessons, baselines, proposals and the
append-only audit log live in the SQLite memory. Honesty rules enforced here: AI text is labelled inference, a needs_validation
finding has no severity badge, a missing severity is Unknown, a detector that did not run is Not run, every write needs a name and a reason.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
import uuid
from datetime import date, timedelta
from pathlib import Path

from .. import config
from ..agents.discovery import paths_to
from ..eval import scoreboard
from ..eval.regression import evaluate
from ..memory import Memory
from . import graphs

ID_RX = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
SEVERITIES = ("critical", "high", "medium", "low", "unknown")
STATUSES = {"open", "confirmed", "false_positive", "accepted"}
GATES = {1: "Approve baseline", 2: "Label a finding", 4: "Accept a risk", 5: "Approve a fix plan", 6: "Allow dependency download for validation",
         7: "Open the pull request", 8: "Activate a lesson", 9: "Stop the line"}
PROTECTED_TYPES = {"integrity_change", "typosquat", "backdoor_signal", "artifact_mismatch", "canary_missed"}
SBOM_FILES = {"cyclonedx": "sbom.cdx.json", "spdx": "sbom.spdx.json"}
REPORT_FILES = {"html": ("report.html", "text/html; charset=utf-8"), "md": ("report.md", "text/markdown; charset=utf-8"),
                "json": ("report.json", "application/json"), "sarif": ("report.sarif", "application/sarif+json")}


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


def need(cond, status: int, message: str) -> None:
    if not cond:
        raise ApiError(status, message)


def _json(p: Path, default=None):
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default
    except (OSError, ValueError):
        return default


def _fp(legacy: dict) -> str:
    return hashlib.sha256(legacy["fingerprint"].encode()).hexdigest()


class Backend:
    def __init__(self, roots: list[Path], db_path: Path | None = None, demo: bool = False):
        self.roots, self.db_path, self.demo = [Path(r) for r in roots], db_path, demo
        self.jobs: dict[str, dict] = {}
        self.lock = threading.Lock()

    # ------------------------------------------------------------------ plumbing
    def mem(self) -> Memory:
        return Memory(self.db_path) if self.db_path else Memory()          # a connection per call: SQLite connections are not shared across threads

    def index(self) -> dict[str, Path]:
        found: list[tuple[float, str, Path]] = []
        for root in self.roots:
            if not root.exists():
                continue
            for depth in ("report.json", "*/report.json", "*/*/report.json"):         # the root itself may be one run (GUARDIAN_EXTRA_RUNS)
                for rp in root.glob(depth):
                    if (rp.parent / "legacy_report.json").exists():
                        found.append((rp.stat().st_mtime, rp.parent.name, rp.parent))
        out: dict[str, Path] = {}
        for _, name, d in sorted(found, key=lambda x: -x[0]):
            out.setdefault(name, d)
        return out

    def run_dir(self, scan_id: str) -> Path:
        need(ID_RX.match(scan_id or ""), 400, "bad scan id")
        d = self.index().get(scan_id)
        need(d, 404, "Scan not found")
        return d

    def _ctx(self, scan_id: str) -> dict:
        d = self.run_dir(scan_id)
        legacy_report = _json(d / "legacy_report.json", {})
        legacy = {_fp(l): l for l in legacy_report.get("findings", [])}
        mem = self.mem()
        return {"dir": d, "report": _json(d / "report.json", {}), "legacy_report": legacy_report, "legacy": legacy, "mem": mem,
                "reviews": mem.reviews(scan_id), "decisions_file": _json(d / "decisions.json", []), "meta": _json(d / "scan-meta.json", {}),
                "investigations": {c["finding"]: c for c in (_json(d / "investigations.json", {}) or {}).get("checks", [])}}

    # ------------------------------------------------------------------ shaping (the honesty rules live here)
    def shape(self, f: dict, c: dict) -> dict:
        leg = c["legacy"].get(f["fingerprint"], {})
        lid = leg.get("id", "")
        out = dict(f)
        out.update(legacy_id=lid, rule=leg.get("rule") or leg.get("type", f["type"]), component_key=leg.get("component", ""))
        if f["verdict"] == "needs_validation":
            out["severity_badge"] = None                                   # no severity badge: the missing fact is shown instead
        else:
            out["severity_badge"] = "Unknown" if f["severity"] == "unknown" else f["severity"].title()
        out["badge"] = "Needs validation" if f["verdict"] == "needs_validation" else out["severity_badge"]
        review = c["reviews"].get(lid)
        expiry = next((d.get("expires") for d in c["decisions_file"] if d.get("finding") == lid and d.get("status") == "accepted-risk"), None)
        if review and review["status"] == "accepted" and expiry and expiry < date.today().isoformat():
            review = {**review, "status": "open", "reason": f"accepted risk expired {expiry}: " + review["reason"]}
        out["review"] = review
        out["accepted_until"] = expiry if review and review["status"] == "accepted" else None
        inv = c["investigations"].get(lid)
        out["ai_investigation"] = ({"label": "AI inference, not evidence", "model": inv["model"], "prompt_sha": inv.get("prompt_sha", ""), "text": inv["text"],
                                    "ai_verdict": inv["ai_verdict"], "verifier_verdict": inv["final_verdict"], "verifier_note": inv["why"], "citation": inv["citation"]}
                                   if inv else None)
        if f.get("ai_inference"):
            out["ai_inference"] = {**f["ai_inference"], "label": "AI inference, not evidence"}
        out["suppressed"] = f["status"] == "suppressed"
        out["fix_report"] = (_json(c["dir"] / "suggestions.json", {}) or {}).get(lid)
        out["workflow_run"] = (_json(c["dir"] / "workflows.json", {}) or {}).get(lid)
        return out

    def _findings(self, c: dict) -> list[dict]:
        return [self.shape(f, c) for f in c["report"].get("findings", [])]

    # ------------------------------------------------------------------ scans
    def list_scans(self) -> list[dict]:
        out = []
        for sid, d in self.index().items():
            meta, rep = _json(d / "scan-meta.json", {}), _json(d / "report.json", {})
            out.append({"id": sid, "project": meta.get("project") or _json(d / "legacy_report.json", {}).get("project", ""), "created": meta.get("created", ""),
                        "head_ref": rep.get("head_ref"), "findings": rep.get("summary", {}).get("findings"), "blocked": bool(rep.get("blocked"))})
        return out

    def start_scan(self, body: dict) -> dict:
        need(not self.demo, 409, "Demo mode serves a saved scan; start the Guardian without GUARDIAN_DEMO to scan live")
        source = str(body.get("source", "")).strip()
        need(source and len(source) <= 500 and not source.startswith("-"), 400, "Enter a GitHub URL or a local path")
        profile = body.get("profile", "standard")
        need(profile in ("quick", "standard", "deep"), 400, "profile must be quick, standard or deep")
        opts = {"profile": profile, "offline": bool(body.get("offline")), "scan_images": bool(body.get("scan_images")), "ai": bool(body.get("ai"))}
        base, head = str(body.get("base_ref") or "").strip() or None, str(body.get("head_ref") or "").strip() or None
        for ref in (base, head):
            need(not ref or (not ref.startswith("-") and re.fullmatch(r"[A-Za-z0-9_./~^@{}:-]{1,200}", ref)), 400, "bad ref")
        jid = self._job("scan", f"scan {source}")

        def work() -> None:
            from .. import runner
            try:
                res = runner.scan(source, base, head, out=None, options=opts, on_stage=lambda m, st, secs, det: self._stage(jid, m, st, secs, det))
                if opts["ai"]:
                    self._stage(jid, "M9.agents", "running", 0, "")
                    from ..agents import lead
                    lead.run(res["out"], self.mem())
                    self._stage(jid, "M9.agents", "ok", 0, "")
                self._finish(jid, {"scan_id": Path(res["out"]).name, "blocked": res["blocked"]})
            except Exception as e:  # noqa: BLE001 - a failed scan is a job result, not a server crash
                self._finish(jid, None, f"{type(e).__name__}: {e}")
        threading.Thread(target=work, daemon=True).start()
        return {"job_id": jid}

    def _job(self, kind: str, label: str) -> str:
        with self.lock:
            need(not any(j["state"] == "running" and j["kind"] == kind for j in self.jobs.values()), 409, f"A {kind} is already running")
            jid = uuid.uuid4().hex[:12]
            self.jobs[jid] = {"id": jid, "kind": kind, "label": label, "state": "running", "stages": [], "started": time.time()}
        return jid

    def _stage(self, jid: str, module: str, state: str, secs: float, detail: str) -> None:
        with self.lock:
            j = self.jobs[jid]
            if state == "running":
                j["current"] = module
            else:
                j["stages"].append({"agent": module, "decision": state, "seconds": round(secs, 1), "detail": detail[:300]})

    def _finish(self, jid: str, result: dict | None, error: str = "") -> None:
        with self.lock:
            j = self.jobs[jid]
            j.update(state="failed" if error else "complete", error=error, result=result, current="", finished=time.time())

    def job(self, jid: str) -> dict:
        need(ID_RX.match(jid or ""), 400, "bad job id")
        with self.lock:
            j = self.jobs.get(jid)
            need(j, 404, "Job not found")
            return json.loads(json.dumps(j, default=str))

    def summary(self, scan_id: str) -> dict:
        c = self._ctx(scan_id)
        rep, fs = c["report"], self._findings(c)
        live = [f for f in fs if not f["suppressed"]]
        sev = {s: sum(1 for f in live if f["severity"] == s and f["verdict"] != "needs_validation") for s in SEVERITIES}
        sev["needs_validation"] = sum(1 for f in live if f["verdict"] == "needs_validation")
        inv = _json(c["dir"] / "inventory.json", {"packages": {}, "roots": {}, "workflows": [], "images": []})
        direct = {k for ks in inv["roots"].values() for k in ks}
        cov = _json(c["dir"] / "coverage.json", {"gaps": [], "surfaces": {}})
        status = _json(c["dir"] / "module-status.json", {})
        gaps = cov.get("gaps", [])
        total_units = len(status) + len(gaps)
        covered = sum(1 for v in status.values() if v == "ok")
        ranked = sorted((f for f in live if f["verdict"] != "needs_validation"), key=lambda f: -f["score"])
        top = ([f for f in ranked if f["severity"] == "critical"] or ranked)[:5]          # Critical risks first; the rest only when there are none
        vuln_check = _json(c["dir"] / "vuln-coverage.json", None) or {"complete": False, "checked": 0, "total": 0, "percent": 0,
                                                                        "reason": "this scan did not record vulnerability coverage", "not_checked": []}
        summ = (c["dir"] / "summary.md")
        return {"scan_id": scan_id, "project": c["meta"].get("project") or c["legacy_report"].get("project"), "source": c["meta"].get("source"),
                "created": c["meta"].get("created"), "seconds": c["meta"].get("seconds"), "base_ref": rep.get("base_ref"), "head_ref": rep.get("head_ref"),
                "comparison": self._comparison(c),
                "stats": {"components": len(inv["packages"]), "direct": len(direct & set(inv["packages"])), "transitive": len(set(inv["packages"]) - direct),
                          "workflows": len(inv.get("workflows", [])), "images": len(inv.get("images", [])),
                          "coverage_percent": round(100 * covered / total_units) if total_units else 0},
                "severity": sev, "vuln_check": {k: vuln_check.get(k) for k in ("complete", "checked", "total", "percent", "reason")}, "selfcheck": self._selfcheck(rep, status), "top_risks": top, "blocked": rep.get("blocked") or "",
                "incomplete": bool(rep.get("incomplete")), "gaps": gaps, "modules": status,
                "ai_summary": ({"label": "AI inference, not evidence: counts and titles come from the findings", "text": summ.read_text(encoding="utf-8")} if summ.exists() else None)}

    @staticmethod
    def _comparison(c: dict) -> dict:
        """The recorded comparison; a run from before comparison metadata existed is labelled from its base ref (an untrusted git ref)."""
        rec = c["report"].get("comparison") or c["meta"].get("comparison") or c["legacy_report"].get("comparison")
        if rec:
            return rec
        base = c["report"].get("base_ref") or c["legacy_report"].get("base_ref")
        return ({"kind": "git-ref", "ref": base, "trusted": False, "note": "a git ref chosen at scan time; not a human-approved baseline"} if base
                else {"kind": "none", "ref": None, "trusted": False, "note": "no baseline: this scan establishes an observation, not trust"})

    @staticmethod
    def _selfcheck(rep: dict, status: dict) -> list[dict]:
        out = []
        for ck in rep.get("canary", []):
            state = ck.get("state") or ("pass" if ck.get("caught") else "fail")
            out.append({"detector": ck["detector"], "state": state, "detail": ck.get("detail", "")})
        for mid, st in status.items():
            if st != "ok":
                out.append({"detector": mid, "state": "fail", "detail": st})
        return out

    # ------------------------------------------------------------------ inventory, sbom, graph, changes
    def inventory(self, scan_id: str) -> dict:
        c = self._ctx(scan_id)
        inv = _json(c["dir"] / "inventory.json", {"packages": {}, "roots": {}})
        direct = {k for ks in inv["roots"].values() for k in ks}
        counts: dict[str, int] = {}
        for f in self._findings(c):
            if f["component_key"] and not f["suppressed"]:
                counts[f["component_key"]] = counts.get(f["component_key"], 0) + 1
        rows = [{"key": k, "name": p["name"], "version": p["version"], "ecosystem": p["ecosystem"], "direct": k in direct, "manifest": (p.get("lockfiles") or [""])[0],
                 "integrity": bool(p.get("integrity")), "install_script": bool(p.get("install_script")), "findings": counts.get(k, 0)} for k, p in inv["packages"].items()]
        return {"components": rows, "notes": inv.get("notes", []), "generated_locks": inv.get("generated_locks", [])}

    def component(self, scan_id: str, key: str) -> dict:
        c = self._ctx(scan_id)
        inv = _json(c["dir"] / "inventory.json", {"packages": {}, "graph": {}, "roots": {}})
        need(key in inv["packages"], 404, "Component not found")
        p = inv["packages"][key]
        graph = {k: set(v) for k, v in inv["graph"].items()}
        incoming = sorted(a for a, bs in graph.items() if key in bs and not a.startswith("app:"))
        return {"key": key, **p, "paths": paths_to(key, {k: set(v) for k, v in inv["graph"].items()}, inv["roots"], limit=5),
                "incoming": incoming, "outgoing": sorted(graph.get(key, [])), "evidence": {"file": (p.get("lockfiles") or [""])[0], "integrity": p.get("integrity", "")},
                "findings": [f for f in self._findings(c) if f["component_key"] == key]}

    def sbom(self, scan_id: str, fmt: str) -> tuple[bytes, str]:
        need(fmt in SBOM_FILES, 400, "format must be cyclonedx or spdx")
        p = self.run_dir(scan_id) / SBOM_FILES[fmt]
        need(p.exists(), 404, f"No {fmt} SBOM for this scan")
        return p.read_bytes(), "application/json"

    def vulnerable_components(self, scan_id: str) -> dict:
        """Components with findings, Critical first and then the rest, for the panel beside the dependency graph."""
        c = self._ctx(scan_id)
        inv = _json(c["dir"] / "inventory.json", {"packages": {}, "roots": {}})
        direct = {k for ks in inv["roots"].values() for k in ks}
        groups: dict[str, dict] = {}
        for f in self._findings(c):
            k = f["component_key"]
            if not k or k not in inv["packages"] or f["suppressed"] or f["verdict"] == "needs_validation":
                continue
            g = groups.setdefault(k, {"key": k, "name": inv["packages"][k]["name"], "version": inv["packages"][k]["version"], "direct": k in direct, "worst": "unknown", "findings": [], "fixed_versions": set(), "advisories": set()})
            g["findings"].append({"fingerprint": f["fingerprint"], "title": f["title"][:110], "severity": f["severity"], "score": f["score"], "legacy_id": f["legacy_id"]})
            g["fixed_versions"].update(f["fixed_versions"])
            g["advisories"].update(f["advisory_ids"])
            if SEVERITIES.index(f["severity"]) < SEVERITIES.index(g["worst"]) or g["worst"] == "unknown" and f["severity"] != "unknown":
                g["worst"] = f["severity"]
        rows = []
        for g in groups.values():
            g["findings"].sort(key=lambda x: -x["score"])
            rows.append({**g, "fixed_versions": sorted(g["fixed_versions"]), "advisories": sorted(g["advisories"]), "top_score": g["findings"][0]["score"]})
        rows.sort(key=lambda r: (SEVERITIES.index(r["worst"]) if r["worst"] in SEVERITIES else 9, -r["top_score"]))
        return {"critical": [r for r in rows if r["worst"] == "critical"], "rest": [r for r in rows if r["worst"] != "critical"], "total": len(rows)}

    def graph(self, scan_id: str, view: str, node: str, severity: str = "critical") -> dict:
        need(view in ("risk", "trace", "full"), 400, "view must be risk, trace or full")
        c = self._ctx(scan_id)
        inv = _json(c["dir"] / "inventory.json", {"packages": {}, "graph": {}, "roots": {}})
        try:
            return graphs.build(inv, self._findings(c), view, node, severity)
        except ValueError as e:
            raise ApiError(400, str(e)) from e
        except KeyError as e:
            raise ApiError(404, e.args[0]) from e

    def changes(self, scan_id: str) -> dict:
        c = self._ctx(scan_id)
        ch = _json(c["dir"] / "changes.json", {})
        fs = self._findings(c)
        by = lambda t: [f for f in fs if f["type"] in t and not f["suppressed"]]   # noqa: E731
        return {"comparison": self._comparison(c), "available": "added" in ch, "added": ch.get("added", []),
                "removed": ch.get("removed", []), "updated": ch.get("updated", []), "files": ch.get("files", []), "workflow_changes": ch.get("workflow_changes", []),
                "image_changes": ch.get("image_changes", []), "integrity_changes": by({"integrity_change"}), "history_anomalies": by({"history_anomaly"}),
                "install_scripts": by({"install_script"}), "typosquats": by({"typosquat"}), "unexpected": by({"unexpected_dependency", "suspicious_update"})}

    # ------------------------------------------------------------------ findings and human gates
    def findings(self, scan_id: str, q: dict) -> dict:
        c = self._ctx(scan_id)
        fs = self._findings(c)
        sev = set(filter(None, (q.get("severity") or "").split(",")))
        out = [f for f in fs if (not sev or f["severity"] in sev or ("needs_validation" in sev and f["verdict"] == "needs_validation"))
               and (not q.get("type") or f["type"] == q["type"]) and (not q.get("verdict") or f["verdict"] == q["verdict"])]
        shown_suppressed = q.get("show_suppressed") in ("1", "true", True)
        suppressed = [f for f in out if f["suppressed"]]
        if not shown_suppressed:
            out = [f for f in out if not f["suppressed"]]
        return {"findings": sorted(out, key=lambda f: -f["score"]), "suppressed_count": len(suppressed), "total": len(fs)}

    def finding(self, scan_id: str, fp: str) -> dict:
        need(re.fullmatch(r"[0-9a-f]{64}", fp or ""), 400, "bad fingerprint")
        c = self._ctx(scan_id)
        f = next((x for x in c["report"].get("findings", []) if x["fingerprint"] == fp), None)
        need(f, 404, "Finding not found")
        out = self.shape(f, c)
        lid = out["legacy_id"]
        trail = [d for d in c["mem"].decisions(scan_id) if lid and (lid in (d["decision"] or "") or lid in (d["inputs"] or ""))]
        plan = next((p for p in _json(c["dir"] / "plans.json", []) if p.get("finding_id") == lid), None)
        return {**out, "decision_trail": trail, "plan": plan}

    def review(self, body: dict) -> dict:
        """Gate 2 (label) and gate 4 (accept risk with an expiry)."""
        c = self._ctx(str(body.get("scan_id", "")))
        f = next((x for x in c["report"].get("findings", []) if x["fingerprint"] == body.get("finding_id") or c["legacy"].get(x["fingerprint"], {}).get("id") == body.get("finding_id")), None)
        need(f, 404, "Finding not found")
        s = self.shape(f, c)
        status = body.get("status")
        need(status in STATUSES, 400, "status must be one of " + ", ".join(sorted(STATUSES)))
        if f["type"] in PROTECTED_TYPES and status == "false_positive":
            need(len(str(body.get("reason", ""))) >= 20, 400, "A protected finding (attack signal) needs a detailed reason (20+ characters) to be called a false positive")
        try:
            lesson = c["mem"].review(str(body["scan_id"]), c["meta"].get("project") or c["legacy_report"].get("project", ""), s["legacy_id"], status,
                                     str(body.get("actor", "")), str(body.get("reason", "")), s["rule"], (f.get("location") or {}).get("file", ""))
        except ValueError as e:
            raise ApiError(400, str(e)) from e
        expires = None
        if status == "accepted":                                          # gate 4: an accepted risk always carries an expiry
            days = int(body.get("days") or 30)
            need(1 <= days <= 365, 400, "expiry must be 1 to 365 days")
            expires = (date.today() + timedelta(days=days)).isoformat()
            cur = [d for d in c["decisions_file"] if d.get("finding") != s["legacy_id"]]
            (c["dir"] / "decisions.json").write_text(json.dumps(cur + [{"finding": s["legacy_id"], "status": "accepted-risk", "by": body["actor"], "reason": body["reason"], "expires": expires}], indent=2), encoding="utf-8")
        return {"ok": True, "lesson_proposed": lesson, "expires": expires}

    def approve_baseline(self, body: dict) -> dict:
        c = self._ctx(str(body.get("scan_id", "")))
        inv = _json(c["dir"] / "inventory.json", {})
        ref = c["legacy_report"].get("head_ref", "HEAD")
        try:
            c["mem"].promote_baseline(c["meta"].get("project") or c["legacy_report"]["project"], (c["meta"].get("head_sha") or ref), inv, body["scan_id"], str(body.get("actor", "")), str(body.get("reason", "")),
                                       findings=list(c["legacy"].values()))
        except ValueError as e:
            raise ApiError(400, str(e)) from e
        return {"ok": True}

    def suggest(self, scan_id: str, body: dict) -> dict:
        """AI fix suggestion for one finding. Labelled inference; the applied change still comes from the deterministic recipe."""
        from .. import config
        from ..agents import suggest as ai
        c = self._ctx(scan_id)
        fid = str(body.get("finding_id", ""))
        f = next((x for x in c["report"].get("findings", []) if x["fingerprint"] == fid or c["legacy"].get(x["fingerprint"], {}).get("id") == fid), None)
        need(f, 404, "Finding not found")
        s = self.shape(f, c)
        cache = _json(c["dir"] / "suggestions.json", {}) or {}
        if "checked" in (cache.get(s["legacy_id"]) or {}) and not body.get("refresh"):       # entries from before the OSV/Trivy report existed are ignored
            return cache[s["legacy_id"]]
        plan = next((p for p in _json(c["dir"] / "plans.json", []) if p.get("finding_id") == s["legacy_id"]), None)
        head = config.WORKSPACE / "checkouts" / (c["meta"].get("project") or c["legacy_report"].get("project", "")) / re.sub(r"[^A-Za-z0-9_.-]", "_", c["legacy_report"].get("head_ref", "HEAD"))
        out = ai.report(s, plan, c["mem"], head if head.exists() else None)
        cache[s["legacy_id"]] = out
        (c["dir"] / "suggestions.json").write_text(json.dumps(cache, indent=2), encoding="utf-8")
        used = "OSV and Trivy checked; fix found; LLM explained it" if out.get("llm") and "error" not in out["llm"] else ("OSV and Trivy checked; fix found" if out.get("fix_found") else "OSV and Trivy checked; no fix found, agentic workflow proposed (no LLM call)")
        c["mem"].decide(scan_id, "", "fix-report", f"fix report for {s['legacy_id']}", used, {"osv": out["checked"]["osv"]["state"], "trivy": out["checked"]["trivy"]["state"]}, rule="fix-report")
        return out

    def run_workflow(self, scan_id: str, finding_id: str, on_step=None) -> dict:
        """Execute the no-fix agentic workflow for one finding (synchronously). The run record is saved next to the scan."""
        import urllib.request

        from .. import config
        from ..agents import nofix
        c = self._ctx(scan_id)
        f = next((x for x in c["report"].get("findings", []) if x["fingerprint"] == finding_id or c["legacy"].get(x["fingerprint"], {}).get("id") == finding_id), None)
        need(f, 404, "Finding not found")
        s = self.shape(f, c)
        need(s["type"] == "known_vulnerability" and s["component_key"], 400, "The no-fix workflow is for known vulnerabilities in a package")
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        repo = config.WORKSPACE / "repos" / project
        head = config.WORKSPACE / "checkouts" / project / re.sub(r"[^A-Za-z0-9_.-]", "_", c["legacy_report"].get("head_ref", "HEAD"))
        sha = (c["legacy_report"].get("head_commit") or {}).get("sha", "")
        need(repo.exists() and head.exists() and sha, 409, "The repository checkout for this scan is not on this computer, so the workflow cannot read or patch the code")
        advisory = {}
        for aid in (s["advisory_ids"] or [])[:1]:                       # the advisory's own words name the vulnerable feature
            try:
                with urllib.request.urlopen(f"https://api.osv.dev/v1/vulns/{aid}", timeout=10) as r:
                    v = json.loads(r.read(2 * 1024 * 1024))
                advisory = {"id": aid, "summary": v.get("summary", ""), "details": v.get("details", "")}
            except Exception:  # noqa: BLE001 - without the advisory text the investigator reports "no feature named", it does not guess
                advisory = {"id": aid, "summary": s["title"], "details": ""}
        rec = nofix.run(s, repo, head, sha, advisory, c["mem"], scan_id, project, on_step=on_step)
        cur = _json(c["dir"] / "workflows.json", {}) or {}
        cur[s["legacy_id"]] = rec
        (c["dir"] / "workflows.json").write_text(json.dumps(cur, indent=2), encoding="utf-8")
        return rec

    def start_workflow(self, scan_id: str, body: dict) -> dict:
        need(not self.demo, 409, "Demo mode serves saved results; run the workflow against a live scan")
        fid = str(body.get("finding_id", ""))
        self.run_dir(scan_id)
        jid = self._job("workflow", f"no-fix workflow {fid}")

        def work() -> None:
            try:
                rec = self.run_workflow(scan_id, fid, on_step=lambda agent, st, secs, note: self._stage(jid, agent, st, secs, note))
                self._finish(jid, {"outcome": rec["outcome"], "finding": rec["finding"]})
            except ApiError as e:
                self._finish(jid, None, e.message)
            except Exception as e:  # noqa: BLE001
                self._finish(jid, None, f"{type(e).__name__}: {e}")
        threading.Thread(target=work, daemon=True).start()
        return {"job_id": jid}

    # ------------------------------------------------------------------ plans, validation (gates 5, 6, 7)
    def plans(self, scan_id: str) -> dict:
        c = self._ctx(scan_id)
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        listed = c["mem"].list_proposals(project, c["legacy_report"].get("run_id"))
        props = {p["finding_id"]: p for p in listed}
        by_change = {p["change"]: p for p in listed if p.get("change")}        # one fix resolves every finding that shares its change
        out = []
        for p in _json(c["dir"] / "plans.json", []):
            pr = props.get(p["finding_id"]) or by_change.get(p["change"])
            out.append({**p, "proposal": ({"id": pr["id"], "status": pr["status"], "decided_by": pr.get("decided_by"), "verdict": (pr.get("result") or {}).get("verdict")} if pr else None)})
        return {"plans": out}

    def approve_plan(self, plan_id: str, body: dict) -> dict:
        """Gate 5. A named person approves one specific change; nothing is built before this."""
        from ..modules import validation
        c = self._ctx(str(body.get("scan_id", "")))
        need(re.fullmatch(r"[\w.:/@-]{1,160}", plan_id or ""), 400, "bad plan id")
        decision = body.get("decision", "approve")
        need(decision in ("approve", "reject"), 400, "decision must be approve or reject")
        mem = c["mem"]
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        existing = next((p for p in mem.list_proposals(project, c["legacy_report"].get("run_id")) if p["finding_id"] == plan_id), None)
        pid = existing["id"] if existing else None
        if not pid:
            p = validation.propose(mem, c["dir"], plan_id, log=lambda *_: None)
            need(p.get("ok"), 409, "No automatic fix: " + p.get("reason", "unsupported"))
            pid = p["id"]
        try:
            if decision == "approve":
                validation.approve(mem, pid, str(body.get("actor", "")), str(body.get("reason", "")))
            else:
                validation.reject(mem, pid, str(body.get("actor", "")), str(body.get("reason", "")))
        except ValueError as e:
            raise ApiError(400, str(e)) from e
        return {"ok": True, "proposal": pid}

    def validate(self, plan_id: str, body: dict) -> dict:
        from ..modules import validation
        c = self._ctx(str(body.get("scan_id", "")))
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        pr = next((p for p in c["mem"].list_proposals(project, c["legacy_report"].get("run_id")) if p["finding_id"] == plan_id), None)
        need(pr and pr["status"] == "approved" and pr.get("decided_by"), 409, "Approve this plan (gate 5) before validating it")
        test_cmd = str(body.get("test_cmd", ""))[:300]
        ship, scan_id = bool(body.get("ship")), str(body.get("scan_id", ""))
        pid = pr["id"]
        jid = self._job("validation", f"validate {pid}")

        def work() -> None:
            def log(line: str) -> None:
                m = re.match(r"\s*\[validation-agent\]\s+(.+?):\s+(\w+)\s+-\s+(.*)", str(line))
                if m:
                    self._stage(jid, m[1], m[2], 0.0, m[3])
            try:
                res = validation.validate(self.mem(), pid, test_cmd, log=log)
                out = {"proposal": pid, "verdict": res["verdict"]}
                if ship:                                            # the person approved "ship when verified": publish only a verified result
                    try:
                        out["published"] = self.publish_fix(plan_id, {"scan_id": scan_id, "actor": pr["decided_by"], "reason": f"{pr.get('decided_reason', '')} (approved to ship when verified)"})
                    except ApiError as e:
                        out["publish_error"] = e.message
                self._finish(jid, out)
            except Exception as e:  # noqa: BLE001
                self._finish(jid, None, f"{type(e).__name__}: {e}")
        threading.Thread(target=work, daemon=True).start()
        return {"job_id": jid, "proposal": pid}

    def validation(self, vid: str) -> dict:
        need(re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", vid or ""), 400, "bad id")
        if vid.startswith("FIX-"):                                          # a finished validation survives restarts in the proposals table
            try:
                p = self.mem().get_proposal(vid)
            except KeyError:
                raise ApiError(404, "No such validation") from None
            res = p.get("result") or {}
            return {"state": "complete" if res else "pending", "proposal": vid, "status": p["status"], "steps": res.get("steps", []), "result": res or None}
        j = self.job(vid)
        res = None
        if j["state"] == "complete" and j.get("result"):
            res = self.mem().get_proposal(j["result"]["proposal"]).get("result")
        return {**j, "steps": (res or {}).get("steps") or j["stages"], "result": res}

    def validation_pr(self, vid: str) -> tuple[bytes, str]:
        need(re.fullmatch(r"FIX-[A-Z0-9]{4,16}", vid or ""), 400, "bad proposal id")
        try:
            res = self.mem().get_proposal(vid).get("result") or {}
        except KeyError:
            raise ApiError(404, "No such validation") from None
        p = Path(res.get("report_dir", "")) / "pr-body.md"
        need(res and p.is_file(), 404, "No pull request description yet: validate the fix first")
        return p.read_bytes(), "text/markdown; charset=utf-8"

    # ------------------------------------------------------------------ gate 7: push the approved branch and open the pull request
    def _publish(self, *a, **kw) -> dict:
        from ..agents import publisher
        try:
            return publisher.publish(*a, **kw)
        except publisher.PublishError as e:
            raise ApiError(409, str(e)) from e

    def publish_fix(self, plan_id: str, body: dict) -> dict:
        """Gate 7 for a validated dependency fix: push its sandbox branch and open the pull request. Never merged."""
        from ..agents import publisher
        need(not self.demo, 409, "Demo mode serves saved results; nothing is pushed")
        c = self._ctx(str(body.get("scan_id", "")))
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        pr = next((p for p in c["mem"].list_proposals(project, c["legacy_report"].get("run_id")) if p["finding_id"] == plan_id), None)
        need(pr and pr["status"] == "approved" and pr.get("decided_by"), 409, "Approve this plan (gate 5) first")
        full = c["mem"].get_proposal(pr["id"])
        res = full.get("result") or {}
        need(res.get("verdict") in publisher.OK_VERDICTS, 409, "Only a verified fix is published: validate it first (gate 6)")
        text = Path(res.get("report_dir", "")) / "pr-body.md"
        return self._publish(Path(res.get("sandbox", "")), res.get("branch", ""), f"guardian: {full['change']}", text.read_text(encoding="utf-8") if text.is_file() else full["change"],
                             str(body.get("actor", "")), str(body.get("reason", "")), base_sha=full.get("head_sha", ""), draft=res["verdict"] != "verified",
                             mem=c["mem"], run_id=f"fix-{pr['id']}", project=project)

    def publish_workflow(self, scan_id: str, body: dict) -> dict:
        """Gate 7 for a patch drafted by the no-fix agents: push it and open a DRAFT pull request. Never merged."""
        from ..agents import publisher
        need(not self.demo, 409, "Demo mode serves saved results; nothing is pushed")
        c = self._ctx(scan_id)
        lid, path = str(body.get("finding_id", "")), c["dir"] / "workflows.json"
        cur = _json(path, {}) or {}
        rec = cur.get(lid)
        need(rec and rec.get("outcome") == "patch-drafted", 409, "There is no verified patch from the no-fix workflow for this finding")
        need(not rec.get("published"), 409, "This patch was already published: " + str((rec.get("published") or {}).get("pull_request", "")))
        v = next((s["output"] for s in rec["steps"] if s["agent"] == "Verifier" and s["status"] == "done"), None)
        need(v and v.get("branch") and v.get("sandbox"), 409, "The verifier's sandbox branch is missing: run the workflow again")
        actor, reason, pk = str(body.get("actor", "")), str(body.get("reason", "")), rec["package"]
        out = self._publish(Path(v["sandbox"]), v["branch"], f"guardian: isolate the vulnerable feature of {pk['name']} (no published fix)", publisher.workflow_body(rec, actor, reason, rec.get("patch", "")),
                            actor, reason, base_sha=(c["legacy_report"].get("head_commit") or {}).get("sha", ""), draft=True, mem=c["mem"], run_id=scan_id,
                            project=c["meta"].get("project") or c["legacy_report"].get("project", ""))
        rec["published"] = {k: out[k] for k in ("repo", "branch", "pull_request", "number")}
        cur[lid] = rec
        path.write_text(json.dumps(cur, indent=2), encoding="utf-8")
        return out

    # ------------------------------------------------------------------ review queue: all nine gates in one list
    def review_items(self, gate: str = "") -> dict:
        items: list[dict] = []
        mem = self.mem()
        for sid in list(self.index())[:5]:
            c = self._ctx(sid)
            rep, project = c["report"], (c["meta"].get("project") or c["legacy_report"].get("project", ""))
            if rep.get("blocked"):
                items.append(self._item(9, f"g9:{sid}", f"Detector self-check failed: {rep['blocked']}", sid, [], ["acknowledge"], rep=rep))
            fs = [f for f in self._findings(c) if not f["suppressed"]]
            for f in fs:
                if f["type"] in PROTECTED_TYPES and f["verdict"] == "confirmed" and not f["review"]:
                    items.append(self._item(9, f"g9:{sid}:{f['legacy_id']}", f"Attack signal: {f['title']}", sid, f["evidence"], ["confirmed", "false_positive"], ai=f["ai_investigation"]))
            if not mem.get_baseline(project) and not rep.get("blocked"):
                items.append(self._item(1, f"g1:{sid}", f"Approve {rep.get('head_ref')} as the trusted baseline", sid, [], ["approve", "reject"]))
            for f in [x for x in fs if x["severity"] == "critical" and x["verdict"] != "needs_validation" and not x["review"] and x["type"] not in PROTECTED_TYPES][:40]:   # critical first
                items.append(self._item(2, f"g2:{sid}:{f['legacy_id']}", f["title"], sid, f["evidence"], ["confirmed", "false_positive", "accepted"], ai=f["ai_investigation"]))
            plans = {p["finding_id"]: p for p in self.plans(sid)["plans"]}
            for p in plans.values():
                if p.get("automatic") and not p.get("proposal"):
                    items.append(self._item(5, f"g5:{sid}:{p['finding_id']}", f"{p['action']}: {p['change']}", sid, [{"kind": "tool_output", "ref": p["expected_risk_reduction"]}], ["approve", "reject"]))
                pr = p.get("proposal")
                if pr and pr["status"] == "approved" and not pr["verdict"]:
                    items.append(self._item(6, f"g6:{sid}:{p['finding_id']}", "Download dependencies with the network on (install scripts off) to validate the approved fix", sid, [], ["approve"]))
                if pr and pr["verdict"] in ("verified", "verified-with-gaps"):
                    items.append(self._item(7, f"g7:{sid}:{p['finding_id']}", f"Open the pull request for {pr['id']} (verdict {pr['verdict']}); it is never auto-merged", sid, [], ["approve"]))
            for lid, wrec in (_json(c["dir"] / "workflows.json", {}) or {}).items():
                if wrec.get("outcome") == "patch-drafted" and not wrec.get("published"):
                    items.append(self._item(7, f"g7w:{sid}:{lid}", f"Open a DRAFT pull request for the AI-drafted patch for {wrec['package']['name']} (statically verified only, not tested); never auto-merged",
                                            sid, [{"kind": "tool_output", "ref": wrec.get("recommendation", "")[:300]}], ["approve"]))
        for l in mem.lessons_by_state():
            if l["state"] == "proposed":
                items.append({"id": f"g8:{l['id']}", "gate": 8, "gate_name": GATES[8], "title": f"Suppress {l['rule']} on {l['scope']} for 30 days", "scan_id": "", "evidence": [{"kind": "tool_output", "ref": l["reason"]}],
                              "ai_view": None, "choices": ["approve", "reject"], "pinned": False})
        if gate:
            items = [i for i in items if str(i["gate"]) == str(gate)]
        items.sort(key=lambda i: (0 if i["gate"] == 9 else 1))
        return {"items": items, "count": len(items), "gates": {str(k): v for k, v in GATES.items()}}

    @staticmethod
    def _item(gate: int, iid: str, title: str, sid: str, evidence: list, choices: list, ai=None, rep=None) -> dict:
        return {"id": iid, "gate": gate, "gate_name": GATES[gate], "title": title, "scan_id": sid, "evidence": evidence[:4], "choices": choices, "pinned": gate == 9,
                "ai_view": ({"label": "AI inference, not evidence", **{k: ai[k] for k in ("model", "text", "verifier_verdict") if k in ai}} if ai else None)}

    def decide(self, item_id: str, body: dict) -> dict:
        choice, actor, reason = body.get("choice"), str(body.get("actor", "")), str(body.get("reason", ""))
        need(actor.strip() and reason.strip(), 400, "A reviewer name and a written reason are required")
        parts = str(item_id).split(":", 2)
        gate = parts[0]
        if gate == "g8":
            mem = self.mem()
            try:
                if choice == "approve":
                    return {"ok": True, "evaluation": mem.approve_lesson(int(parts[1]), actor, reason)}
                mem.reject_lesson(int(parts[1]), actor, reason)
                return {"ok": True}
            except (ValueError, IndexError) as e:
                raise ApiError(400, str(e)) from e
        need(len(parts) >= 2, 400, "bad item id")
        sid = parts[1]
        if gate == "g1":
            if choice == "approve":
                return self.approve_baseline({"scan_id": sid, "actor": actor, "reason": reason})
            self.mem().decide(sid, "", f"human:{actor}", "baseline rejected", reason, rule="human-gate-1")
            return {"ok": True}
        if gate in ("g2", "g9") and len(parts) == 3:
            return self.review({"scan_id": sid, "finding_id": parts[2], "status": choice, "actor": actor, "reason": reason, "days": body.get("days")})
        if gate == "g9":
            self.mem().decide(sid, "", f"human:{actor}", "self-check failure acknowledged", reason, rule="human-gate-9")
            return {"ok": True}
        if gate == "g5" and len(parts) == 3:
            return self.approve_plan(parts[2], {"scan_id": sid, "decision": choice, "actor": actor, "reason": reason})
        if gate == "g6" and len(parts) == 3:
            self.mem().decide(sid, "", f"human:{actor}", f"allowed the dependency download (network on, install scripts off) to validate {parts[2]}", reason, rule="human-gate-6")
            return self.validate(parts[2], {"scan_id": sid, "test_cmd": body.get("test_cmd", ""), "ship": body.get("ship")})
        if gate == "g7" and len(parts) == 3:
            self.mem().decide(sid, "", f"human:{actor}", f"approved opening the pull request for {parts[2]}", reason + "; the Guardian never merges", rule="human-gate-7")
            from ..agents import publisher
            if not publisher.enabled():
                return {"ok": True, "note": "Recorded. Pushing is switched off (set GUARDIAN_ALLOW_PUSH=1 and GUARDIAN_GITHUB_TOKEN), so open the pull request yourself from pr-body.md. The Guardian never merges."}
            return {"ok": True, "published": self.publish_fix(parts[2], {"scan_id": sid, "actor": actor, "reason": reason})}
        if gate == "g7w" and len(parts) == 3:                                  # a patch drafted by the no-fix agents
            return {"ok": True, "published": self.publish_workflow(sid, {"finding_id": parts[2], "actor": actor, "reason": reason})}
        raise ApiError(400, "unknown gate")

    # ------------------------------------------------------------------ report, audit, proof, learning, models
    def report(self, scan_id: str, fmt: str) -> tuple[bytes, str]:
        need(fmt in REPORT_FILES, 400, "format must be html, md, json or sarif")
        name, mime = REPORT_FILES[fmt]
        p = self.run_dir(scan_id) / name
        need(p.exists(), 404, f"No {fmt} report for this scan")
        return p.read_bytes(), mime

    def report_view(self, scan_id: str) -> dict:
        """The eight sections of the Report page."""
        c = self._ctx(scan_id)
        s = self.summary(scan_id)
        fs = self._findings(c)
        live = [f for f in fs if not f["suppressed"]]
        mem = c["mem"]
        project = s["project"] or ""
        results = [{"proposal": p["id"], "finding_id": p["finding_id"], "status": p["status"], "decided_by": p.get("decided_by"), "decided_reason": p.get("decided_reason"),
                    "verdict": (p.get("result") or {}).get("verdict"), "verdict_reason": (p.get("result") or {}).get("verdict_reason"),
                    "before": (p.get("result") or {}).get("before"), "after": (p.get("result") or {}).get("after")} for p in mem.list_proposals(project, c["legacy_report"].get("run_id"))]
        remaining = [{"title": f["title"], "badge": f["badge"], "status": (f["review"] or {}).get("status", "open"), "accepted_until": f["accepted_until"]}
                     for f in live if f["severity"] in ("critical", "high") or f["accepted_until"]][:60]
        return {"summary": s, "sbom": {"components": s["stats"]["components"], "formats": [k for k, v in SBOM_FILES.items() if (c["dir"] / v).exists()]},
                "evidence_ledger": sorted([{"title": f["title"], "badge": f["badge"], "score": f["score"], "evidence": f["evidence"][:2], "reasons": f["score_reasons"]} for f in live if f["verdict"] != "needs_validation"],
                                          key=lambda x: -x["score"])[:100],
                "changes": self.changes(scan_id), "fixes": results, "remaining": remaining,
                "limitations": s["gaps"] + ["Absence of findings is not absence of a backdoor."], "audit": self.audit(scan_id)["entries"]}

    def audit(self, scan_id: str) -> dict:
        c = self._ctx(scan_id)
        mem = c["mem"]
        project = c["meta"].get("project") or c["legacy_report"].get("project", "")
        entries = list(mem.decisions(scan_id))
        for p in mem.list_proposals(project, c["legacy_report"].get("run_id")):
            entries += mem.decisions(f"fix-{p['id']}")
        return {"entries": sorted(entries, key=lambda d: d["ts"])}

    def evaluation(self) -> dict:
        return evaluate()

    def scoreboard(self) -> dict:
        return scoreboard.load()

    def refresh_scoreboard(self) -> dict:
        need(not self.demo, 409, "Demo mode: the scoreboard shows the saved results")
        jid = self._job("scoreboard", "scoreboard refresh")

        def work() -> None:
            try:
                scoreboard.main(False)
                self._finish(jid, {"ok": True})
            except Exception as e:  # noqa: BLE001
                self._finish(jid, None, f"{type(e).__name__}: {e}")
        threading.Thread(target=work, daemon=True).start()
        return {"job_id": jid}

    def learning(self) -> dict:
        mem = self.mem()
        lessons = mem.lessons_by_state()
        cached = mem.db.execute("SELECT COUNT(*), MIN(ts) FROM cache").fetchone()
        baselines = [dict(zip(["project", "ref", "approved_by", "reason", "ts"], r)) for r in mem.db.execute("SELECT project, ref, approved_by, reason, ts FROM baselines ORDER BY ts DESC")]
        latest = next(iter(self.index()), None)
        shaped = self._findings(self._ctx(latest)) if latest else []
        import fnmatch
        for l in lessons:
            hits = [f for f in shaped if not l["protected"] and l["rule"] in (f["type"], f["rule"], f["detector"]) and fnmatch.fnmatch((f.get("location") or {}).get("file") or f["component_key"], l["scope"])]
            l["shadow"] = {"would_suppress": len(hits), "examples": [f["title"][:100] for f in hits[:5]], "scan": latest}
        return {"baselines": baselines, "lessons": {s: [l for l in lessons if l["state"] == s] for s in ("proposed", "active", "rejected")},
                "evaluation": {"passing": evaluate()["passing"], "total": evaluate()["total"]},
                "cache": {"entries": cached[0], "oldest_age_seconds": int(time.time() - cached[1]) if cached[1] else None}}

    def models(self) -> dict:
        from urllib.parse import urlparse

        from ..agents import llm
        cfg = config.load(None)
        eps = []
        try:
            for base, model, key in llm.endpoints(cfg["llm"]):
                eps.append({"host": urlparse(base).netloc or base, "model": model, "configured": bool(key)})     # never the key itself
        except Exception:  # noqa: BLE001
            pass
        return {"provider": cfg["llm"]["provider"], "model": cfg["llm"]["model"], "endpoints": eps, "ai_available": bool(eps and eps[0]["configured"])}
