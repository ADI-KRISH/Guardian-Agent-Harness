"""Guardian API (127.0.0.1:48200). Standard library only. Routing and request hardening; all logic is in service.py.

Request protections ported from GuardianAI day1 (team): server.py. Host check, a per-session token for every write (X-Guardian-Token,
fetched from GET /session), Origin check on writes, 64 KB body cap, CSP, nosniff and no-store on every response.
0security forwards /api/guardian/* here through one proxy block in dashboard.ts (it drops the browser's Origin; the token still applies).

GUARDIAN_DEMO=1 serves the saved Juice Shop scan in api/fixtures/; POSTs then write to a throwaway database.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from .. import config
from .service import ApiError, Backend

PORT = int(os.environ.get("GUARDIAN_PORT", "48200"))
FIXTURES = Path(__file__).parent / "fixtures"
MAX_BODY = 64 * 1024
CSP = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"
S = r"([A-Za-z0-9_.-]{1,64})"
KEY = r"([^/]{1,300})"

GET_ROUTES = [
    (r"^/session$", "session"), (r"^/health$", "health"), (r"^/scans$", "list_scans"),
    (rf"^/scans/{S}/summary$", "summary"), (rf"^/scans/{S}/inventory$", "inventory"), (rf"^/scans/{S}/components/{KEY}$", "component"),
    (rf"^/scans/{S}/sbom$", "sbom"), (rf"^/scans/{S}/graph$", "graph"), (rf"^/scans/{S}/changes$", "changes"), (rf"^/scans/{S}/vulnerable-components$", "vulnerable_components"), (rf"^/scans/{S}/findings$", "findings"),
    (rf"^/scans/{S}/findings/([0-9a-f]{{64}})$", "finding"), (rf"^/scans/{S}/plans$", "plans"), (rf"^/scans/{S}/audit$", "audit"),
    (rf"^/scans/{S}/report$", "report"), (rf"^/scans/{S}/report-view$", "report_view"), (rf"^/jobs/{S}$", "job"), (rf"^/validations/{S}$", "validation"), (rf"^/validations/(FIX-[A-Z0-9]{{4,16}})/pr$", "validation_pr"),
    (r"^/review-items$", "review_items"), (r"^/evaluation$", "evaluation"), (r"^/scoreboard$", "scoreboard"), (r"^/lessons$", "learning"),
    (r"^/learning$", "learning"), (r"^/models/status$", "models"),
]
POST_ROUTES = [
    (r"^/scans$", "start_scan"), (r"^/review$", "review"), (r"^/baseline$", "approve_baseline"), (rf"^/review-items/([^/]{{1,200}})/decision$", "decide"),
    (rf"^/scans/{S}/suggest$", "suggest"), (rf"^/scans/{S}/workflow$", "start_workflow"), (rf"^/plans/([^/]{{1,200}})/approve$", "approve_plan"), (rf"^/plans/([^/]{{1,200}})/validate$", "validate"),
    (rf"^/plans/([^/]{{1,200}})/publish$", "publish_fix"), (rf"^/scans/{S}/workflow/publish$", "publish_workflow"), (rf"^/lessons/{S}/decision$", "lesson_decision"),
    (r"^/scoreboard/refresh$", "refresh_scoreboard"),
]


def make_backend(demo: bool | None = None) -> Backend:
    demo = bool(int(os.environ.get("GUARDIAN_DEMO", "0"))) if demo is None else demo
    if demo:
        tmp = Path(tempfile.mkdtemp(prefix="guardian-demo-"))
        return Backend([FIXTURES], db_path=tmp / "demo.db", demo=True)
    roots = [config.WORKSPACE / "mreports"] + [Path(p) for p in os.environ.get("GUARDIAN_EXTRA_RUNS", "").split(os.pathsep) if p]
    return Backend(roots)


def dispatch(backend: Backend, method: str, path: str, query: dict, body: dict, token_ok: bool) -> tuple[int, object, str]:
    """Returns (status, payload, mime). payload is bytes for files, otherwise JSON-serialisable."""
    table = GET_ROUTES if method == "GET" else POST_ROUTES
    for rx, name in table:
        m = re.match(rx, path)
        if not m:
            continue
        g = [unquote(x) for x in m.groups()]
        q = {k: v[0] for k, v in query.items()}
        if method == "GET":
            if name == "session":
                return 200, {"demo": backend.demo}, "application/json"
            if name == "health":
                return 200, {"ok": True, "demo": backend.demo}, "application/json"
            if name == "list_scans":
                return 200, backend.list_scans(), "application/json"
            if name == "sbom":
                data, mime = backend.sbom(g[0], q.get("format", "cyclonedx"))
                return 200, data, mime
            if name == "validation_pr":
                data, mime = backend.validation_pr(g[0])
                return 200, data, mime
            if name == "report":
                data, mime = backend.report(g[0], q.get("format", "html"))
                return 200, data, mime
            if name == "graph":
                return 200, backend.graph(g[0], q.get("view", "risk"), q.get("node", ""), q.get("severity", "critical")), "application/json"
            if name == "findings":
                return 200, backend.findings(g[0], q), "application/json"
            if name == "review_items":
                return 200, backend.review_items(q.get("gate", "")), "application/json"
            return 200, getattr(backend, name)(*g), "application/json"
        if not token_ok:
            return 403, {"error": "Invalid same-origin session token"}, "application/json"
        if name == "lesson_decision":
            return 200, backend.decide(f"g8:{g[0]}", body), "application/json"
        if name == "start_workflow":
            return 200, backend.start_workflow(g[0], body), "application/json"
        if name == "suggest":
            return 200, backend.suggest(g[0], body), "application/json"
        if name in ("decide", "approve_plan", "validate", "publish_fix", "publish_workflow"):
            return 200, getattr(backend, name)(g[0], body), "application/json"
        return 200, getattr(backend, name)(body) if name != "refresh_scoreboard" else backend.refresh_scoreboard(), "application/json"
    return 404, {"error": "Not found"}, "application/json"


def serve(port: int = PORT, backend: Backend | None = None, ready=None) -> None:
    backend = backend or make_backend()
    token = secrets.token_urlsafe(32)
    hosts: set[str] = set()                           # filled once the real port is known (port 0 = pick a free one, for tests)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args) -> None:       # never log request lines: they can carry finding ids
            pass

        def send(self, status: int, payload, mime: str = "application/json") -> None:
            data = payload if isinstance(payload, bytes) else json.dumps(payload, default=str).encode()
            self.send_response(status)
            for k, v in (("Content-Type", mime), ("Content-Length", str(len(data))), ("X-Content-Type-Options", "nosniff"), ("Cache-Control", "no-store"),
                         ("Content-Security-Policy", CSP), ("Referrer-Policy", "no-referrer")):
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def handle_any(self, method: str) -> None:
            if self.headers.get("Host", "") not in hosts:
                return self.send(403, {"error": "Invalid Host"})
            u = urlparse(self.path)
            body: dict = {}
            token_ok = False
            try:
                if method == "POST":
                    origin = self.headers.get("Origin")
                    if origin and origin not in {f"http://{h}" for h in hosts}:
                        return self.send(403, {"error": "Cross-origin writes are blocked"})
                    token_ok = secrets.compare_digest(self.headers.get("X-Guardian-Token", ""), token)
                    if not token_ok:
                        return self.send(403, {"error": "Invalid same-origin session token"})
                    size = int(self.headers.get("Content-Length", "0"))
                    if not 0 < size <= MAX_BODY:
                        return self.send(400, {"error": "Invalid request size"})
                    body = json.loads(self.rfile.read(size))
                    if not isinstance(body, dict):
                        return self.send(400, {"error": "Expected a JSON object"})
                if method == "GET" and u.path == "/session":
                    return self.send(200, {"token": token, "demo": backend.demo})
                status, payload, mime = dispatch(backend, method, u.path, parse_qs(u.query), body, token_ok)
                self.send(status, payload, mime)
            except ApiError as e:
                self.send(e.status, {"error": e.message})
            except (ValueError, KeyError, TypeError) as e:
                self.send(400, {"error": str(e)[:300]})
            except Exception:  # noqa: BLE001
                self.send(500, {"error": "Internal error; see the Guardian server output"})

        def do_GET(self) -> None:
            self.handle_any("GET")

        def do_POST(self) -> None:
            self.handle_any("POST")

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    real = server.server_address[1]
    hosts.update({f"127.0.0.1:{real}", f"localhost:{real}"})
    server.guardian_token = token
    print(f"Guardian API on http://127.0.0.1:{real}{' (demo data)' if backend.demo else ''}", flush=True)
    if ready:
        ready(server)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        getattr(stream, "reconfigure", lambda **k: None)(errors="replace")
    serve()
