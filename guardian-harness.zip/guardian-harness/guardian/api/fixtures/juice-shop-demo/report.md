# Supply Chain Guardian report

Compared `v20.0.0` -> `HEAD`.

## What is in it
1682 packages (154 direct), 94 workflow steps, 5 base images.

## What changed
309 added, 594 removed, 174 updated.

## What is risky (225 findings: {'critical': 3, 'high': 59, 'medium': 93, 'low': 70})

### [CRITICAL 9.5] jsonwebtoken 0.4.0: CVE-2015-9235 Verification Bypass in jsonwebtoken
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-c7hr-j4mj-j2w6 matches jsonwebtoken@0.4.0 in package-lock.json
- evidence: severity 9.5 (advisory rating)
- evidence: fixed in: 4.2.2
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0
- why this score: severity 9.5 x reach 1.00 (direct dependency, scope runtime) = 9.5; reachable: imported in lib/insecurity.ts:11
- fixed in: 4.2.2

### [CRITICAL 9.5] marsdb 0.6.11: GHSA-5mrr-rgp6-x4gr Command Injection in marsdb
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-5mrr-rgp6-x4gr matches marsdb@0.6.11 in package-lock.json
- evidence: severity 9.5 (advisory rating)
- evidence: fixed in: no fixed version published
- evidence: data/mongodb.ts:7 imports marsdb
- path: app:package-lock.json > npm:marsdb@0.6.11
- why this score: severity 9.5 x reach 1.00 (direct dependency, scope runtime) = 9.5; reachable: imported in data/mongodb.ts:7


### [CRITICAL 8.1] jsonwebtoken 0.4.0: CVE-2022-23539 jsonwebtoken unrestricted key type could lead to legacy keys usage
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8cf7-32gw-wr33 matches jsonwebtoken@0.4.0 in package-lock.json
- evidence: severity 8.1 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0
- why this score: severity 8.1 x reach 1.00 (direct dependency, scope runtime) = 8.1; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [HIGH 8.0] .github/workflows/lint-fixer.yml:29 untrusted ${{ github.event.* }} used inside run: (script injection)
- type `workflow_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: .github/workflows/lint-fixer.yml:29: branch: ${{ github.head_ref }}
- why this score: rule expression-injection


### [HIGH 7.7] express-jwt 0.1.3: CVE-2020-15084 Authorization bypass in express-jwt
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-6g6m-m6h5-w9gf matches express-jwt@0.1.3 in package-lock.json
- evidence: severity 7.7 (CVSS)
- evidence: fixed in: 6.0.0
- evidence: lib/insecurity.ts:10 imports express-jwt
- path: app:package-lock.json > npm:express-jwt@0.1.3
- why this score: severity 7.7 x reach 1.00 (direct dependency, scope runtime) = 7.7; reachable: imported in lib/insecurity.ts:10
- fixed in: 6.0.0

### [HIGH 7.6] jsonwebtoken 0.1.0: CVE-2015-9235 Verification Bypass in jsonwebtoken
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-c7hr-j4mj-j2w6 matches jsonwebtoken@0.1.0 in package-lock.json
- evidence: severity 9.5 (advisory rating)
- evidence: fixed in: 4.2.2
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0
- why this score: severity 9.5 x reach 0.80 (transitive dependency, scope runtime) = 7.6; reachable: imported in lib/insecurity.ts:11
- fixed in: 4.2.2

### [HIGH 7.5] possible generic-api-key in test/api/passkey.test.ts:21 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: test/api/passkey.test.ts:21 matches generic-api-key; sha256 prefix 889711355f13; commit c5047c80218d
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] possible generic-api-key in data/static/users.yml:296 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: data/static/users.yml:296 matches generic-api-key; sha256 prefix 889711355f13; commit 072cee06f868
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] possible private-key in test/files/passkeyVictimCredential.json:4 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: test/files/passkeyVictimCredential.json:4 matches private-key; sha256 prefix 3021d90eb943; commit c91808770230
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] possible generic-api-key in frontend/src/app/forgot-password/forgot-password.component.spec.ts:119 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: frontend/src/app/forgot-password/forgot-password.component.spec.ts:119 matches generic-api-key; sha256 prefix d5cc6babb34f; commit 161679bdaf61
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] possible private-key in infrastructure/terraform/networking.tf:171 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: infrastructure/terraform/networking.tf:171 matches private-key; sha256 prefix 8bcac7908eb9; commit 458c66e82833
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] possible private-key in terraform/networking.tf:171 (value masked)
- type `secret_exposed`, confidence medium, verdict needs_validation, detector M18.secrets
- evidence: terraform/networking.tf:171 matches private-key; sha256 prefix 8bcac7908eb9; commit 614652f0e476
- why this score: credential pattern in an added line; only verified secrets are Critical


### [HIGH 7.5] sanitize-html 1.4.2: CVE-2022-25887 Sanitize-html Vulnerable To REDoS Attacks
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-cgfm-xwp7-2cvr matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 2.7.1
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 7.5 x reach 1.00 (direct dependency, scope runtime) = 7.5; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.7.1

### [HIGH 7.4] tar 6.2.1: CVE-2026-59873 node-tar: Decompression/parse DoS via unlimited input
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-23hp-3jrh-7fpw matches tar@6.2.1 in package-lock.json
- evidence: severity 9.2 (CVSS)
- evidence: fixed in: 7.5.19
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 9.2 x reach 0.80 (transitive dependency, scope runtime) = 7.4; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.19

### [HIGH 7.3] crypto-js 3.3.0: CVE-2023-46233 crypto-js PBKDF2 1,000 times weaker than specified in 1993 and 1.3M times weaker than current standard
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-xwcq-pm8m-c4vf matches crypto-js@3.3.0 in package-lock.json
- evidence: severity 9.1 (CVSS)
- evidence: fixed in: 4.2.0
- path: app:package-lock.json > npm:pdfkit@0.11.0 > npm:crypto-js@3.3.0
- why this score: severity 9.1 x reach 0.80 (transitive dependency, scope runtime) = 7.3; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.2.0

### [HIGH 7.3] lodash 2.4.2: CVE-2019-10744 Prototype Pollution in lodash
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-jf85-cpcp-j695 matches lodash@2.4.2 in package-lock.json
- evidence: severity 9.1 (CVSS)
- evidence: fixed in: 4.17.12
- path: app:package-lock.json > npm:sanitize-html@1.4.2 > npm:lodash@2.4.2
- why this score: severity 9.1 x reach 0.80 (transitive dependency, scope runtime) = 7.3; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.17.12

### [HIGH 7.2] crypto-js 3.3.0: CVE-2026-71851 crypto-js: Insufficient Entropy in Cryptographic Secret Generation via Vulnerable CryptoJS Dependency Chain
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-rg76-677x-56q9 matches crypto-js@3.3.0 in package-lock.json
- evidence: severity 9.0 (CVSS)
- evidence: fixed in: 4.0.0
- path: app:package-lock.json > npm:pdfkit@0.11.0 > npm:crypto-js@3.3.0
- why this score: severity 9.0 x reach 0.80 (transitive dependency, scope runtime) = 7.2; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.0.0

### [HIGH 7.0] first-time contributor touched sensitive files: Bump socket.io-client to 4.8.4  Signed-off-by: Abdullah Shahid <comrad (ed79ffaa)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: ed79ffaa74e1 new author 149247976+comradezephyr@users.noreply.github.com changed frontend/package.json
- why this score: new author 149247976+comradezephyr@users.noreply.github.com changed frontend/package.json


### [HIGH 7.0] first-time contributor touched sensitive files: Bumped socket.io , socket.io-client to 4.8.4   Signed-off-by: Abdullah (5058eabd)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 5058eabdd049 new author 149247976+comradezephyr@users.noreply.github.com changed package.json
- why this score: new author 149247976+comradezephyr@users.noreply.github.com changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: Fix scripts that use angular <22.2.0 stats.json filename for new brows (6e4c1457)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 6e4c145798fc new author smiley@smiley.bz changed frontend/package.json
- why this score: new author smiley@smiley.bz changed frontend/package.json


### [HIGH 7.0] first-time contributor touched sensitive files: Bump multer to 2.4.0  Signed-off-by: Abdullah Shahid <comradzephyr@gma (24d643c0)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 24d643c00bce new author 149247976+comradezephyr@users.noreply.github.com changed package.json
- why this score: new author 149247976+comradezephyr@users.noreply.github.com changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: chore: replacing archived get-tag action (ed33af1f)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: ed33af1f592b new author carrer1270@gmail.com changed .github/workflows/release.yml
- why this score: new author carrer1270@gmail.com changed .github/workflows/release.yml


### [HIGH 7.0] first-time contributor touched sensitive files: fix: address maintainer feedback on string similarity implementation (3006ba77)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 3006ba774258 new author inf23104@lehre.dhbw-stuttgart.de changed package.json
- why this score: new author inf23104@lehre.dhbw-stuttgart.de changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: feat: replace LLM judge with string similarity check via complaint for (ade5e87d)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: ade5e87d3efd new author inf23104@lehre.dhbw-stuttgart.de changed package.json
- why this score: new author inf23104@lehre.dhbw-stuttgart.de changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: fix: strengthen judge prompt and fix mock server bug (441222c2)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 441222c2c6bc new author inf23104@lehre.dhbw-stuttgart.de changed package.json
- why this score: new author inf23104@lehre.dhbw-stuttgart.de changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: fix: remove canary string, use pure LLM-as-a-judge for verification (3c6c4ffb)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 3c6c4ffb63e6 new author inf23104@lehre.dhbw-stuttgart.de changed package.json
- why this score: new author inf23104@lehre.dhbw-stuttgart.de changed package.json


### [HIGH 7.0] first-time contributor touched sensitive files: fix: update codefix files and sync RSN after chat.ts refactor (64b12549)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 64b12549eb8f new author inf23104@lehre.dhbw-stuttgart.de changed package.json
- why this score: new author inf23104@lehre.dhbw-stuttgart.de changed package.json


### [HIGH 7.0] jws 0.2.6: CVE-2016-1000223 Forgeable Public/Private Tokens in jws
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-gjcw-v447-2w7q matches jws@0.2.6 in package-lock.json
- evidence: severity 8.7 (CVSS)
- evidence: fixed in: 3.0.0
- evidence: lib/insecurity.ts:12 imports jws
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0 > npm:jws@0.2.6
- why this score: severity 8.7 x reach 0.80 (transitive dependency, scope runtime) = 7.0; reachable: imported in lib/insecurity.ts:12
- fixed in: 3.0.0

### [HIGH 7.0] tar 6.2.1: CVE-2026-59874 node-tar: Negative tar entry size causes infinite loop in archive replace
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8x88-c5mf-7j5w matches tar@6.2.1 in package-lock.json
- evidence: severity 8.7 (CVSS)
- evidence: fixed in: 7.5.18
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.7 x reach 0.80 (transitive dependency, scope runtime) = 7.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.18

### [HIGH 7.0] tar 6.2.1: CVE-2026-23950 Race Condition in node-tar Path Reservations via Unicode Ligature Collisions on macOS APFS
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-r6q2-hw4h-h46w matches tar@6.2.1 in package-lock.json
- evidence: severity 8.8 (CVSS)
- evidence: fixed in: 7.5.4
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.8 x reach 0.80 (transitive dependency, scope runtime) = 7.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.4

### [HIGH 6.9] Action calibreapp/image-actions@main is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/image_actions.yml:33: uses: calibreapp/image-actions@main
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 7.0 x reach 0.90 (runs in CI with access to repository secrets) x new-since-baseline 1.1 = 6.9


### [HIGH 6.9] Action peter-evans/create-pull-request@v8 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/image_actions.yml:42: uses: peter-evans/create-pull-request@v8
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 7.0 x reach 0.90 (runs in CI with access to repository secrets) x new-since-baseline 1.1 = 6.9


### [HIGH 6.8] zizmor cache-poisoning: runtime artifacts potentially vulnerable to a cache poisoning attack
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule cache-poisoning (confidence Low) at .github/workflows/ci.yml:2: generally used when publishing artifacts generated at runtime
- evidence: code: on:
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor cache-poisoning: runtime artifacts potentially vulnerable to a cache poisoning attack
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule cache-poisoning (confidence Low) at .github/workflows/frontend-bundle-analysis.yml:2: generally used when publishing artifacts generated at runtime
- evidence: code: on:
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor dangerous-triggers: use of fundamentally insecure workflow trigger
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule dangerous-triggers (confidence Medium) at .github/workflows/pr-compliance.yml:3: pull_request_target is almost always used insecurely
- evidence: code: on:
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor cache-poisoning: runtime artifacts potentially vulnerable to a cache poisoning attack
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule cache-poisoning (confidence Low) at .github/workflows/release.yml:2: generally used when publishing artifacts generated at runtime
- evidence: code: on:
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-ebook.yml:22: this step
- evidence: code: name: Update challenges.yml
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-ebook.yml:27: this step
- evidence: code: name: Update tags.yml
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-www-legacy.yml:26: this step
- evidence: code: name: Update challenges.yml
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-www-legacy.yml:35: this step
- evidence: code: name: Update snippets
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-www.yml:27: this step
- evidence: code: name: Update challenges.yml
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-www.yml:36: this step
- evidence: code: name: Update tags.yml
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-challenges-www.yml:45: this step
- evidence: code: name: Update snippets
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-news-www-legacy.yml:17: this step
- evidence: code: name: Update tab_news.md
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.8] zizmor template-injection: code injection via template expansion
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule template-injection (confidence High) at .github/workflows/update-news-www.yml:17: this step
- evidence: code: name: Update tab_news.md
- why this score: severity 7.5 x reach 0.90 (runs in CI with access to repository secrets) = 6.8


### [HIGH 6.6] tar 6.2.1: CVE-2026-24842 node-tar Vulnerable to Arbitrary File Creation/Overwrite via Hardlink Path Traversal
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-34x7-hfp2-rc4v matches tar@6.2.1 in package-lock.json
- evidence: severity 8.2 (CVSS)
- evidence: fixed in: 7.5.7
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.2 x reach 0.80 (transitive dependency, scope runtime) = 6.6; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.7

### [HIGH 6.6] tar 6.2.1: CVE-2026-23745 node-tar is Vulnerable to Arbitrary File Overwrite and Symlink Poisoning via Insufficient Path Sanitization
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8qq5-rm4j-mr97 matches tar@6.2.1 in package-lock.json
- evidence: severity 8.2 (CVSS)
- evidence: fixed in: 7.5.3
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.2 x reach 0.80 (transitive dependency, scope runtime) = 6.6; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.3

### [HIGH 6.6] tar 6.2.1: CVE-2026-31802 node-tar Symlink Path Traversal via Drive-Relative Linkpath
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-9ppj-qmqm-q256 matches tar@6.2.1 in package-lock.json
- evidence: severity 8.2 (CVSS)
- evidence: fixed in: 7.5.11
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.2 x reach 0.80 (transitive dependency, scope runtime) = 6.6; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.11

### [HIGH 6.6] tar 6.2.1: CVE-2026-29786 tar has Hardlink Path Traversal via Drive-Relative Linkpath
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-qffp-2rhf-9h96 matches tar@6.2.1 in package-lock.json
- evidence: severity 8.2 (CVSS)
- evidence: fixed in: 7.5.10
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 8.2 x reach 0.80 (transitive dependency, scope runtime) = 6.6; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.10

### [HIGH 6.5] jsonwebtoken 0.1.0: CVE-2022-23539 jsonwebtoken unrestricted key type could lead to legacy keys usage
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8cf7-32gw-wr33 matches jsonwebtoken@0.1.0 in package-lock.json
- evidence: severity 8.1 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0
- why this score: severity 8.1 x reach 0.80 (transitive dependency, scope runtime) = 6.5; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [HIGH 6.5] notevil 1.3.3: CVE-2021-23771 Sandbox escape in notevil and argencoders-notevil
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8g4m-cjm2-96wq matches notevil@1.3.3 in package-lock.json
- evidence: severity 6.5 (CVSS)
- evidence: fixed in: no fixed version published
- evidence: routes/b2bOrder.ts:9 imports notevil
- path: app:package-lock.json > npm:notevil@1.3.3
- why this score: severity 6.5 x reach 1.00 (direct dependency, scope runtime) = 6.5; reachable: imported in routes/b2bOrder.ts:9


### [HIGH 6.4] jsonwebtoken 0.4.0: CVE-2022-23540 jsonwebtoken vulnerable to signature validation bypass due to insecure default algorithm in jwt.verify()
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-qwph-4952-7xr6 matches jsonwebtoken@0.4.0 in package-lock.json
- evidence: severity 6.4 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0
- why this score: severity 6.4 x reach 1.00 (direct dependency, scope runtime) = 6.4; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [HIGH 6.1] sanitize-html 1.4.2: CVE-2016-1000237 Cross-Site Scripting in sanitize-html
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-3j7m-hmh3-9jmp matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 6.1 (CVSS)
- evidence: fixed in: 1.4.3
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 6.1 x reach 1.00 (direct dependency, scope runtime) = 6.1; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 1.4.3

### [HIGH 6.1] sanitize-html 1.4.2: CVE-2026-63670 ApostropheCMS: Mutation-XSS / allowedTags bypass via literal `</textarea/>` solidus close
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-jxwj-j7wr-gfrw matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 6.1 (CVSS)
- evidence: fixed in: 2.17.6
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 6.1 x reach 1.00 (direct dependency, scope runtime) = 6.1; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.17.6

### [HIGH 6.1] sanitize-html 1.4.2: CVE-2019-25225 sanitize-html is vulnerable to XSS through incomprehensive sanitization
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-qhxp-v273-g94h matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 6.1 (CVSS)
- evidence: fixed in: 2.0.0-beta
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 6.1 x reach 1.00 (direct dependency, scope runtime) = 6.1; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.0.0-beta

### [HIGH 6.0] ws 8.18.0: CVE-2026-48779 ws: Memory exhaustion DoS from tiny fragments and data chunks
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-96hv-2xvq-fx4p matches ws@8.18.0 in frontend/package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 5.2.5, 6.2.4, 7.5.11, 8.21.0
- path: app:frontend/package-lock.json > npm:ethers@5.8.0 > npm:@ethersproject/providers@5.8.0 > npm:ws@8.18.0
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 5.2.5, 6.2.4, 7.5.11, 8.21.0

### [HIGH 6.0] jws 0.2.6: CVE-2025-65945 auth0/node-jws Improperly Verifies HMAC Signature
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-869p-cjfg-cm3x matches jws@0.2.6 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 3.2.3, 4.0.1
- evidence: lib/insecurity.ts:12 imports jws
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0 > npm:jws@0.2.6
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; reachable: imported in lib/insecurity.ts:12
- fixed in: 3.2.3, 4.0.1

### [HIGH 6.0] lodash 2.4.2: CVE-2018-16487 Prototype Pollution in lodash
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-4xc9-xhrj-v574 matches lodash@2.4.2 in package-lock.json
- evidence: severity 7.5 (advisory rating)
- evidence: fixed in: 4.17.11
- path: app:package-lock.json > npm:sanitize-html@1.4.2 > npm:lodash@2.4.2
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.17.11

### [HIGH 6.0] moment 2.0.0: CVE-2017-18214 Regular Expression Denial of Service in moment
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-446m-mv8f-q348 matches moment@2.0.0 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 2.19.3
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0 > npm:moment@2.0.0
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 2.19.3

### [HIGH 6.0] moment 2.0.0: CVE-2022-24785 Path Traversal: 'dir/../../filename' in moment.locale
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-8hfj-j24r-96c4 matches moment@2.0.0 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 2.29.2
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0 > npm:moment@2.0.0
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 2.29.2

### [HIGH 6.0] tar 6.2.1: CVE-2026-73566 node-tar: Uncontrolled recursion in mapHas/filesFilter allows uncatchable stack-overflow DoS via crafted long-path tar with member selection
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-r292-9mhp-454m matches tar@6.2.1 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 7.5.21
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.21

### [HIGH 6.0] uuid 8.3.2: CVE-2026-41907 uuid: Missing buffer bounds check in v3/v5/v6 when buf is provided
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-w5hq-g745-h8pq matches uuid@8.3.2 in package-lock.json
- evidence: severity 7.5 (CVSS)
- evidence: fixed in: 11.1.1, 12.0.1, 13.0.1
- path: app:package-lock.json > npm:sequelize@6.37.8 > npm:uuid@8.3.2
- why this score: severity 7.5 x reach 0.80 (transitive dependency, scope runtime) = 6.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 11.1.1, 12.0.1, 13.0.1

### [MEDIUM 5.9] .github/workflows/ci.yml:353 downloads code and runs it
- type `unpinned_action`, confidence high, verdict confirmed, detector workflow-parser
- evidence: rule download-and-run matched .github/workflows/ci.yml:353: run: curl https://cli-assets.heroku.com/install.sh | sh
- evidence: the script is fetched and executed unchecked, so whoever controls that URL controls this CI job
- why this score: severity 6.5 x reach 0.90 (runs in CI with access to repository secrets) = 5.9


### [MEDIUM 5.8] lodash 2.4.2: CVE-2021-23337 Command Injection in lodash
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-35jh-r3h4-6jhm matches lodash@2.4.2 in package-lock.json
- evidence: severity 7.2 (CVSS)
- evidence: fixed in: 4.17.21
- path: app:package-lock.json > npm:sanitize-html@1.4.2 > npm:lodash@2.4.2
- why this score: severity 7.2 x reach 0.80 (transitive dependency, scope runtime) = 5.8; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.17.21

### [MEDIUM 5.7] tar 6.2.1: CVE-2026-26960 Arbitrary File Read/Write via Hardlink Target Escape Through Symlink Chain in node-tar Extraction
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-83g3-92jg-28cx matches tar@6.2.1 in package-lock.json
- evidence: severity 7.1 (CVSS)
- evidence: fixed in: 7.5.8
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 7.1 x reach 0.80 (transitive dependency, scope runtime) = 5.7; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.8

### [MEDIUM 5.5] sanitize-html 1.4.2: CVE-2017-16016 Cross-Site Scripting in sanitize-html
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-xc6g-ggrc-qq4r matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.5 (advisory rating)
- evidence: fixed in: 1.11.4
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.5 x reach 1.00 (direct dependency, scope runtime) = 5.5; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 1.11.4

### [MEDIUM 5.5] tar 6.2.1: CVE-2026-53655 node-tar applies PAX size override to intermediary GNU long-name/long-link headers, causing tar parser interpretation differential (file smuggling)
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-vmf3-w455-68vh matches tar@6.2.1 in package-lock.json
- evidence: severity 6.9 (CVSS)
- evidence: fixed in: 7.5.16
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 6.9 x reach 0.80 (transitive dependency, scope runtime) = 5.5; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.16

### [MEDIUM 5.4] sanitize-html 1.4.2: CVE-2026-113661 ApostropheCMS: Incomplete CVE-2026-53606: `meta http-equiv=refresh` `content` still ships `javascript:` / `data:` URLs
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-cv27-6wvh-8x7j matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.4 (CVSS)
- evidence: fixed in: 2.18.0
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.4 x reach 1.00 (direct dependency, scope runtime) = 5.4; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.18.0

### [MEDIUM 5.4] Action coverallsapp/github-action@v2 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/ci.yml:198: uses: coverallsapp/github-action@v2
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 6.0 x reach 0.90 (runs in CI with access to repository secrets) = 5.4


### [MEDIUM 5.3] file-type 16.5.4: CVE-2026-31808 file-type affected by infinite loop in ASF parser on malformed input with zero-size sub-header
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-5v7r-6r5c-r473 matches file-type@16.5.4 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 21.3.1
- evidence: routes/profileImageFileUpload.ts:8 imports file-type
- path: app:package-lock.json > npm:file-type@16.5.4
- why this score: severity 5.3 x reach 1.00 (direct dependency, scope runtime) = 5.3; reachable: imported in routes/profileImageFileUpload.ts:8
- fixed in: 21.3.1

### [MEDIUM 5.3] sanitize-html 1.4.2: CVE-2021-26540 Improper Input Validation in sanitize-html
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-mjxr-4v3x-q3m4 matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 2.3.2
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.3 x reach 1.00 (direct dependency, scope runtime) = 5.3; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.3.2

### [MEDIUM 5.3] sanitize-html 1.4.2: CVE-2021-26539 Improper Input Validation in sanitize-html
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-rjqq-98f6-6j3r matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 2.3.1
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.3 x reach 1.00 (direct dependency, scope runtime) = 5.3; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.3.1

### [MEDIUM 5.3] sanitize-html 1.4.2: CVE-2024-21501 sanitize-html Information Exposure vulnerability
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-rm97-x556-q36h matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 2.12.1
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.3 x reach 1.00 (direct dependency, scope runtime) = 5.3; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.12.1

### [MEDIUM 5.3] sanitize-html 1.4.2: CVE-2026-113654 ApostropheCMS sanitize-html: nonTextTags discard region ends early on an implied close, letting <noscript> content render
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-x3q4-9hxx-gx8m matches sanitize-html@1.4.2 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 2.18.0
- evidence: lib/challengeUtils.ts:5 imports sanitize-html
- path: app:package-lock.json > npm:sanitize-html@1.4.2
- why this score: severity 5.3 x reach 1.00 (direct dependency, scope runtime) = 5.3; reachable: imported in lib/challengeUtils.ts:5
- fixed in: 2.18.0

### [MEDIUM 5.2] lodash 2.4.2: CVE-2018-3721 Prototype Pollution in lodash
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-fvqr-27wr-82fm matches lodash@2.4.2 in package-lock.json
- evidence: severity 6.5 (CVSS)
- evidence: fixed in: 4.17.5
- path: app:package-lock.json > npm:sanitize-html@1.4.2 > npm:lodash@2.4.2
- why this score: severity 6.5 x reach 0.80 (transitive dependency, scope runtime) = 5.2; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 4.17.5

### [MEDIUM 5.2] moment 2.0.0: CVE-2016-4055 Regular Expression Denial of Service in moment
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-87vv-r9j6-g5qv matches moment@2.0.0 in package-lock.json
- evidence: severity 6.5 (CVSS)
- evidence: fixed in: 2.11.2
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0 > npm:moment@2.0.0
- why this score: severity 6.5 x reach 0.80 (transitive dependency, scope runtime) = 5.2; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 2.11.2

### [MEDIUM 5.1] jsonwebtoken 0.1.0: CVE-2022-23540 jsonwebtoken vulnerable to signature validation bypass due to insecure default algorithm in jwt.verify()
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-qwph-4952-7xr6 matches jsonwebtoken@0.1.0 in package-lock.json
- evidence: severity 6.4 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0
- why this score: severity 6.4 x reach 0.80 (transitive dependency, scope runtime) = 5.1; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [MEDIUM 5.0] test/smoke/Dockerfile:6 no USER instruction: the container runs as root
- type `dockerfile_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: test/smoke/Dockerfile:6: 
- why this score: rule no-user


### [MEDIUM 5.0] jsonwebtoken 0.4.0: CVE-2022-23541 jsonwebtoken's insecure implementation of key retrieval function could lead to Forgeable Public/Private Tokens from RSA to HMAC
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-hjrf-2m68-5959 matches jsonwebtoken@0.4.0 in package-lock.json
- evidence: severity 5.0 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0
- why this score: severity 5.0 x reach 1.00 (direct dependency, scope runtime) = 5.0; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [MEDIUM 5.0] Action actions/checkout@v6 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/image_actions.yml:30: uses: actions/checkout@v6
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) x new-since-baseline 1.1 = 5.0


### [MEDIUM 4.5] Dockerfile:22 base image uses :latest or no tag
- type `dockerfile_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: Dockerfile:22: FROM gcr.io/distroless/nodejs24-debian13
- why this score: rule latest-tag


### [MEDIUM 4.5] infrastructure/Dockerfile:14 base image uses :latest or no tag
- type `dockerfile_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: infrastructure/Dockerfile:14: FROM base AS production
- why this score: rule latest-tag


### [MEDIUM 4.5] test/smoke/Dockerfile:1 base image uses :latest or no tag
- type `dockerfile_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: test/smoke/Dockerfile:1: FROM alpine
- why this score: rule latest-tag


### [MEDIUM 4.5] elliptic 6.6.1: CVE-2025-14505 Elliptic Uses a Cryptographic Primitive with a Risky Implementation
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-848j-6mx2-7j84 matches elliptic@6.6.1 in frontend/package-lock.json
- evidence: severity 5.6 (CVSS)
- evidence: fixed in: no fixed version published
- path: app:frontend/package-lock.json > npm:ethers@5.8.0 > npm:@ethersproject/signing-key@5.8.0 > npm:elliptic@6.6.1
- why this score: severity 5.6 x reach 0.80 (transitive dependency, scope runtime) = 4.5; transitive dependency: reachability depends on how its dependents use it (not lowered)


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:29: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:46: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:65: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:106: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:145: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:183: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:205: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:236: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:267: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:303: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:312: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/ci.yml:350: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:1: default permissions used due to no permissions: block
- evidence: code: name: "CI/CD Pipeline"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:26: this job
- evidence: code: lint:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:43: this job
- evidence: code: coding-challenge-rsn:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:58: this job
- evidence: code: frontend-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:99: this job
- evidence: code: server-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:138: this job
- evidence: code: api-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:178: this job
- evidence: code: coverage-report:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:202: this job
- evidence: code: custom-config-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:233: this job
- evidence: code: e2e-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:262: this job
- evidence: code: smoke-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:300: this job
- evidence: code: docker-test:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:307: this job
- evidence: code: docker:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:345: this job
- evidence: code: heroku:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/ci.yml:370: this job
- evidence: code: notify-slack:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/codeql-analysis.yml:20: does not set persist-credentials: false
- evidence: code: name: Checkout repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/frontend-bundle-analysis.yml:17: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/frontend-bundle-analysis.yml:14: this job
- evidence: code: bundle-analysis:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/image_actions.yml:21: this job
- evidence: code: build:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/lint-fixer.yml:12: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/lint-fixer.yml:9: this job
- evidence: code: LMLFTFY:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/rebase.yml:13: does not set persist-credentials: false
- evidence: code: uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 #v7.0.1
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/rebase.yml:1: default permissions used due to no permissions: block
- evidence: code: name: Automatic Rebase
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/rebase.yml:8: this job
- evidence: code: rebase:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/rebase.yml:21: this job
- evidence: code: always_job:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor archived-uses: action or reusable workflow from archived repository
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule archived-uses (confidence High) at .github/workflows/rebase.yml:16: this step
- evidence: code: name: Automatic Rebase
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/release.yml:14: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/release.yml:47: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/release.yml:80: does not set persist-credentials: false
- evidence: code: name: "Check out Git repository"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/release.yml:1: default permissions used due to no permissions: block
- evidence: code: name: "Release Pipeline"
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/release.yml:11: this job
- evidence: code: create-release:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/release.yml:22: this job
- evidence: code: package:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/release.yml:77: this job
- evidence: code: docker:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/release.yml:108: this job
- evidence: code: notify-slack:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/stale.yml:7: this job
- evidence: code: stale:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-challenges-ebook.yml:16: does not set persist-credentials: false
- evidence: code: name: Check out Git repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/update-challenges-ebook.yml:12: this job
- evidence: code: UpdateChallengesOnWebsite:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-challenges-www-legacy.yml:16: does not set persist-credentials: false
- evidence: code: name: Check out Git repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-challenges-www-legacy.yml:22: does not set persist-credentials: false
- evidence: code: name: Check out juice-shop source
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/update-challenges-www-legacy.yml:12: this job
- evidence: code: UpdateChallengesOnWebsite:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-challenges-www.yml:17: does not set persist-credentials: false
- evidence: code: name: Check out Git repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-challenges-www.yml:23: does not set persist-credentials: false
- evidence: code: name: Check out juice-shop source
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/update-challenges-www.yml:13: this job
- evidence: code: UpdateChallengesOnWebsite:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-news-www-legacy.yml:11: does not set persist-credentials: false
- evidence: code: name: Check out Git repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/update-news-www-legacy.yml:8: this job
- evidence: code: UpdateNewsOnWebsite:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/update-news-www.yml:11: does not set persist-credentials: false
- evidence: code: name: Check out Git repository
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.5] zizmor excessive-permissions: overly broad permissions
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule excessive-permissions (confidence Medium) at .github/workflows/update-news-www.yml:8: this job
- evidence: code: UpdateNewsOnWebsite:
- why this score: severity 5.0 x reach 0.90 (runs in CI with access to repository secrets) = 4.5


### [MEDIUM 4.4] base64url 0.0.6: GHSA-rvg8-pwq2-xj7q Out-of-bounds Read in base64url
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-rvg8-pwq2-xj7q matches base64url@0.0.6 in package-lock.json
- evidence: severity 5.5 (advisory rating)
- evidence: fixed in: 3.0.0
- path: app:package-lock.json > npm:jsonwebtoken@0.4.0 > npm:jws@0.2.6 > npm:base64url@0.0.6
- why this score: severity 5.5 x reach 0.80 (transitive dependency, scope runtime) = 4.4; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 3.0.0

### [MEDIUM 4.4] Build file changed: infrastructure/Dockerfile
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: A infrastructure/Dockerfile
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) x new-since-baseline 1.1 = 4.4


### [MEDIUM 4.4] Build file changed: infrastructure/docker-compose.yml
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: A infrastructure/docker-compose.yml
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) x new-since-baseline 1.1 = 4.4


### [MEDIUM 4.2] tar 6.2.1: CVE-2026-59875 node-tar: Uncaught Exception DoS via NUL byte in PAX path/linkpath records
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-gvwx-54wh-qm9j matches tar@6.2.1 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 7.5.17
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 5.3 x reach 0.80 (transitive dependency, scope runtime) = 4.2; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.17

### [MEDIUM 4.2] tar 6.2.1: CVE-2026-59871 node-tar: Process crash via PAX numeric path type confusion
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-w8wr-v893-vjvp matches tar@6.2.1 in package-lock.json
- evidence: severity 5.3 (CVSS)
- evidence: fixed in: 7.5.18
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:tar@6.2.1
- why this score: severity 5.3 x reach 0.80 (transitive dependency, scope runtime) = 4.2; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 7.5.18

### [MEDIUM 4.0] cli-table3 was downgraded 0.6.5 -> 0.6.1
- type `suspicious_update`, confidence medium, verdict confirmed, detector change-agent
- evidence: baseline had cli-table3@0.6.5; head has @0.6.1 (package-lock.json)
- why this score: severity 5.0 x reach 0.80 (default) = 4.0


### [MEDIUM 4.0] jsonwebtoken 0.1.0: CVE-2022-23541 jsonwebtoken's insecure implementation of key retrieval function could lead to Forgeable Public/Private Tokens from RSA to HMAC
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-hjrf-2m68-5959 matches jsonwebtoken@0.1.0 in package-lock.json
- evidence: severity 5.0 (CVSS)
- evidence: fixed in: 9.0.0
- evidence: lib/insecurity.ts:11 imports jsonwebtoken
- path: app:package-lock.json > npm:express-jwt@0.1.3 > npm:jsonwebtoken@0.1.0
- why this score: severity 5.0 x reach 0.80 (transitive dependency, scope runtime) = 4.0; reachable: imported in lib/insecurity.ts:11
- fixed in: 9.0.0

### [MEDIUM 4.0] Base image gcr.io/distroless/nodejs24-debian13:latest is not pinned by digest
- type `untrusted_image`, confidence medium, verdict confirmed, detector dockerfile-parser
- evidence: Dockerfile:22: FROM gcr.io/distroless/nodejs24-debian13 (no @sha256 digest)
- why this score: severity 4.5 x reach 0.90 (base image of the shipped container) = 4.0


### [MEDIUM 4.0] Base image alpine:latest is not pinned by digest
- type `untrusted_image`, confidence medium, verdict confirmed, detector dockerfile-parser
- evidence: test/smoke/Dockerfile:1: FROM alpine (no @sha256 digest)
- why this score: severity 4.5 x reach 0.90 (base image of the shipped container) = 4.0


### [MEDIUM 4.0] Build file changed: Dockerfile
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: M Dockerfile
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) = 4.0


### [MEDIUM 4.0] Build file changed: frontend/package.json
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: M frontend/package.json
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) = 4.0


### [MEDIUM 4.0] Build file changed: package.json
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: M package.json
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) = 4.0


### [MEDIUM 4.0] Build file changed: test/smoke/smoke-test.sh
- type `suspicious_update`, confidence medium, verdict confirmed, detector backdoor-agent
- evidence: git diff v20.0.0..HEAD: M test/smoke/smoke-test.sh
- why this score: severity 4.0 x reach 1.00 (runs at install or build time on developer and CI machines) = 4.0


### [LOW 3.6] @cyclonedx/cyclonedx-npm 4.2.1: CVE-2026-71538 @cyclonedx/cyclonedx-npm: Shell Injection via Unsanitized --workspace Argument on Windows
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-q69g-4hcv-6jg4 matches @cyclonedx/cyclonedx-npm@4.2.1 in package-lock.json
- evidence: severity 8.5 (CVSS)
- evidence: fixed in: 6.0.0
- path: app:package-lock.json > npm:@cyclonedx/cyclonedx-npm@4.2.1
- why this score: severity 8.5 x reach 0.60 (direct dependency used only in development/test) = 5.1; not reachable: direct dependency never imported by application source (tests excluded), score -1.5
- fixed in: 6.0.0

### [LOW 3.6] @cyclonedx/cyclonedx-npm 4.2.1: CVE-2026-55849 @cyclonedx/cyclonedx-npm: Shell Injection via Unsanitized --workspace Argument
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-v75r-vx73-82pj matches @cyclonedx/cyclonedx-npm@4.2.1 in package-lock.json
- evidence: severity 8.5 (CVSS)
- evidence: fixed in: 5.0.0
- path: app:package-lock.json > npm:@cyclonedx/cyclonedx-npm@4.2.1
- why this score: severity 8.5 x reach 0.60 (direct dependency used only in development/test) = 5.1; not reachable: direct dependency never imported by application source (tests excluded), score -1.5
- fixed in: 5.0.0

### [LOW 3.6] Action github/codeql-action/init@v3 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/codeql-analysis.yml:23: uses: github/codeql-action/init@v3
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 4.0 x reach 0.90 (runs in CI with access to repository secrets) = 3.6


### [LOW 3.6] Action github/codeql-action/autobuild@v3 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/codeql-analysis.yml:34: uses: github/codeql-action/autobuild@v3
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 4.0 x reach 0.90 (runs in CI with access to repository secrets) = 3.6


### [LOW 3.6] Action github/codeql-action/analyze@v3 is pinned to a tag, not a commit SHA
- type `unpinned_action`, confidence medium, verdict confirmed, detector workflow-parser
- evidence: .github/workflows/codeql-analysis.yml:36: uses: github/codeql-action/analyze@v3
- evidence: a tag can be moved to a different commit (as in the tj-actions/changed-files compromise, CVE-2025-30066)
- why this score: severity 4.0 x reach 0.90 (runs in CI with access to repository secrets) = 3.6


### [LOW 3.5] ws 8.18.0: CVE-2026-45736 ws: Uninitialized memory disclosure
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-58qx-3vcg-4xpx matches ws@8.18.0 in frontend/package-lock.json
- evidence: severity 4.4 (CVSS)
- evidence: fixed in: 8.20.1
- path: app:frontend/package-lock.json > npm:ethers@5.8.0 > npm:@ethersproject/providers@5.8.0 > npm:ws@8.18.0
- why this score: severity 4.4 x reach 0.80 (transitive dependency, scope runtime) = 3.5; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 8.20.1

### [LOW 3.5] Base image node:20.19.2-bookworm-slim is not pinned by digest
- type `untrusted_image`, confidence medium, verdict confirmed, detector dockerfile-parser
- evidence: infrastructure/Dockerfile:1: FROM node:20.19.2-bookworm-slim (no @sha256 digest)
- why this score: severity 3.5 x reach 0.90 (base image of the shipped container) x new-since-baseline 1.1 = 3.5


### [LOW 3.5] Base image node:20.19.2-bookworm is not pinned by digest
- type `untrusted_image`, confidence medium, verdict confirmed, detector dockerfile-parser
- evidence: infrastructure/Dockerfile:6: FROM node:20.19.2-bookworm (no @sha256 digest)
- why this score: severity 3.5 x reach 0.90 (base image of the shipped container) x new-since-baseline 1.1 = 3.5


### [LOW 3.3] minimatch 9.0.9: CVE-2026-118764 minimatch has potential denial of service via globparts amplification
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-g3hv-75wg-m249 matches minimatch@9.0.9 in package-lock.json
- evidence: severity 6.9 (CVSS)
- evidence: fixed in: 11.0.1
- path: app:package-lock.json > npm:@cyclonedx/cyclonedx-npm@4.2.1 > npm:libxmljs2@0.37.0 > npm:node-gyp@11.5.0 > npm:make-fetch-happen@14.0.3 > npm:cacache@19.0.1 > npm:glob@10.5.0 > npm:minimatch@9.0.9
- why this score: severity 6.9 x reach 0.48 (transitive dependency used only in development/test) = 3.3; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 11.0.1

### [LOW 3.1] Base image node:24 is not pinned by digest
- type `untrusted_image`, confidence medium, verdict confirmed, detector dockerfile-parser
- evidence: Dockerfile:1: FROM node:24 (no @sha256 digest)
- why this score: severity 3.5 x reach 0.90 (base image of the shipped container) = 3.1


### [LOW 3.0] infrastructure/Dockerfile:11 COPY . . without a .dockerignore can ship .git and secrets
- type `dockerfile_issue`, confidence high, verdict confirmed, detector M5.dockerfile
- evidence: infrastructure/Dockerfile:11: COPY . .
- why this score: rule copy-all-no-dockerignore


### [LOW 3.0] large mixed commit: Introduce several "Technology" tags for challenges (b58c5907)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: b58c5907f1fb 46 files in one commit
- why this score: 46 files in one commit


### [LOW 3.0] author and committer differ: Compress Images (d9bd0eca)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: d9bd0eca2354 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (1ed951f7)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 1ed951f7e8f5 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (f040f680)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: f040f6803f7d author J12934 <13718901+J12934@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author J12934 <13718901+J12934@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] large mixed commit: Remove 6x AVIF product images for all products (b8e9a995)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: b8e9a995bbaa 54 files in one commit
- why this score: 54 files in one commit


### [LOW 3.0] large mixed commit: Add 3x AVIF product images for all products (9ec5ba92)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 9ec5ba92b9c5 54 files in one commit
- why this score: 54 files in one commit


### [LOW 3.0] large mixed commit: Add 2x AVIF product images for all products (83620ccf)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 83620ccf38c5 54 files in one commit
- why this score: 54 files in one commit


### [LOW 3.0] large mixed commit: Add 1x AVIF product images for all products (550476dd)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 550476dd3f46 54 files in one commit
- why this score: 54 files in one commit


### [LOW 3.0] author and committer differ: Compress Images (62a698e6)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 62a698e6bb48 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Node @type/node (e3343c50)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: e3343c50b1ed author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Add allowed scripts for frontend package json (0be17250)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 0be172501924 author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Replace grunt with a simple(ish) script to package the app (7fa7ad76)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 7fa7ad76e35a author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Allow sqlite, esbuild (used by tsx) and cypress for the backend packag (192ce86b)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 192ce86b5184 author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Fix typescript 6.0 depracations (3acae403)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 3acae403041d author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Properly adopt test mocks for angularx-qrcode (4a33cd42)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 4a33cd4214b2 author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Update to Angular 22 (367aa21c)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 367aa21c8a94 author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] large mixed commit: Update to Angular 22 (367aa21c)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 367aa21c8a94 78 files in one commit
- why this score: 78 files in one commit


### [LOW 3.0] author and committer differ: Switch to more maintained qr code lib (020ecf2c)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 020ecf2c6231 author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] author and committer differ: Fix expected challenge name for e2e test after challenge name tweak (1b8ab387)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 1b8ab387725c author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>
- why this score: author Jannik Hollenbach <jannik.hollenbach@owasp.org> but committer Bjoern Kimminich <bjoern.kimminich@kuehne-nagel.com>


### [LOW 3.0] large mixed commit: Update to Angular 22 (6d98c83b)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 6d98c83b2946 78 files in one commit
- why this score: 78 files in one commit


### [LOW 3.0] author and committer differ: Compress Images (3f9b8505)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 3f9b8505a8e5 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (2c5125e8)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 2c5125e8d9b9 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] large mixed commit: Add Gitpod to environments in danger zone description translations (a818a29e)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: a818a29e1b4c 42 files in one commit
- why this score: 42 files in one commit


### [LOW 3.0] author and committer differ: Compress Images (8f0684a5)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 8f0684a5b833 author J12934 <13718901+J12934@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author J12934 <13718901+J12934@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (9655fd51)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 9655fd51fd98 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (45073584)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 450735845f70 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (7f400c90)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 7f400c90a07e author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (29c5a4b1)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 29c5a4b11408 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (bf3b24d8)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: bf3b24d86018 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] author and committer differ: Compress Images (2af989e9)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 2af989e95250 author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>
- why this score: author bkimminich <3531020+bkimminich@users.noreply.github.com> but committer github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>


### [LOW 3.0] large mixed commit: Compress Images (2af989e9)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 2af989e95250 87 files in one commit
- why this score: 87 files in one commit


### [LOW 3.0] large mixed commit: Remove gitpod from supported ignored envs (8f4e1a2e)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 8f4e1a2ef18b 46 files in one commit
- why this score: 46 files in one commit


### [LOW 3.0] large mixed commit: Migrate server unit test suite to use the node.js test runner (525a87ed)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: 525a87edbd82 47 files in one commit
- why this score: 47 files in one commit


### [LOW 3.0] author and committer differ: Fix 401 Unauthorized response when using forged JWT tokens for challen (a7c12792)
- type `history_anomaly`, confidence medium, verdict confirmed, detector M17.history
- evidence: git log v20.0.0..HEAD: a7c127928dda author shadowshan125 <ajaykrishnan114cs@gmail.com> but committer Jannik Hollenbach <jannik.hollenbach@owasp.org>
- why this score: author shadowshan125 <ajaykrishnan114cs@gmail.com> but committer Jannik Hollenbach <jannik.hollenbach@owasp.org>


### [LOW 3.0] glob 10.5.0: CVE-2026-118773 Glob: AbortSignal cancellation bypass allows post-timeout filesystem traversal
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-3g3m-2fjr-6pw4 matches glob@10.5.0 in package-lock.json
- evidence: severity 6.3 (CVSS)
- evidence: fixed in: 14.0.2
- path: app:package-lock.json > npm:@cyclonedx/cyclonedx-npm@4.2.1 > npm:libxmljs2@0.37.0 > npm:node-gyp@11.5.0 > npm:make-fetch-happen@14.0.3 > npm:cacache@19.0.1 > npm:glob@10.5.0
- why this score: severity 6.3 x reach 0.48 (transitive dependency used only in development/test) = 3.0; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 14.0.2

### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:35: this step
- evidence: code: name: "Install application minimalistically"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:52: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:73: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:114: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:153: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:211: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:242: this step
- evidence: code: name: "Install CLI tools"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence high, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/ci.yml:273: this step
- evidence: code: name: "Install CLI tools"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/frontend-bundle-analysis.yml:25: this step
- evidence: code: name: "Install backend dependencies"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/frontend-bundle-analysis.yml:41: this step
- evidence: code: name: "Install Playwright for screenshot"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor artipacked: credential persistence through GitHub Actions artifacts
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule artipacked (confidence Low) at .github/workflows/image_actions.yml:29: does not set persist-credentials: false
- evidence: code: name: Checkout Branch
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/lint-fixer.yml:18: this step
- evidence: code: name: "Install application"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] zizmor adhoc-packages: ad-hoc installation of packages
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule adhoc-packages (confidence High) at .github/workflows/release.yml:53: this step
- evidence: code: name: "Install CLI tools"
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.7] actionlint expression: property "os" is not defined in object type {}
- type `unpinned_action`, confidence medium, verdict confirmed, detector actionlint
- evidence: .github\workflows\ci.yml:212: property "os" is not defined in object type {}
- evidence: .github\workflows\ci.yml:212: property "node-version" is not defined in object type {}
- why this score: severity 3.0 x reach 0.90 (runs in CI with access to repository secrets) = 2.7


### [LOW 2.6] @tootallnate/once 1.1.2: CVE-2026-3449 @tootallnate/once vulnerable to Incorrect Control Flow Scoping
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-vpq2-c234-7xj6 matches @tootallnate/once@1.1.2 in package-lock.json
- evidence: severity 3.3 (CVSS)
- evidence: fixed in: 2.0.1, 3.0.1
- path: app:package-lock.json > npm:sqlite3@5.1.7 > npm:node-gyp@8.4.1 > npm:make-fetch-happen@9.1.0 > npm:http-proxy-agent@4.0.1 > npm:@tootallnate/once@1.1.2
- why this score: severity 3.3 x reach 0.80 (transitive dependency, scope runtime) = 2.6; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 2.0.1, 3.0.1

### [LOW 2.5] hbs 4.4.0: CVE-2021-32822 hbs: Insertion of Sensitive Information into Externally-Accessible File or Directory and Exposure of Sensitive Information to an Unauthorized Actor
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-7f5c-rpf4-86p8 matches hbs@4.4.0 in package-lock.json
- evidence: severity 4.0 (CVSS)
- evidence: fixed in: no fixed version published
- path: app:package-lock.json > npm:hbs@4.4.0
- why this score: severity 4.0 x reach 1.00 (direct dependency, scope runtime) = 4.0; not reachable: direct dependency never imported by application source (tests excluded), score -1.5


### [LOW 1.8] New direct dependency @simplewebauthn/server@14.1.0
- type `unexpected_dependency`, confidence medium, verdict confirmed, detector change-agent
- evidence: not present in baseline; declared in package-lock.json
- why this score: severity 2.0 x reach 0.80 (default) x new-since-baseline 1.1 = 1.8


### [LOW 1.8] New direct dependency libxml2-wasm@0.7.2
- type `unexpected_dependency`, confidence medium, verdict confirmed, detector change-agent
- evidence: not present in baseline; declared in package-lock.json
- why this score: severity 2.0 x reach 0.80 (default) x new-since-baseline 1.1 = 1.8


### [LOW 1.8] New direct dependency proxy-agent@8.0.3
- type `unexpected_dependency`, confidence medium, verdict confirmed, detector change-agent
- evidence: not present in baseline; declared in package-lock.json
- why this score: severity 2.0 x reach 0.80 (default) x new-since-baseline 1.1 = 1.8


### [LOW 1.8] New direct dependency @simplewebauthn/browser@14.0.0
- type `unexpected_dependency`, confidence medium, verdict confirmed, detector change-agent
- evidence: not present in baseline; declared in frontend/package-lock.json
- why this score: severity 2.0 x reach 0.80 (default) x new-since-baseline 1.1 = 1.8


### [LOW 1.8] New direct dependency angularx-qrcode@21.0.5
- type `unexpected_dependency`, confidence medium, verdict confirmed, detector change-agent
- evidence: not present in baseline; declared in frontend/package-lock.json
- why this score: severity 2.0 x reach 0.80 (default) x new-since-baseline 1.1 = 1.8


### [LOW 1.4] messageformat 2.3.0: CVE-2025-57349 messageformat has a prototype pollution vulnerability
- type `known_vulnerability`, confidence medium, verdict confirmed, detector osv-scanner
- evidence: OSV GHSA-xfqm-j7pc-xrfc matches messageformat@2.3.0 in package-lock.json
- evidence: severity 1.7 (CVSS)
- evidence: fixed in: 3.0.0-beta.0
- path: app:package-lock.json > npm:i18n@0.11.1 > npm:messageformat@2.3.0
- why this score: severity 1.7 x reach 0.80 (transitive dependency, scope runtime) = 1.4; transitive dependency: reachability depends on how its dependents use it (not lowered)
- fixed in: 3.0.0-beta.0

### [LOW 1.4] zizmor superfluous-actions: action functionality is already included by the runner
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule superfluous-actions (confidence High) at .github/workflows/release.yml:16: this step
- evidence: code: name: "Create Release"
- why this score: severity 1.5 x reach 0.90 (runs in CI with access to repository secrets) = 1.4


### [LOW 1.4] zizmor superfluous-actions: action functionality is already included by the runner
- type `unpinned_action`, confidence medium, verdict confirmed, detector zizmor
- evidence: zizmor rule superfluous-actions (confidence High) at .github/workflows/release.yml:70: this step
- evidence: code: name: 'Attach packaged archive to tag release'
- why this score: severity 1.5 x reach 0.90 (runs in CI with access to repository secrets) = 1.4


## Self-check (canary)
- PASS typosquat-rule: crossenv -> cross-env
- PASS backdoor-rules: base64 eval line
- PASS bidi-rule: U+202E
- PASS ai-injection-rule: injection comment
- PASS workflow-parser: some-org/some-action@v1
- PASS zizmor: unpinned-uses expected
- PASS osv-scanner: lodash 4.17.15 advisories expected (needs network to osv.dev)

## Coverage and limits
- no lockfile committed in ['.', 'frontend']: versions were resolved at scan time with --ignore-scripts (no package code was run), so they show what a fresh install would get today
- M18 secrets: gitleaks not installed, used built-in patterns on added lines only (no history or image layers)
- Absence of findings is not absence of a backdoor.