"""M2 graph views for the console. Elements are Cytoscape-shaped; every number comes from the inventory and the findings.

Views: risk (how risk enters: shortest paths from the app to every affected component, plus finding and evidence-file nodes),
trace (one package: paths to it, its dependents and dependencies), full (the whole network, capped).
"""
from __future__ import annotations

from collections import deque

SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "unknown": 0}
FULL_CAP = 300


def _app(key: str) -> str:
    return "app" if key.startswith("app:") else key


def _adj(inv: dict) -> dict[str, set[str]]:
    adj: dict[str, set[str]] = {}
    for a, bs in (inv.get("graph") or {}).items():
        for b in bs:
            adj.setdefault(_app(a), set()).add(_app(b))
    return adj


def _bfs_depths(adj: dict[str, set[str]]) -> dict[str, int]:
    depth, q = {"app": 0}, deque(["app"])
    while q:
        n = q.popleft()
        for m in adj.get(n, ()):
            if m not in depth:
                depth[m] = depth[n] + 1
                q.append(m)
    return depth


def _node(inv: dict, key: str, worst: dict[str, str], direct: set[str]) -> dict:
    p = (inv.get("packages") or {}).get(key, {})
    return {"data": {"id": key, "label": "app" if key == "app" else f"{p.get('name', key)}@{p.get('version', '')}".rstrip("@"),
                     "kind": "app" if key == "app" else "package", "ecosystem": p.get("ecosystem", ""), "direct": key in direct,
                     "severity": worst.get(key, ""), "scope": p.get("scope", "")}}


def _worst(findings: list[dict]) -> dict[str, str]:
    worst: dict[str, str] = {}
    for f in findings:
        k = f.get("component_key")
        if k and f.get("badge") not in (None, "Needs validation") and SEV_ORDER.get(f["severity"], 0) >= SEV_ORDER.get(worst.get(k, "unknown"), -1):
            worst[k] = f["severity"]
    return worst


def analytics(inv: dict) -> dict:
    adj = _adj(inv)
    depth = _bfs_depths(adj)
    indeg: dict[str, int] = {}
    for a, bs in adj.items():
        for b in bs:
            indeg[b] = indeg.get(b, 0) + 1

    def reach(start: str) -> int:
        seen, q = {start}, deque([start])
        while q:
            for m in adj.get(q.popleft(), ()):
                if m not in seen:
                    seen.add(m)
                    q.append(m)
        return len(seen) - 1
    pk = inv.get("packages") or {}
    label = lambda k: f"{pk.get(k, {}).get('name', k)}@{pk.get(k, {}).get('version', '')}"   # noqa: E731
    blast = sorted(((k, reach(k)) for k in list(adj)[:2000] if k != "app"), key=lambda x: -x[1])[:5]
    return {"max_depth": max(depth.values(), default=0), "packages": len(pk),
            "blast_radius": [{"id": k, "label": label(k), "reaches": n} for k, n in blast],
            "most_depended_on": [{"id": k, "label": label(k), "dependents": n} for k, n in sorted(indeg.items(), key=lambda x: -x[1])[:5] if k != "app"]}


RISK_CAP = 40       # findings drawn in the risk view; a graph of every finding is a flat unreadable line


def build(inv: dict, findings: list[dict], view: str = "risk", node: str = "", severity: str = "critical") -> dict:
    adj = _adj(inv)
    direct = {_app(k) for ks in (inv.get("roots") or {}).values() for k in ks}
    worst = _worst(findings)
    total = len(inv.get("packages") or {})
    keep: set[str] = {"app"}
    edges: set[tuple[str, str, str]] = set()
    extra_nodes: list[dict] = []
    note = ""
    if view == "risk":
        pool = [f for f in findings if f.get("status") != "suppressed" and f.get("verdict") != "needs_validation" and f.get("component_key")
                and (severity == "all" or f["severity"] == severity)]
        pool.sort(key=lambda f: (-SEV_ORDER.get(f["severity"], 0), -f["score"]))
        if len(pool) > RISK_CAP:
            note = f"showing the {RISK_CAP} highest-scoring of {len(pool)} {severity} findings"
        for f in pool[:RISK_CAP]:
            k = f.get("component_key")
            is_pkg = k in (inv.get("packages") or {})
            path = ([_app(x) for x in (f.get("dependency_paths") or [[]])[0]] or ["app", k]) if is_pkg else []
            path = [("app" if i == 0 else x) for i, x in enumerate(path)]
            keep.update(x for x in path if x == "app" or x in (inv.get("packages") or {}))
            edges.update((a, b, "depends_on") for a, b in zip(path, path[1:]))
            fid = f"finding:{f['fingerprint'][:12]}"
            badge = f.get("badge") or f["severity"]
            extra_nodes.append({"data": {"id": fid, "label": f["title"][:48], "kind": "finding", "severity": f["severity"] if f.get("badge") not in ("Needs validation",) else "", "badge": badge}})
            if is_pkg:
                edges.add((k, fid, "affects"))
            else:
                edges.add(("app", fid, "affects"))
            loc = (f.get("location") or {}).get("file")
            if loc:
                fn = f"file:{loc}"
                if not any(n["data"]["id"] == fn for n in extra_nodes):
                    extra_nodes.append({"data": {"id": fn, "label": loc, "kind": "file"}})
                edges.add((fid, fn, "evidenced_in"))
    elif view == "trace":
        if not node:
            raise ValueError("choose a package to trace")
        target = next((k for k in (inv.get("packages") or {}) if k == node or inv["packages"][k].get("name") == node), None)
        if not target:
            raise KeyError(f"No package {node}")
        parents: dict[str, str] = {}
        q = deque(["app"])
        seen = {"app"}
        while q:                                         # shortest path from the app, plus every direct dependent and dependency
            n = q.popleft()
            for m in adj.get(n, ()):
                if m not in seen:
                    seen.add(m)
                    parents[m] = n
                    q.append(m)
        cur = target
        keep.add(target)
        while cur in parents:
            edges.add((parents[cur], cur, "depends_on"))
            cur = parents[cur]
            keep.add(cur)
        for a, bs in adj.items():
            if target in bs:
                keep.add(a)
                edges.add((a, target, "depends_on"))
        for b in adj.get(target, ()):
            keep.add(b)
            edges.add((target, b, "depends_on"))
    else:                                                # full network, capped
        order = ["app"] + sorted((k for k in (inv.get("packages") or {}) if k in worst), key=lambda k: -SEV_ORDER.get(worst[k], 0))
        order += [k for k in (inv.get("packages") or {}) if k in direct and k not in worst]
        q = deque(order)
        while q and len(keep) < FULL_CAP:
            keep.add(q.popleft())
        for k in list(adj):
            for m in adj[k]:
                if k in keep and m in keep:
                    edges.add((k, m, "depends_on"))
        if total + 1 > len(keep):
            note = f"showing {len(keep)} of {total + 1}; full graph in export"
    nodes = [_node(inv, k, worst, direct) for k in sorted(keep)] + extra_nodes
    ids = {n["data"]["id"] for n in nodes}
    return {"view": view, "elements": {"nodes": nodes, "edges": [{"data": {"id": f"{a}>{b}", "source": a, "target": b, "relation": r}} for a, b, r in sorted(edges) if a in ids and b in ids]},
            "shown": len(nodes), "total": total + 1, "note": note, "analytics": analytics(inv)}
