"""M5 images: Dockerfile / Compose image inventory, digest pins, and optional Trivy image CVE scans.

Ported from GuardianAI day1 (team): guardian/containers.py. Differences: reads files through the bounded reader, returns
new-schema findings, and runs Trivy through our `tools.run` (secrets stripped) instead of a hand-built environment.
Image scanning is opt-in; when Trivy is missing the result says "Not run", never "no vulnerabilities".
"""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
from pathlib import Path

from ..core import Finding
from ..tools import find_exe, run
from .discovery import SKIP_DIRS
from .formats import bounded_read, yaml_data

SEV = {"Critical": ("critical", 9.0), "High": ("high", 7.5), "Medium": ("medium", 5.0), "Low": ("low", 2.5)}
COMPOSE_NAMES = ("docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml")


def _fp(*parts: str) -> str:
    return hashlib.sha256("|".join(parts).encode()).hexdigest()


def inspect(root: Path, scan_images: bool = False, offline: bool = False, detector: str = "M5.images") -> tuple[list[Finding], dict]:
    findings: list[Finding] = []
    images: list[dict] = []
    warnings: list[str] = []

    def record(ref: str, file: str, line: int) -> None:
        if not any(i["reference"] == ref for i in images):
            images.append({"reference": ref, "file": file, "line": line, "status": "static only"})

    def floating(file: str, line: int, text: str, what: str) -> None:
        findings.append(Finding(type="untrusted_image", title=f"{file}:{line} {what}", detector=detector, location={"file": file, "line": line, "snippet": text.strip()[:120]},
                                evidence=[{"kind": "file_line", "ref": f"{file}:{line}: {text.strip()[:120]}"}], severity="medium", score=4.5, confidence="high",
                                verdict="confirmed", score_reasons=["image is not pinned by digest, so its content can change silently"],
                                fingerprint=_fp("floating", file, str(line))))
    for p in root.rglob("*"):
        if not p.is_file() or any(part in SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        name, rel = p.name, p.relative_to(root).as_posix()
        is_docker = name.startswith("Dockerfile") or name.endswith(".Dockerfile") or name == "Containerfile"
        if not (is_docker or name in COMPOSE_NAMES):
            continue
        text = bounded_read(p)
        if text is None:
            warnings.append(f"{rel}: skipped (symlink, binary or above the size budget)")
            continue
        lines = text.splitlines()
        if is_docker:
            args: dict[str, str] = {}
            stages: set[str] = set()
            for num, line in enumerate(lines, 1):
                arg = re.match(r"\s*ARG\s+(\w+)=(\S+)", line, re.I)
                if arg:
                    args[arg[1]] = arg[2].strip("\"'")
                m = re.match(r"\s*FROM\s+(?:--platform=\S+\s+)?(\S+)(?:\s+AS\s+(\S+))?", line, re.I)
                if m:
                    ref = m[1]
                    for k, v in args.items():
                        ref = ref.replace("${" + k + "}", v).replace("$" + k, v)
                    if ref.lower() != "scratch" and ref.lower() not in stages:
                        record(ref, rel, num)
                        if not re.search(r"@sha256:[a-f0-9]{64}$", ref):
                            floating(rel, num, line, "container base image is not digest-pinned")
                    if m[2]:
                        stages.add(m[2].lower())
        else:
            try:
                data = yaml_data(text)
                for service, config in (data.get("services") or {}).items():
                    if not isinstance(config, dict) or not config.get("image"):
                        continue
                    ref = str(config["image"])
                    num = next((i for i, l in enumerate(lines, 1) if ref in l), 1)
                    record(ref, rel, num)
                    if "@sha256:" not in ref:
                        floating(rel, num, lines[num - 1], f"compose service {service} uses an image without a digest")
            except (ValueError, TypeError) as exc:
                warnings.append(f"{rel}: {exc}")

    trivy = find_exe("trivy")
    for image in images:
        if not scan_images:
            continue
        if offline:
            image.update(status="unavailable", error="Offline mode: remote image scan disabled")
            continue
        if not trivy:
            image.update(status="unavailable", error="Not run: Trivy is not installed (OS and image-layer CVE scanning needs it)")
            continue
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/:@-]*", image["reference"]):
            image.update(status="unavailable", error="Unresolved or unsupported image reference")
            continue
        with tempfile.TemporaryDirectory(prefix="guardian-trivy-") as tmp:
            out = Path(tmp) / "report.json"
            r = run("trivy", ["image", "--image-src", "remote", "--scanners", "vuln", "--format", "json", "--output", str(out), "--timeout", "120s", "--", image["reference"]],
                    cwd=tmp, timeout=180)
            if not r.ok or not out.exists() or out.stat().st_size > 32 * 1024 * 1024:
                image.update(status="failed", error=(r.stderr[-300:] or "Trivy produced no usable report"))
                continue
            report = json.loads(out.read_text(encoding="utf-8"))
        image.update(status="complete", digest=report.get("Metadata", {}).get("RepoDigests", []))
        for target in report.get("Results", []):
            for v in target.get("Vulnerabilities") or []:
                sev, score = SEV.get(str(v.get("Severity", "")).title(), ("medium", 4.0))
                fixed = [v["FixedVersion"]] if v.get("FixedVersion") else []
                findings.append(Finding(type="known_vulnerability", title=f"{image['reference']}: {v.get('PkgName')} {v['VulnerabilityID']}", detector=detector,
                                        package={"ecosystem": "image", "name": str(v.get("PkgName", "")), "version": str(v.get("InstalledVersion", ""))},
                                        location={"file": image["file"], "line": image["line"]}, advisory_ids=[v["VulnerabilityID"]], fixed_versions=fixed,
                                        evidence=[{"kind": "tool_output", "ref": f"Trivy {v['VulnerabilityID']} in {image['reference']} ({target.get('Target')})"}],
                                        severity=sev, score=score, confidence="high", verdict="confirmed", score_reasons=[f"Trivy severity {v.get('Severity')}"],
                                        fingerprint=_fp("trivy", image["reference"], str(v.get("PkgName")), v["VulnerabilityID"])))
    info = {"images": images, "warnings": warnings, "image_scanner": "Trivy" if trivy else "not installed", "requested": scan_images}
    return findings, info
