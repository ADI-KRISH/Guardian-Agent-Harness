"""M9 lead agent + M19 verifier agent, run after a modular scan.

Lead: picks the findings that most need judgement (Critical first, within the budget) and has the investigator (an LLM with
read-only tools confined to the checkout) look at the real code. M19: a second pass with no shared context checks every AI claim:
an AI "false positive" verdict needs a cited file:line that exists in the checkout, otherwise it is dropped to "unclear".
The AI can never close, lower or suppress a deterministic finding; its text is stored as inference, never as evidence.
The executive summary is built from the data, so every number in it is a fact.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .. import config
from . import llm
from . import investigator, verifier

CITE = re.compile(r"([\w./\\-]+\.[A-Za-z0-9]+):(\d+)")


def accept(ans: dict, finding_id: str, known_ids: set[str]) -> dict | None:
    """Ported from GuardianAI day1 (team): ai.investigate checks. Accept an answer only if it is about a finding that exists,
    cap its length, and record model, prompt hash and temperature 0. Prose is always unverified inference."""
    if finding_id not in known_ids or not isinstance(ans.get("text"), str) or not ans["text"].strip():
        return None
    return {**ans, "finding_id": finding_id, "text": ans["text"][:2000], "temperature": 0, "kind": "inferred",
            "verification": "finding id validated; model prose is unverified inference"}


def verify_claim(ans: dict, head_dir: Path) -> dict:
    """M19. Returns the checked claim: final verdict, citation status, and why."""
    raw = ans.get("verdict", "unclear")
    cites = [(f, int(n)) for f, n in CITE.findall(ans.get("text", ""))]
    ok = next(((f, n) for f, n in cites if verifier._line(head_dir, f.replace("\\", "/"), n) is not None), None)
    final, why = raw, "claim kept"
    if raw == "likely_false_positive" and not ok:
        final, why = "unclear", "dropped: a false-positive claim must cite a file and line that exist in the checkout"
    elif raw == "likely_real" and not ok:
        why = "kept as inference: no verifiable citation, so it adds no confidence"
    return {"ai_verdict": raw, "final_verdict": final, "citation": f"{ok[0]}:{ok[1]}" if ok else None, "why": why, "is_evidence": False}


def summary(report: dict, legacy: list[dict], checks: list[dict]) -> str:
    """Facts only: counts, titles and versions come from the findings, never from a model."""
    act = [f for f in legacy if not f.get("suppressed_by")]
    lv = {k: sum(1 for f in act if f["risk_level"] == k) for k in ("Critical", "High", "Medium", "Low")}
    out = [f"{len(act)} findings between {report.get('base_ref') or 'no baseline'} and {report['head_ref']}: " +
           ", ".join(f"{v} {k}" for k, v in lv.items() if v) + ".", "", "Top risks:"]
    for f in sorted(act, key=lambda x: -x["score"])[:5]:
        fx = f"; fixed in {', '.join(f['fixed_versions'][:2])}" if f.get("fixed_versions") else ""
        out.append(f"- [{f['risk_level']} {f['score']}] {f['title'][:110]}{fx}")
    if checks:
        out += ["", "AI investigations (inference, checked by the verifier agent):"]
        out += [f"- {c['finding']}: AI said {c['ai_verdict']}, verified result {c['final_verdict']} ({c['why']})" for c in checks]
    return "\n".join(out)


def run(out_dir: Path, mem=None, log=print) -> dict:
    out_dir = Path(out_dir)
    report = json.loads((out_dir / "legacy_report.json").read_text(encoding="utf-8"))
    inv = json.loads((out_dir / "inventory.json").read_text(encoding="utf-8"))
    legacy = report["findings"]
    cfg = config.load(None)
    project = report["project"]
    head_dir = config.WORKSPACE / "checkouts" / project / re.sub(r"[^A-Za-z0-9_.-]", "_", report["head_ref"])
    checks, notes = [], []
    if not llm.agentic_ok(cfg):
        notes.append("LLM not configured or unreachable: investigations skipped, deterministic results only")
    else:
        todo = sorted((f for f in legacy if not f.get("suppressed_by")), key=lambda f: -f["score"])[: cfg["llm"]["max_findings_investigated"]]
        ctx = {"head_dir": head_dir, "repo": config.WORKSPACE / "repos" / project, "base_ref": report.get("base_ref"),
               "head_ref": report["head_ref"], "head": inv}
        for f in todo:
            log(f"  [investigator] {f['id']}")
            ans = investigator.investigate(cfg, f, ctx)
            if not ans.get("text"):
                notes.append(f"{f['id']}: investigation failed ({ans.get('error', '?')[:120]})")
                continue
            ans = accept(ans, f["id"], {x["id"] for x in legacy})
            if ans is None:
                notes.append(f"{f['id']}: model answer rejected (unknown finding id or empty text)")
                continue
            chk = verify_claim(ans, head_dir) | {"finding": f["id"], "model": ans["model"], "text": ans["text"],
                                                  "tool_calls": ans.get("tool_calls", []),
                                                  "prompt_sha": ans.get("prompt_sha", ""), "temperature": 0}
            checks.append(chk)
            if mem:
                mem.decide(f"inv-{out_dir.name}", project, "verifier-agent", f"{f['id']}: {chk['final_verdict']}", chk["why"], {"ai": chk["ai_verdict"]}, rule="ai-claim-check")
    (out_dir / "investigations.json").write_text(json.dumps({"checks": checks, "notes": notes}, indent=2), encoding="utf-8")
    text = summary(report, legacy, checks) + ("\n\nNotes: " + "; ".join(notes) if notes else "")
    (out_dir / "summary.md").write_text(text, encoding="utf-8")
    return {"checks": checks, "notes": notes, "summary": text}
