"""Reputation check for typosquat candidates (M3).

A name that is one edit from a popular package is a candidate, not proof: `prompt`, `utile` and `listr` are real packages that merely sit near
other names. Before a candidate is reported as Critical, ask the registry how long the package has existed, how many versions it has and (npm)
how much it is downloaded. An established package is almost certainly legitimate, so the finding is demoted with the facts that justified it.
A young or thin package stays Critical. A failed lookup is NOT guessed either way: the finding becomes "needs validation".
Network goes only to the public registries; answers are cached for 7 days.
"""
from __future__ import annotations

import json
import urllib.request
from datetime import datetime, timezone

MIN_AGE_DAYS = 365
MIN_VERSIONS = 5
MIN_WEEKLY_DOWNLOADS = 10_000


def _get(url: str) -> dict:
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "SupplyChainGuardian/1"}), timeout=8) as r:
        return json.loads(r.read(4 * 1024 * 1024))


def _days(ts: str) -> int:
    return (datetime.now(timezone.utc) - datetime.fromisoformat(ts.replace("Z", "+00:00"))).days


def lookup(eco: str, name: str, memory=None, fetch=_get) -> dict:
    """{state: ran|failed, age_days, versions, weekly_downloads, established, why}. Never raises."""
    key = f"rep:{eco}:{name}"
    cached = memory.cache_get(key, 7 * 86400) if memory else None
    if cached is not None:
        return cached
    try:
        if eco == "npm":
            meta = fetch(f"https://registry.npmjs.org/{name.replace('/', '%2f')}")
            created = (meta.get("time") or {}).get("created")
            versions = len(meta.get("versions") or {})
            try:
                weekly = int(fetch(f"https://api.npmjs.org/downloads/point/last-week/{name.replace('/', '%2f')}").get("downloads", 0))
            except Exception:  # noqa: BLE001 - downloads are a bonus signal; age and versions can decide alone
                weekly = None
        elif eco == "PyPI":
            meta = fetch(f"https://pypi.org/pypi/{name}/json")
            uploads = [u["upload_time_iso_8601"] for files in (meta.get("releases") or {}).values() for u in files if u.get("upload_time_iso_8601")]
            created, versions, weekly = (min(uploads) if uploads else None), len(meta.get("releases") or {}), None
        else:
            return {"state": "failed", "why": f"no registry lookup for {eco}"}
        age = _days(created) if created else None
    except Exception as e:  # noqa: BLE001 - registry down or the name does not exist: say so, do not guess
        return {"state": "failed", "why": f"{type(e).__name__}: {str(e)[:100]}"}
    established = bool(age is not None and ((age >= MIN_AGE_DAYS and versions >= MIN_VERSIONS) or (weekly or 0) >= MIN_WEEKLY_DOWNLOADS))
    bits = [f"first published {age} days ago" if age is not None else "publish date unknown", f"{versions} versions"] + ([f"{weekly:,} downloads last week"] if weekly is not None else [])
    out = {"state": "ran", "age_days": age, "versions": versions, "weekly_downloads": weekly, "established": established, "why": ", ".join(bits)}
    if memory:
        memory.cache_put(key, out)
    return out


MAX_AGE_DAYS = 90            # first published more recently than this: a lookalike is suspicious
MAX_SHARE = 0.01             # less than 1% of the imitated package's weekly downloads: nobody uses it


def is_squat(rep: dict, target: dict) -> tuple[bool, str]:
    """A lookalike is a typosquat only when the name is itself unpopular: under 1% of the target's weekly downloads (and under 10,000 in absolute terms: a package a 100x-bigger neighbour dwarfs is still popular), or first published
    under 90 days ago. With no download figure it falls back to the age and version history; with no registry answer at all it falls back to
    the top-5,000 list (the lookalike already is not in it), so ngy-cookie and lodahs stay flagged."""
    if rep["state"] != "ran":
        return True, "the registry has no usable record, and the name is not in the top-5,000 list"
    age, dl, tdl = rep.get("age_days"), rep.get("weekly_downloads"), (target or {}).get("weekly_downloads")
    if age is not None and age < MAX_AGE_DAYS:
        return True, f"first published {age} days ago (under {MAX_AGE_DAYS})"
    if dl is not None and tdl:
        share = dl / tdl
        return (share < MAX_SHARE and dl < MIN_WEEKLY_DOWNLOADS), f"{dl:,} weekly downloads is {share:.2%} of the imitated package's {tdl:,}"
    return not rep["established"], rep["why"]


def apply(findings: list[dict], memory=None, fetch=_get, budget: int = 60) -> dict:
    """Drop legacy typosquat findings that fail is_squat, in place. Returns counts for the report."""
    counts = {"checked": 0, "dropped": 0, "kept": 0, "unverified": 0}
    drop = set()
    for f in findings:
        if f["type"] != "typosquat":
            continue
        eco, _, rest = f["component"].partition(":")
        name = rest.rpartition("@")[0]
        if counts["checked"] >= budget or not name:
            continue
        counts["checked"] += 1
        rep = lookup(eco, name, memory, fetch)
        target = lookup(eco, f["similar_to"], memory, fetch) if f.get("similar_to") and rep["state"] == "ran" else None
        squat, why = is_squat(rep, target)
        if rep["state"] != "ran":
            f["verdict"], f["missing_fact"] = "needs_validation", f"the registry could not be asked how established '{name}' is ({rep['why']})"
            counts["unverified"] += 1
        elif not squat:
            drop.add(id(f))
            counts["dropped"] += 1
            continue
        else:
            counts["kept"] += 1
        f["verified_evidence"].append(f"registry: {why}")
    findings[:] = [f for f in findings if id(f) not in drop]
    return counts
