"""Vulnerability agent: known vulnerabilities (OSV) traced back through the dependency graph."""
from __future__ import annotations

from pathlib import Path

from ..tools import scanners
from . import finding
from .discovery import paths_to, pkey

GHSA_SEV = {"CRITICAL": 9.5, "HIGH": 7.5, "MODERATE": 5.5, "MEDIUM": 5.5, "LOW": 3.0}


def _fixed(v: dict, name: str) -> list[str]:
    out = []
    for aff in v.get("affected", []):
        if aff.get("package", {}).get("name", "").lower() != name.lower():
            continue
        for rng in aff.get("ranges", []):
            out += [e["fixed"] for e in rng.get("events", []) if "fixed" in e]
    return sorted(set(out))


def scan(head_dir: Path, head: dict, base: dict | None) -> tuple[list[dict], dict]:
    r = scanners.osv_scan(head_dir)
    data = r.json() or {}
    findings = []
    base_pk = (base or {}).get("packages", {})
    for res in data.get("results", []):
        src = res.get("source", {}).get("path", "")
        try:
            src_rel = str(Path(src).resolve().relative_to(head_dir.resolve())).replace("\\", "/")
        except ValueError:
            src_rel = src
        for pkg in res.get("packages", []):
            p = pkg.get("package", {})
            name, ver, eco = p.get("name", ""), p.get("version", ""), p.get("ecosystem", "")
            k = pkey(eco, name, ver)
            vulns = {v["id"]: v for v in pkg.get("vulnerabilities", [])}
            for g in pkg.get("groups", []) or [{"ids": [i]} for i in vulns]:
                ids = g.get("ids", [])
                v = next((vulns[i] for i in ids if i in vulns), {})
                aliases = sorted(set(ids + g.get("aliases", []) + v.get("aliases", [])))
                cves = [a for a in aliases if a.startswith("CVE-")]
                sev = None
                try:
                    sev = float(g.get("max_severity")) if g.get("max_severity") not in (None, "") else None
                except ValueError:
                    sev = None
                unknown_sev = False
                if sev is None:
                    rating = str(v.get("database_specific", {}).get("severity", "")).upper()
                    unknown_sev = rating not in GHSA_SEV
                    sev = GHSA_SEV.get(rating, 0.0)      # no CVSS and no rating: Unknown, never Low
                fixed = _fixed(v, name)
                meta = head["packages"].get(k, {})
                is_new = k not in base_pk
                primary = (cves or ids or ["?"])[0]
                f = finding("known_vulnerability", f"{name} {ver}: {primary} {v.get('summary', '')}".strip(),
                            component=k, detector="osv-scanner", severity=sev,
                            location={"file": src_rel},
                            change="introduced since baseline" if (base and is_new) else ("present in baseline" if base else ""),
                            verified_evidence=[f"OSV {', '.join(ids)} matches {name}@{ver} in {src_rel}",
                                               f"severity {sev} ({'CVSS' if g.get('max_severity') else 'advisory rating'})",
                                               f"fixed in: {', '.join(fixed) or 'no fixed version published'}"],
                            extra={"id": primary, "advisory_ids": ids, "aliases": aliases, "fixed_versions": fixed,
                                   "scope": meta.get("scope", "unknown"), "severity_unknown": unknown_sev},
                            recommendation=(f"Upgrade {name} to {fixed[0]} or later" if fixed else "No fix published: consider replacing or mitigating") )
                f["dependency_paths"] = paths_to(k, head["graph"], head["roots"])
                findings.append(f)
    return findings, r.meta()


# ---------------------------------------------------------------------------------------------
# API fallback. Ported from GuardianAI day1 (team): guardian/osv.py (exact-version query with pagination, aliases, fix
# boundaries, 24 h cache, offline mode). OSV-Scanner stays primary; this covers a missing scanner and offline cached runs.
# ---------------------------------------------------------------------------------------------
import json  # noqa: E402
import re  # noqa: E402
import urllib.request  # noqa: E402
from concurrent.futures import ThreadPoolExecutor, as_completed  # noqa: E402

OSV_URL = "https://api.osv.dev/v1/query"
MAX_RESPONSE = 8 * 1024 * 1024
QUERY_BUDGET = 10000


def _osv_request(payload: dict) -> dict:
    req = urllib.request.Request(OSV_URL, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", "User-Agent": "SupplyChainGuardian/1"})
    with urllib.request.urlopen(req, timeout=12) as response:
        raw = response.read(MAX_RESPONSE + 1)
        if len(raw) > MAX_RESPONSE:
            raise ValueError("OSV response exceeded size budget")
        return json.loads(raw)


def osv_fetch(eco: str, name: str, version: str, request=_osv_request) -> list[dict]:
    """Network part only (safe to run in a worker thread): all pages of advisories for one exact package version."""
    payload = {"package": {"name": name, "ecosystem": eco}, "version": version}
    advisories: list[dict] = []
    for _ in range(12):
        page = request(payload)
        advisories.extend(page.get("vulns", []))
        if not page.get("next_page_token"):
            return advisories
        payload["page_token"] = page["next_page_token"]
    raise ValueError("OSV pagination budget exhausted")


def osv_query(eco: str, name: str, version: str, memory, offline: bool = False, request=_osv_request) -> tuple[list[dict], str]:
    """One exact-version lookup with the 24 h cache; says where the answer came from: cached | live | unavailable (...)."""
    key = f"osv:{eco}:{name}:{version}"
    cached = memory.cache_get(key, 86400) if memory else None
    if cached is not None:
        return cached, "cached"
    if offline:
        return [], "unavailable (offline; no fresh cache)"
    advisories = osv_fetch(eco, name, version, request)
    if memory:
        memory.cache_put(key, advisories)
    return advisories, "live"


def scan_api(head: dict, base: dict | None, memory, offline: bool = False, request=_osv_request) -> tuple[list[dict], list[dict]]:
    """Legacy-format findings plus a per-component coverage list. Unresolved versions are listed as gaps, never queried or called clean."""
    findings, coverage, unique = [], [], {}
    base_pk = (base or {}).get("packages", {})
    for k, p in head["packages"].items():
        if not p.get("ecosystem") or not re.fullmatch(r"v?\d[\w.+!\-]*", str(p.get("version", ""))):
            coverage.append({"component": k, "status": "unresolved version or unsupported ecosystem"})
        else:
            unique.setdefault((p["ecosystem"], p["name"], p["version"]), []).append(k)
    items = list(unique.items())
    for (_, _, _), keys in items[QUERY_BUDGET:]:
        coverage.extend({"component": k, "status": "query budget exceeded"} for k in keys)
    answers: dict[tuple, tuple[list[dict], str]] = {}
    todo = []
    for (e, n, v), keys in items[:QUERY_BUDGET]:                      # SQLite is touched only here, in the calling thread
        cached = memory.cache_get(f"osv:{e}:{n}:{v}", 86400) if memory else None
        if cached is not None:
            answers[(e, n, v)] = (cached, "cached")
        elif offline:
            answers[(e, n, v)] = ([], "unavailable (offline; no fresh cache)")
        else:
            todo.append((e, n, v))
    with ThreadPoolExecutor(max_workers=8) as pool:                   # only the network fetch runs in workers
        jobs = {pool.submit(osv_fetch, e, n, v, request): (e, n, v) for (e, n, v) in todo}
        for fut in as_completed(jobs):
            ident = jobs[fut]
            try:
                advisories = fut.result()
                if memory:
                    memory.cache_put(f"osv:{ident[0]}:{ident[1]}:{ident[2]}", advisories)
                answers[ident] = (advisories, "live")
            except Exception as exc:  # noqa: BLE001 - a failed lookup is a coverage gap, never "clean"
                answers[ident] = ([], f"failed: {str(exc)[:160]}")
    for (eco, name, ver), keys in items[:QUERY_BUDGET]:
        advisories, status = answers[(eco, name, ver)]
        for k in keys:
            coverage.append({"component": k, "status": status})
            meta = head["packages"][k]
            for v in advisories:
                if v.get("withdrawn"):
                    continue
                ids = [v["id"], *v.get("aliases", [])]
                rated = str(v.get("database_specific", {}).get("severity", "")).upper() in GHSA_SEV
                sev = GHSA_SEV.get(str(v.get("database_specific", {}).get("severity", "")).upper(), 0.0)
                primary = next((a for a in ids if a.startswith("CVE-")), v["id"])
                fixed = _fixed(v, name)
                f = finding("known_vulnerability", f"{name} {ver}: {primary} {v.get('summary', '')}".strip(), component=k, detector="osv-api",
                            severity=sev, location={"file": (meta.get("lockfiles") or [""])[0]},
                            change="introduced since baseline" if (base and k not in base_pk) else ("present in baseline" if base else ""),
                            verified_evidence=[f"OSV API ({status}) {v['id']} matches {name}@{ver}", f"fixed in: {', '.join(fixed) or 'no fixed version published'}"],
                            extra={"id": primary, "advisory_ids": [v["id"]], "aliases": sorted(set(ids)), "fixed_versions": fixed, "scope": meta.get("scope", "unknown"),
                                   "severity_unknown": not rated},
                            recommendation=f"Upgrade {name} to {fixed[0]} or later" if fixed else "No fix published: consider replacing or mitigating")
                f["dependency_paths"] = paths_to(k, head["graph"], head["roots"])
                findings.append(f)
    return findings, coverage


# ---------------------------------------------------------------------------------------------
# One entry point for both pipelines: OSV-Scanner on lockfiles, the exact-version API for everything else, and an honest
# coverage record so "0 findings" can never be read as "no vulnerabilities" when part of the tree was not checked.
# ---------------------------------------------------------------------------------------------
LOCKFILES = {"package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml", "uv.lock", "poetry.lock", "Pipfile.lock",
             "pubspec.lock", "go.sum", "gradle.lockfile", "packages.lock.json"}


def scan_all(head_dir: Path, head: dict, base: dict | None, memory, offline: bool = False, request=_osv_request) -> tuple[list[dict], dict]:
    pk = head["packages"]
    findings, meta, why = [], {"rc": -1}, ""
    if not offline:
        findings, meta = scan(head_dir, head, base)
    status: dict[str, str] = {}
    if offline or meta.get("rc") not in (0, 1):
        why = "offline mode" if offline else f"OSV-Scanner did not run ({(meta.get('stderr_tail') or 'exit ' + str(meta.get('rc'))).strip()[-120:]}); used the OSV API"
        findings, api_keys = [], set(pk)
    else:
        api_keys = {k for k, p in pk.items() if p.get("exact_pin")}                # manifest pins: the scanner has no lockfile for them
        for k, p in pk.items():
            src = Path((p.get("lockfiles") or [""])[0]).name
            if k not in api_keys:
                status[k] = "checked" if src in LOCKFILES or src.endswith("requirements.txt") else "not checked: no lockfile for this ecosystem"
    if api_keys:
        api_fs, cov = scan_api({**head, "packages": {k: pk[k] for k in api_keys}}, base, memory, offline, request)
        findings += api_fs
        status.update({c["component"]: "checked" if c["status"] in ("live", "cached") else f"not checked: {c['status']}" for c in cov})
    status.update({u["component"]: u["reason"] for u in head.get("unchecked", [])})
    failed = [r for r in head.get("resolution", []) if r.get("status") == "failed"]
    reasons = [f"lockfile resolution failed for {r['manifest']} ({r['reason']})" for r in failed]
    counts: dict[str, int] = {}
    for v in status.values():
        if v != "checked":
            counts[v] = counts.get(v, 0) + 1
    reasons += [f"{n} component(s) {v}" for v, n in sorted(counts.items(), key=lambda x: -x[1])]
    checked = sum(1 for v in status.values() if v == "checked")
    return findings, {"total": len(status), "checked": checked, "percent": round(100 * checked / len(status)) if status else 100,
                      "complete": not reasons, "reason": "; ".join(([why] if why and reasons else []) + reasons), "note": why,
                      "not_checked": [{"component": k, "reason": v} for k, v in status.items() if v != "checked"]}
