﻿"""Publisher: after a named person approves, push a guardian/* branch to GitHub and open a pull request.

The only place in the harness that talks to a remote. It is OFF unless GUARDIAN_ALLOW_PUSH=1. Rules checked in code before anything leaves this computer:
  - a named approver and a written reason are required
  - only branches named guardian/... are pushed; the repository's default branch is never pushed to; there is no force push
  - the token travels in one command's header: never in .git/config, a URL, the decision log or an error message
  - a pull request is opened, never merged; a patch that was not runtime-validated is opened as a DRAFT
  - the approval and the result are written to the append-only decision log
Setup: GUARDIAN_ALLOW_PUSH=1 and GUARDIAN_GITHUB_TOKEN (fine-grained, Contents and Pull requests write, ONE repository).
To push somewhere other than the sandbox's `origin` (for example your fork of a public project) set GUARDIAN_PUSH_REMOTE=https://github.com/you/repo.
"""
from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path

from ..tools import git
from ..tools import run as run_tool

BRANCH_RX = re.compile(r"^guardian/[A-Za-z0-9._-]{1,100}$")
GITHUB_RX = re.compile(r"^(?:https://github\.com/|git@github\.com:)([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?/?$")
MAX_FILES = 25
OK_VERDICTS = ("verified", "verified-with-gaps")


class PublishError(RuntimeError):
    """A refusal or a failure, in words a person can act on."""


def enabled(env=None) -> bool:
    return (env if env is not None else os.environ).get("GUARDIAN_ALLOW_PUSH") == "1"


def token(env=None) -> str:
    e = env if env is not None else os.environ
    return e.get("GUARDIAN_GITHUB_TOKEN") or e.get("GITHUB_TOKEN") or ""


def parse_remote(url: str) -> tuple[str, str] | None:
    m = GITHUB_RX.match((url or "").strip())
    return (m.group(1), m.group(2)) if m else None


def github_api(method: str, url: str, tok: str, payload: dict | None = None) -> tuple[int, dict]:
    headers = {"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json", "User-Agent": "SupplyChainGuardian/1", "X-GitHub-Api-Version": "2022-11-28"}
    data = None
    if payload is not None:
        data, headers["Content-Type"] = json.dumps(payload).encode(), "application/json"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, data=data, method=method, headers=headers), timeout=30) as r:
            return r.status, json.loads(r.read(2 * 1024 * 1024) or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read(65536) or b"{}")
        except ValueError:
            return e.code, {}


def _scrub(text: str, tok: str) -> str:
    for s in filter(None, (tok, base64.b64encode(f"x-access-token:{tok}".encode()).decode() if tok else "")):
        text = text.replace(s, "***")
    return text


def publish(sandbox: Path, branch: str, title: str, body: str, actor: str, reason: str, *, base_sha: str = "", draft: bool = True, mem=None,
            run_id: str = "-", project: str = "", env=None, http=github_api, runner=run_tool) -> dict:
    """Push `branch` from the sandbox and open a pull request. Returns {ok, repo, branch, base, pull_request, number, draft, files}. Raises PublishError."""
    env = env if env is not None else os.environ
    tok = token(env)
    sandbox = Path(sandbox)

    def log(decision: str, why: str, inputs: dict | None = None) -> None:
        if mem:
            mem.decide(run_id, project, f"human:{actor}" if decision.startswith("approved") else "publisher", decision, why[:400], inputs, rule="human-gate-7")

    def refuse(msg: str) -> None:
        log(f"publish refused for {branch}", msg)
        raise PublishError(msg)

    if not (actor or "").strip() or not (reason or "").strip():
        raise PublishError("A named approver and a written reason are required before anything is pushed")
    if not enabled(env):
        raise PublishError("Pushing is switched off. Set GUARDIAN_ALLOW_PUSH=1 (and GUARDIAN_GITHUB_TOKEN) to let the Guardian push approved branches. Nothing was pushed.")
    if not tok:
        raise PublishError("No GitHub token: set GUARDIAN_GITHUB_TOKEN (fine-grained, Contents and Pull requests write on one repository)")
    if not BRANCH_RX.match(branch or ""):
        refuse(f"Only guardian/... branches are pushed, not '{branch}'")
    if not sandbox.is_dir():
        refuse("The sandbox folder with the fix is gone: run the fix again")
    cur = runner("git", [*git.SAFE, "-C", str(sandbox), "rev-parse", "--abbrev-ref", "HEAD"])
    if not cur.ok or cur.stdout.strip() != branch:
        refuse(f"The sandbox is not on branch {branch}")
    remote = (env.get("GUARDIAN_PUSH_REMOTE") or "").strip()
    if not remote:
        r = runner("git", [*git.SAFE, "-C", str(sandbox), "remote", "get-url", "origin"])
        remote = r.stdout.strip() if r.ok else ""
    where = parse_remote(remote)
    if not where:
        refuse("The target is not a github.com repository (without credentials in the URL). Set GUARDIAN_PUSH_REMOTE=https://github.com/OWNER/REPO")
    owner, repo = where
    files = [p for _, p in git.changed_files(sandbox, base_sha, "HEAD")] if base_sha else []
    if base_sha and not files:
        refuse("The branch has no change compared with the commit it was made from")
    if len(files) > MAX_FILES:
        refuse(f"The branch changes {len(files)} files (limit {MAX_FILES}): a person should look at it first")
    st, info = http("GET", f"https://api.github.com/repos/{owner}/{repo}", tok)
    if st != 200:
        refuse(f"GitHub says {st} for {owner}/{repo}: the repository does not exist or the token cannot see it")
    if not (info.get("permissions") or {}).get("push"):
        refuse(f"The token cannot push to {owner}/{repo}. For a project you do not own, fork it and set GUARDIAN_PUSH_REMOTE to your fork")
    default = info.get("default_branch") or "main"
    if branch == default:
        refuse("Refusing to push the default branch")
    log(f"approved pushing {branch} to {owner}/{repo} and opening a pull request", reason, {"files": files, "draft": draft})
    header = "Authorization: Basic " + base64.b64encode(f"x-access-token:{tok}".encode()).decode()
    pushed = runner("git", [*git.SAFE, "-c", f"http.extraheader={header}", "-C", str(sandbox), "push", "--no-verify",
                            f"https://github.com/{owner}/{repo}.git", f"refs/heads/{branch}:refs/heads/{branch}"], timeout=300)
    if not pushed.ok:
        msg = _scrub(pushed.stderr[-300:], tok) or "git push failed"
        log(f"push of {branch} failed", msg)
        raise PublishError(f"git push failed: {msg}")
    st, pr = http("POST", f"https://api.github.com/repos/{owner}/{repo}/pulls", tok,
                  {"title": title[:200], "head": branch, "base": default, "body": body[:60000], "draft": draft, "maintainer_can_modify": True})
    if st == 422:                                                     # a pull request for this branch is already open
        _, found = http("GET", f"https://api.github.com/repos/{owner}/{repo}/pulls?head={owner}:{branch}&state=open", tok)
        pr = (found[0] if isinstance(found, list) and found else {}) or {}
    elif st != 201:
        msg = _scrub(str(pr.get("message", ""))[:200], tok)
        log(f"pull request for {branch} failed", f"GitHub {st}: {msg}")
        raise PublishError(f"The branch was pushed, but GitHub refused the pull request ({st}): {msg}")
    url, num = pr.get("html_url") or f"https://github.com/{owner}/{repo}/tree/{branch}", pr.get("number")
    log(f"pushed {branch} to {owner}/{repo}; pull request {'#' + str(num) if num else 'opened'} ({'draft' if draft else 'ready'}), never merged by the Guardian", url, {"url": url})
    return {"ok": True, "repo": f"{owner}/{repo}", "branch": branch, "base": default, "pull_request": url, "number": num, "draft": draft, "files": files}


def workflow_body(rec: dict, approver: str, reason: str, patch: str = "") -> str:
    """Pull request text for a patch drafted by the no-fix agent workflow. Says plainly what it is and is not."""
    steps = {s["agent"]: s for s in rec.get("steps", [])}
    inv, strat = (steps.get("Investigator") or {}).get("output", {}), steps.get("Strategist") or {}
    pk = rec.get("package", {})
    hits = [f"- `{h['file']}:{h['line']}`  `{h['text'][:100]}`" for h in inv.get("feature_hits", [])[:10]]
    L = [f"## Isolate the vulnerable feature of {pk.get('name')} {pk.get('version')} (no published fix)", "",
         f"**Advisory:** {(inv.get('advisory') or {}).get('id', '')} {(inv.get('advisory') or {}).get('summary', '')}", "",
         f"**Strategy chosen:** {rec.get('strategy', '')}" + (" (AI inference, not evidence)" if strat.get("ai") else " (fixed rule)"),
         f"**Why:** {((strat.get('output') or {}).get('reason') or '')}", "", "**Where the vulnerable feature is used (found by search, with file and line):**", *(hits or ["- none listed"]), "",
         "**What this is NOT:**",
         "- A mitigation, not a resolution: the package is still on the advisory list.",
         "- Statically verified only (the edited lines no longer use the feature, no other file changed). It was NOT built or tested: run your tests before merging.", "",
         f"**Approved by:** {approver}: {reason}", "", "Opened as a draft. The Guardian never merges.", ""]
    if patch.strip():
        L += ["<details><summary>patch</summary>", "", "```diff", patch[:20000], "```", "</details>", ""]
    return "\n".join(L)
