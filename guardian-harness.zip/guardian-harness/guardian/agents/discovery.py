"""Discovery agent (Day 1 steps 1-2): what is in the application.

Builds one snapshot of a checkout:
  sbom          CycloneDX from Syft
  packages      every locked package: ecosystem, name, version, scope (runtime/dev), origin URL, integrity hash,
                install-script flag, which lockfile it came from
  graph         dependency edges, so every package has a path back to the app
  workflows     every `uses:` in GitHub workflows, pinned or not
  images        every Dockerfile FROM, with tag and digest
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import tomllib
from collections import deque
from pathlib import Path
from urllib.parse import urlparse

from ..tools import run, scanners

SKIP_DIRS = {"node_modules", ".git", "dist", "build", "vendor", ".venv", "venv", "env", "site-packages", "__pycache__"}


def _walk(root: Path, names: set[str] | None = None, suffixes: tuple = ()):
    for p in root.rglob("*"):
        if any(part in SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        if p.is_file() and ((names and p.name in names) or (suffixes and p.name.endswith(suffixes))):
            yield p


def pkey(eco: str, name: str, version: str) -> str:
    return f"{eco}:{name}@{version}"


# ---------------- npm ----------------
def _v1_as_packages(data: dict, manifest: Path) -> dict:
    """npm lockfileVersion 1 (nested `dependencies` tree: version, resolved, integrity, requires, dev) in the v2/v3 `packages` shape,
    so one resolver handles both. v1 has no root entry: the root's direct dependencies come from the package.json beside the lockfile."""
    pk: dict = {}
    try:
        root = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        root = {}
    pk[""] = {k: root.get(k, {}) for k in ("dependencies", "devDependencies", "optionalDependencies")}

    def walk(deps: dict, prefix: str):
        for name, d in (deps or {}).items():
            path = f"{prefix}node_modules/{name}"
            pk[path] = {"version": d.get("version", ""), "resolved": d.get("resolved", ""), "integrity": d.get("integrity", ""),
                        "dev": bool(d.get("dev")), "optional": bool(d.get("optional")), "dependencies": d.get("requires") or {}}
            if str(d.get("version", "")).startswith(("file:", "git", "github:")):
                pk[path]["version"] = d.get("version", "")
            walk(d.get("dependencies"), path + "/")
    walk(data.get("dependencies"), "")
    return pk


def _npm_lock(lock: Path, root: Path, packages: dict, graph: dict, roots: dict):
    data = json.loads(lock.read_text(encoding="utf-8"))
    rel = str(lock.relative_to(root)).replace("\\", "/")
    pk = data.get("packages")
    if not pk and data.get("dependencies"):
        pk = _v1_as_packages(data, lock.parent / "package.json")
    if not pk:
        if (lock.parent / "package.json").exists():
            raise ValueError("lockfile lists no packages")
        return
    path_to_key = {}
    for p, meta in pk.items():
        if not p:
            continue
        name = meta.get("name") or p.split("node_modules/")[-1]
        ver = meta.get("version", "")
        if not ver or meta.get("link"):
            continue
        k = pkey("npm", name, ver)
        path_to_key[p] = k
        entry = packages.setdefault(k, {"ecosystem": "npm", "name": name, "version": ver, "lockfiles": [],
                                        "scope": "dev" if meta.get("dev") else "runtime",
                                        "origin": meta.get("resolved", ""), "integrity": meta.get("integrity", ""),
                                        "install_script": bool(meta.get("hasInstallScript")),
                                        "license": meta.get("license", "")})
        if rel not in entry["lockfiles"]:
            entry["lockfiles"].append(rel)
        if not meta.get("dev"):
            entry["scope"] = "runtime"

    def resolve(from_path: str, dep: str) -> str | None:
        base = from_path
        while True:
            cand = f"{base}/node_modules/{dep}" if base else f"node_modules/{dep}"
            if cand in path_to_key:
                return path_to_key[cand]
            if not base:
                return None
            idx = base.rfind("/node_modules/")
            base = base[:idx] if idx >= 0 else ""

    app = f"app:{rel}"
    root_meta = pk.get("", {})
    direct = {**root_meta.get("dependencies", {}), **root_meta.get("devDependencies", {}),
              **root_meta.get("optionalDependencies", {})}
    roots[app] = []
    for d in direct:
        k = resolve("", d)
        if k:
            roots[app].append(k)
            graph.setdefault(app, set()).add(k)
    for p, meta in pk.items():
        if p not in path_to_key:
            continue
        for d in {**meta.get("dependencies", {}), **meta.get("optionalDependencies", {})}:
            k = resolve(p, d)
            if k:
                graph.setdefault(path_to_key[p], set()).add(k)


# ---------------- Python ----------------
def _toml_lock(lock: Path, root: Path, packages: dict, graph: dict, roots: dict):
    data = tomllib.loads(lock.read_text(encoding="utf-8"))
    rel = str(lock.relative_to(root)).replace("\\", "/")
    by_name = {}
    for pkg in data.get("package", []):
        name, ver = pkg.get("name", ""), pkg.get("version", "")
        src = pkg.get("source", {}) or {}
        if src.get("editable") or src.get("virtual"):
            by_name[name.lower()] = f"app:{rel}"
            continue
        k = pkey("PyPI", name, ver)
        by_name[name.lower()] = k
        sd = pkg.get("sdist") or {}
        wh = (pkg.get("wheels") or [{}])[0]
        e = packages.setdefault(k, {"ecosystem": "PyPI", "name": name, "version": ver, "lockfiles": [],
                                    "scope": "dev" if pkg.get("category") == "dev" else "runtime",
                                    "origin": sd.get("url") or wh.get("url") or src.get("registry", ""),
                                    "integrity": sd.get("hash") or wh.get("hash", ""), "install_script": bool(sd) and not pkg.get("wheels"),
                                    "license": ""})
        if rel not in e["lockfiles"]:
            e["lockfiles"].append(rel)
    app = f"app:{rel}"
    roots.setdefault(app, [])
    for pkg in data.get("package", []):
        src = by_name.get(pkg.get("name", "").lower())
        deps = pkg.get("dependencies", [])
        names = [d.get("name", "") for d in deps] if isinstance(deps, list) else list(deps.keys())
        for n in names:
            tgt = by_name.get(n.lower())
            if src and tgt and src != tgt:
                graph.setdefault(src, set()).add(tgt)
                if src == app:
                    roots[app].append(tgt)
    if not roots[app]:  # poetry: direct deps come from pyproject
        pyp = lock.parent / "pyproject.toml"
        if pyp.exists():
            pd = tomllib.loads(pyp.read_text(encoding="utf-8"))
            names = list(pd.get("tool", {}).get("poetry", {}).get("dependencies", {}).keys())
            names += [re.split(r"[ <>=!~\[;]", d)[0] for d in pd.get("project", {}).get("dependencies", [])]
            for n in names:
                tgt = by_name.get(n.lower())
                if tgt:
                    roots[app].append(tgt)
                    graph.setdefault(app, set()).add(tgt)


def _requirements(req: Path, root: Path, packages: dict, graph: dict, roots: dict):
    rel = str(req.relative_to(root)).replace("\\", "/")
    app = f"app:{rel}"
    roots.setdefault(app, [])
    for line in req.read_text(encoding="utf-8", errors="replace").splitlines():
        m = re.match(r"^\s*([A-Za-z0-9_.\-]+)\s*==\s*([^\s;#\\]+)", line)
        if not m:
            continue
        name, ver = m.groups()
        k = pkey("PyPI", name, ver)
        h = re.search(r"--hash=(\S+)", line)
        e = packages.setdefault(k, {"ecosystem": "PyPI", "name": name, "version": ver, "lockfiles": [], "scope": "runtime",
                                    "origin": "", "integrity": h.group(1) if h else "", "install_script": False, "license": ""})
        e["lockfiles"].append(rel)
        roots[app].append(k)
        graph.setdefault(app, set()).add(k)


# ---------------- CI and containers ----------------
USES = re.compile(r"^\s*-?\s*uses:\s*['\"]?([^'\"\s#]+)")


def _workflows(root: Path) -> list[dict]:
    out = []
    wf_dir = root / ".github" / "workflows"
    files = list(wf_dir.glob("*.y*ml")) if wf_dir.exists() else []
    files += list(_walk(root, names={"action.yml", "action.yaml"}))
    for f in files:
        for i, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            m = USES.match(line)
            if not m:
                continue
            uses = m.group(1)
            local = uses.startswith("./") or uses.startswith("docker://")
            ref = uses.split("@", 1)[1] if "@" in uses else ""
            out.append({"file": str(f.relative_to(root)).replace("\\", "/"), "line": i, "uses": uses,
                        "local": local, "ref": ref, "pinned": bool(re.fullmatch(r"[0-9a-f]{40}", ref)) or local,
                        "first_party": uses.startswith(("actions/", "github/"))})
    return out


FROM = re.compile(r"^\s*FROM\s+(?:--platform=\S+\s+)?(\S+)(?:\s+AS\s+(\S+))?", re.I)


def _images(root: Path) -> list[dict]:
    out = []
    for f in _walk(root, suffixes=("Dockerfile", ".dockerfile", ".Dockerfile")):
        stages = set()
        for i, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            m = FROM.match(line)
            if not m:
                continue
            ref, alias = m.group(1), m.group(2)
            if alias:
                stages.add(alias.lower())
            if ref.lower() in stages or ref.lower() == "scratch" or "$" in ref:
                continue
            digest = ref.split("@", 1)[1] if "@" in ref else ""
            base = ref.split("@", 1)[0]
            name, _, tag = base.rpartition(":") if ":" in base.split("/")[-1] else (base, "", "")
            out.append({"file": str(f.relative_to(root)).replace("\\", "/"), "line": i, "image": name or base,
                        "tag": tag or "latest", "digest": digest, "ref": ref})
    return out


def paths_to(target: str, graph: dict, roots: dict, limit: int = 3) -> list[list[str]]:
    """Shortest dependency paths from an app root to target (BFS)."""
    out = []
    for app in roots:
        prev = {app: None}
        q = deque([app])
        while q:
            n = q.popleft()
            if n == target:
                path = []
                while n:
                    path.append(n)
                    n = prev[n]
                out.append(list(reversed(path)))
                break
            for c in graph.get(n, ()):
                if c not in prev:
                    prev[c] = n
                    q.append(c)
        if len(out) >= limit:
            break
    return out


GEN_MARK = ".guardian-generated-lock"


def sanitized_manifest(data: dict) -> tuple[dict, list[str]]:
    """Ported from GuardianAI day1 (team): resolver.sanitized_manifest. Only registry names and versions, ranges, dist-tags and npm
    aliases survive; scripts, overrides, workspaces and any URL, git or path dependency are dropped. Returns the clean manifest and
    a note for every dependency that was left out (Day 1 refused the whole manifest; we resolve the rest and say what was skipped)."""
    result = {"name": "guardian-analysis", "version": "0.0.0", "private": True}
    skipped: list[str] = []
    for section in ("dependencies", "devDependencies", "optionalDependencies"):
        result[section] = {}
        for name, spec in (data.get(section) or {}).items():
            if not re.fullmatch(r"(?:@[a-zA-Z0-9_.-]+/)?[a-zA-Z0-9_.-]+", name):
                skipped.append(f"{name} (invalid package name)")
                continue
            ok = isinstance(spec, str) and bool(re.fullmatch(r"[a-zA-Z0-9@/^~*<>=| ._+!-]+", spec)) and ":" not in spec and "/" not in spec
            alias = isinstance(spec, str) and bool(re.fullmatch(r"npm:(?:@[\w.-]+/)?[\w.-]+@[\w.*~^<>=| +!-]+", spec))
            if not (ok or alias):
                skipped.append(f"{name}: {spec} (non-registry dependency)")
                continue
            result[section][name] = spec
    return result, skipped


RESOLVE_TIMEOUT = 180
REGISTRY = "https://registry.npmjs.org/"
EXACT_PIN = re.compile(r"=?v?(\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)")


def npm_command() -> list[str]:
    """argv prefix that runs npm with shell=False. On Windows npm is a .cmd shim, so run node on npm-cli.js directly
    (fallback: cmd /c npm.cmd). GUARDIAN_NODE / GUARDIAN_NPM override discovery."""
    node = os.environ.get("GUARDIAN_NODE") or shutil.which("node")
    if not node:
        raise ValueError("Node.js was not found on PATH (set GUARDIAN_NODE)")
    if os.name != "nt":
        npm = os.environ.get("GUARDIAN_NPM") or shutil.which("npm")
        if not npm:
            raise ValueError("npm was not found on PATH (set GUARDIAN_NPM)")
        return [str(Path(node).resolve()), str(Path(npm).resolve())]
    cli = os.environ.get("GUARDIAN_NPM") or str(Path(node).resolve().parent / "node_modules" / "npm" / "bin" / "npm-cli.js")
    if Path(cli).exists():
        return [str(Path(node).resolve()), cli]
    cmd = shutil.which("npm.cmd")
    if not cmd:
        raise ValueError("npm-cli.js and npm.cmd were not found next to node")
    return [os.environ.get("ComSpec", "cmd.exe"), "/c", cmd]


def resolver_env(tmp: Path, node_dir: str) -> dict:
    """Allowlisted environment for the resolver: nothing from the parent except what Windows/node need to start. Home, temp and
    npm cache all point into the disposable folder; no credentials, no proxy or registry tokens."""
    t = str(tmp)
    env = {"CI": "true", "GIT_TERMINAL_PROMPT": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull,
           "npm_config_cache": str(tmp / "cache"), "npm_config_ignore_scripts": "true", "npm_config_registry": REGISTRY}
    if os.name == "nt":
        root = os.environ.get("SystemRoot") or os.environ.get("SYSTEMROOT") or r"C:\Windows"
        env.update(SystemRoot=root, windir=root, APPDATA=t, LOCALAPPDATA=t, USERPROFILE=t, HOME=t, TEMP=t, TMP=t,
                   PATH=os.pathsep.join([node_dir, rf"{root}\System32", root]))
        if "ComSpec" in os.environ:
            env["ComSpec"] = os.environ["ComSpec"]
    else:
        env.update(HOME=t, TMPDIR=t, PATH=os.pathsep.join([node_dir, "/usr/bin", "/bin", "/usr/local/bin"]))
    return env


def _resolve_lock(clean: dict) -> str:
    """npm install --package-lock-only in a disposable folder; returns the lockfile text or raises ValueError (short reason)."""
    command = npm_command()
    with tempfile.TemporaryDirectory(prefix="guardian-resolve-") as tmp:
        work = Path(tmp)
        (work / "package.json").write_text(json.dumps(clean), encoding="utf-8")
        for rc in ("user.npmrc", "global.npmrc"):          # two different files: npm refuses one file as both user and global config
            (work / rc).write_text("", encoding="utf-8")
        args = command + ["install", "--package-lock-only", "--ignore-scripts", "--no-audit", "--no-fund", "--legacy-peer-deps",
                          f"--registry={REGISTRY}", f"--userconfig={work / 'user.npmrc'}", f"--globalconfig={work / 'global.npmrc'}"]
        try:
            r = subprocess.run(args, cwd=work, env=resolver_env(work, str(Path(command[0]).parent)), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=RESOLVE_TIMEOUT, shell=False)
        except subprocess.TimeoutExpired:
            raise ValueError(f"npm timed out after {RESOLVE_TIMEOUT}s") from None
        except OSError as e:
            raise ValueError(f"npm could not start: {e}") from None
        lock = work / "package-lock.json"
        if r.returncode or not lock.exists():
            raise ValueError("npm failed: " + " ".join((r.stderr or r.stdout or "no output").split())[-200:])
        if lock.stat().st_size > 16 * 1024 * 1024 or (work / "node_modules").exists():
            raise ValueError("generated lockfile too large or node_modules created")
        return lock.read_text(encoding="utf-8")


def ensure_npm_locks(root: Path, notes: list, max_projects: int = 3, resolution: list | None = None) -> list[str]:
    """If a package.json has dependencies but no lockfile, resolve one WITHOUT running any package code, in a DISPOSABLE copy:
    a sanitized manifest alone in a temp directory, empty npmrc files, an allowlisted environment, no scripts
    (npm install --package-lock-only --ignore-scripts, 180 s). The lockfile is copied back and marked as generated.
    `resolution` receives one {manifest, status, reason} row per manifest so a failure is never silent."""
    made = []
    resolution = resolution if resolution is not None else []
    for pj in sorted(_walk(root, names={"package.json"}), key=lambda p: len(p.parts)):
        d = pj.parent
        if len(made) >= max_projects or len(d.relative_to(root).parts) > 2:
            continue
        if (d / "package-lock.json").exists() or (d / "yarn.lock").exists() or (d / "pnpm-lock.yaml").exists():
            continue
        try:
            meta = json.loads(pj.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        rel = str(d.relative_to(root)).replace("\\", "/") or "."
        clean, skipped = sanitized_manifest(meta)
        if skipped:
            notes.append(f"{rel}: {len(skipped)} non-registry or invalid dependencies were left out of lockfile resolution: {'; '.join(skipped[:4])}")
        if not any(clean[sec] for sec in ("dependencies", "devDependencies", "optionalDependencies")):
            continue
        try:
            text = _resolve_lock(clean)
        except ValueError as e:
            resolution.append({"manifest": rel, "status": "failed", "reason": str(e)})
            notes.append(f"could not resolve a lockfile for {rel}: {e}")
            continue
        (d / "package-lock.json").write_text(text, encoding="utf-8")
        (d / GEN_MARK).write_text("generated by guardian at scan time", encoding="utf-8")
        resolution.append({"manifest": rel, "status": "resolved", "reason": ""})
        made.append(rel)
    return made


def manifest_pins(root: Path, packages: dict, unchecked: list) -> None:
    """For a package.json that still has no lockfile: dependencies pinned exactly (3.10.1) become components OSV can be asked about
    by exact version; ranged ones (^1.0.0) have no known version and are listed as not checked."""
    for pj in _walk(root, names={"package.json"}):
        d = pj.parent
        if any((d / n).exists() for n in ("package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml")):
            continue
        try:
            meta = json.loads(pj.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        rel = str(pj.relative_to(root)).replace("\\", "/")
        for sec, scope in (("dependencies", "runtime"), ("optionalDependencies", "runtime"), ("devDependencies", "dev")):
            for name, spec in (meta.get(sec) or {}).items():
                m = EXACT_PIN.fullmatch(spec.strip()) if isinstance(spec, str) else None
                if m:
                    k = pkey("npm", name, m.group(1))
                    e = packages.setdefault(k, {"ecosystem": "npm", "name": name, "version": m.group(1), "lockfiles": [rel], "scope": scope,
                                                "origin": "", "integrity": "", "install_script": False, "license": "", "exact_pin": True})
                    if rel not in e["lockfiles"]:
                        e["lockfiles"].append(rel)
                else:
                    unchecked.append({"component": f"npm:{name}@{spec}", "reason": "not checked: range"})


EXTRA_NAMES = {"pubspec.lock", "pubspec.yaml", "Pipfile.lock", "pnpm-lock.yaml", "yarn.lock", "packages.lock.json", "gradle.lockfile",
               "build.gradle", "build.gradle.kts", "go.sum"}
EXTRA_SIBLINGS = {"package.json", "go.mod", "pyproject.toml"}


def extra_formats(root: Path, packages: dict, graph: dict, roots: dict, notes: list) -> None:
    """Lockfile formats beyond npm/uv/poetry/requirements (Pub, Pipfile, pnpm, Yarn, NuGet, Gradle, Go).
    Ported from GuardianAI day1 (team): the parsers are formats.parse_extra; this adapter maps them onto our snapshot structures."""
    from . import formats
    files = {}
    for p in _walk(root, names=EXTRA_NAMES | EXTRA_SIBLINGS, suffixes=formats.HANDLED_SUFFIX):
        text = formats.bounded_read(p)
        if text is not None:
            files[p.relative_to(root).as_posix()] = {"text": text}
    current = {"file": ""}

    def app_key() -> str:
        return f"app:{current['file']}"

    def add(name, version, eco, loc, **extra):
        k = pkey(eco, name, version)
        pk = packages.setdefault(k, {"ecosystem": eco, "name": name, "version": version, "lockfiles": [], "scope": "unknown", "origin": "",
                                     "integrity": "", "install_script": False, "license": "", "direct": False})
        if current["file"] not in pk["lockfiles"]:
            pk["lockfiles"].append(current["file"])
        if extra.get("integrity"):
            pk["integrity"] = str(extra["integrity"])
        return k

    def edge(a, b, relation=""):
        if a == "app":
            a = app_key()
            roots.setdefault(a, [])
            if b not in roots[a]:
                roots[a].append(b)
        graph.setdefault(a, set()).add(b)

    for rel in sorted(files):
        if Path(rel).name in EXTRA_SIBLINGS and Path(rel).name not in EXTRA_NAMES:
            continue
        current["file"] = rel
        try:
            formats.parse_extra(rel, files, add, edge, packages, notes)
        except Exception as e:  # noqa: BLE001 - a malformed lockfile is a visible note, never a crash
            notes.append(f"could not parse {rel}: {type(e).__name__}: {str(e)[:160]}")


def snapshot(root: Path, run_syft: bool = True, generate_locks: bool = True) -> dict:
    packages, graph, roots, notes = {}, {}, {}, []
    resolution: list[dict] = []
    lock_errors: list[str] = []                      # lockfiles that could not be read: this snapshot is not a full inventory
    generated = ensure_npm_locks(root, notes, resolution=resolution) if generate_locks else []
    generated += [str(p.parent.relative_to(root)).replace("\\", "/") or "." for p in _walk(root, names={GEN_MARK})
                  if (str(p.parent.relative_to(root)).replace("\\", "/") or ".") not in generated]
    if generated:
        notes.append(f"no lockfile committed in {generated}: versions were resolved at scan time with --ignore-scripts "
                     "(no package code was run), so they show what a fresh install would get today")
    for lock in _walk(root, names={"package-lock.json", "npm-shrinkwrap.json"}):
        try:
            _npm_lock(lock, root, packages, graph, roots)
        except Exception as e:  # noqa: BLE001
            notes.append(f"could not parse {lock.name}: {e}")
            lock_errors.append(f"{lock.relative_to(root)}: {e}".replace("\\", "/"))
    for lock in _walk(root, names={"uv.lock", "poetry.lock"}):
        try:
            _toml_lock(lock, root, packages, graph, roots)
        except Exception as e:  # noqa: BLE001
            notes.append(f"could not parse {lock.name}: {e}")
    for req in _walk(root, suffixes=("requirements.txt",)):
        _requirements(req, root, packages, graph, roots)
    extra_formats(root, packages, graph, roots, notes)
    unchecked: list[dict] = []
    manifest_pins(root, packages, unchecked)
    manifests_without_lock = [str(p.relative_to(root)) for p in _walk(root, names={"package.json"})
                              if not (p.parent / "package-lock.json").exists() and not (p.parent / "yarn.lock").exists()
                              and not (p.parent / "pnpm-lock.yaml").exists()]
    if manifests_without_lock:
        notes.append(f"package.json without a lockfile (transitive versions unknown): {manifests_without_lock[:5]}")

    sbom, sbom_meta = None, None
    if run_syft:
        r = scanners.syft_sbom(root)
        sbom_meta = r.meta()
        sbom = r.json() if r.ok else None
        if not r.ok:
            notes.append(f"syft failed: {r.stderr[-200:]}")
    # Packages Syft found that no lockfile parser covered (other ecosystems, binaries, OS packages)
    if sbom:
        for c in sbom.get("components", []):
            purl = c.get("purl", "")
            if not purl.startswith("pkg:"):
                continue
            eco = purl[4:].split("/")[0]
            eco = {"npm": "npm", "pypi": "PyPI", "maven": "Maven", "golang": "Go", "cargo": "crates.io",
                   "gem": "RubyGems", "nuget": "NuGet", "github": "GitHubActions"}.get(eco, eco)
            k = pkey(eco, c.get("name", ""), c.get("version", ""))
            if k not in packages and eco not in ("npm", "PyPI"):
                locs = [p["value"] for p in c.get("properties", []) if p.get("name", "").startswith("syft:location")]
                packages[k] = {"ecosystem": eco, "name": c.get("name", ""), "version": c.get("version", ""),
                               "lockfiles": locs[:1], "scope": "unknown", "origin": "", "integrity": "",
                               "install_script": False, "license": ""}
    for p in packages.values():
        p["origin_host"] = urlparse(p["origin"]).hostname or "" if p["origin"] else ""
    return {
        "packages": packages,
        "graph": {k: sorted(v) for k, v in graph.items()},
        "roots": roots,
        "workflows": _workflows(root),
        "images": _images(root),
        "sbom": sbom,
        "sbom_tool": sbom_meta,
        "notes": notes,
        "generated_locks": generated,
        "resolution": resolution,
        "lock_errors": lock_errors,
        "unchecked": unchecked,
    }
