# agents/

Everything in the Guardian that reasons, plans or talks to a model lives here. The deterministic detectors that the agents rely on sit
alongside them (they started life as "specialist agents"); the table says which is which.

## The AI-driven agents

| File | Role | What the AI may do | What it may never do |
| --- | --- | --- | --- |
| `llm.py` | Model router (OpenAI-compatible endpoints with failover, Anthropic), tool-calling loop | n/a | read keys into output; call a model with repo text that is not wrapped as `<DATA>` |
| `orchestrator.py` | Run coordinator for the legacy `scan`: plans the comparison, runs the canary, drives the lead agent, logs every decision | n/a (plans with fixed rules) | skip the canary or the audit log |
| `pipeline.py` | Lead agent: runs the specialist agents as tools, then verifies and scores | choose which specialists to run and which findings to investigate | change a score or a confidence; skip the verify-and-score gate |
| `investigator.py` | Reads real code with read-only tools to judge one finding | give a verdict and an explanation (stored as inference) | write, run code, leave the checkout |
| `lead.py` | Runs the investigator on the top findings; **M19 verifier**: an AI "false positive" claim needs a cited file and line that exist | investigate | close, lower or suppress a deterministic finding |
| `suggest.py` | Fix report: OSV and Trivy first, the model only explains a fix that exists, otherwise the no-fix plan | explain a sourced fix in structured form | invent a version, a CVE or a fix |
| `nofix.py` | **No-fix workflow**: investigator, alternatives scout, strategist, patch author, verifier, human gates | pick a strategy; draft edits at lines the investigator found | touch any other line, add a dependency, merge or push |
| `reputation.py` | Registry check before a typosquat candidate is reported as Critical | none (no AI) | guess when the registry cannot be reached: the finding becomes "needs validation" |

## Deterministic specialist agents (no AI)

`discovery.py` (inventory), `formats.py` (extra lockfile formats), `change.py` (what changed, lookalike names), `vuln.py` (OSV),
`ci_container.py` and `containers.py` (workflows, images), `backdoor.py` and `flow.py` (hidden-code and secret-to-network rules),
`verifier.py` (re-checks cited evidence), `evidence.py` (scores and lessons), `fixer.py` (the fixed fix recipes), `validator.py` (Docker validation).

## Rules every agent here follows

1. Detectors and scores are deterministic. A model explains or drafts; it never decides a score, a confidence or a verdict.
2. AI text is stored as inference (`is_evidence: false`) with the model name and a prompt hash.
3. Repository and scanner text is untrusted `<DATA>`; instructions inside it are ignored.
4. Agents change only a sandbox branch. A named person approves; nothing is merged, pushed or deployed.
5. A step that cannot run says so (`Not run`, `failed`, `needs validation`); it is never reported as clean.
6. Every agent step writes a line to the append-only audit log.
