import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from guardian.core import Finding, RegistryError, RunContext, SchemaError, order, run_all
from guardian.core.schema import json_schema
from guardian.memory import Memory


class Mod:
    def __init__(self, id, needs=(), provides=("findings",), fn=None):
        self.id, self.needs, self.provides, self.fn = id, list(needs), list(provides), fn

    def run(self, ctx):
        if self.fn:
            self.fn(ctx)


def ctx():
    return RunContext(repo_path=Path("."), out_dir=Path(tempfile.mkdtemp()))


class CoreTests(unittest.TestCase):
    def test_schema_rejects_bad_finding(self):
        with self.assertRaises(SchemaError):
            Finding(type="nonsense", title="x", detector="M0").validate()
        with self.assertRaises(SchemaError):
            Finding(type="known_vulnerability", title="x", detector="M4", severity="urgent").validate()
        with self.assertRaises(SchemaError):  # AI text can never be evidence
            Finding(type="known_vulnerability", title="x", detector="M4", ai_inference={"text": "t", "is_evidence": True}).validate()

    def test_unsuppressible_cannot_be_suppressible(self):
        self.assertFalse(Finding(type="typosquat", title="t", detector="M3").suppressible)
        with self.assertRaises(SchemaError):
            Finding(type="typosquat", title="t", detector="M3", suppressible=True).validate()

    def test_emit_validates_and_dedupes(self):
        c = ctx()
        f = lambda: Finding(type="typosquat", title="ngy-cookie", detector="M3", package={"ecosystem": "npm", "name": "ngy-cookie", "version": "0.1.2"})
        c.emit([f(), f()])
        self.assertEqual(len(c.findings), 1)
        with self.assertRaises(SchemaError):
            c.emit([Finding(type="bad", title="x", detector="M3")])

    def test_registry_orders_and_refuses_cycle(self):
        a = Mod("A", provides=["artifact:snapshot"])
        b = Mod("B", needs=["artifact:snapshot"])
        self.assertEqual([m.id for m in order([b, a])], ["A", "B"])
        x, y = Mod("X", needs=["artifact:y"], provides=["artifact:x"]), Mod("Y", needs=["artifact:x"], provides=["artifact:y"])
        with self.assertRaises(RegistryError):
            order([x, y])
        with self.assertRaises(RegistryError):
            order([Mod("Z", needs=["artifact:missing"])])

    def test_crashing_module_is_failed_not_clean(self):
        def boom(_):
            raise RuntimeError("x")
        st = run_all([Mod("A", fn=boom), Mod("B")], ctx())
        self.assertTrue(st["A"].startswith("failed")) and self.assertEqual(st["B"], "ok")

    def test_legacy_adapter_and_json_schema(self):
        legacy = {"type": "new_install_script", "title": "postinstall added", "component": "foo@1.0.0", "detector": "change-agent",
                  "verified_evidence": ["package.json:9"], "risk_level": "High", "score": 6.5}
        f = Finding.from_legacy(legacy).validate()
        self.assertEqual((f.type, f.package["name"], f.severity, f.verdict), ("install_script", "foo", "high", "confirmed"))
        json.dumps(json_schema())

    def test_sarif_contract(self):
        from guardian.modules.report import sarif
        f = Finding(type="typosquat", title="crossenv", detector="M3", severity="critical", score=9.9,
                    package={"ecosystem": "npm", "name": "crossenv", "version": "1.0.0"}, location={"file": "package-lock.json"}).validate()
        s = sarif([f.to_dict()])
        r = s["runs"][0]["results"][0]
        self.assertEqual((s["version"], r["ruleId"], r["level"]), ("2.1.0", "typosquat", "error"))
        self.assertEqual(r["locations"][0]["physicalLocation"]["artifactLocation"]["uri"], "package-lock.json")

    def test_all_enabled_modules_resolve(self):
        from guardian.modules import AVAILABLE
        from guardian.runner import DEFAULT_MODULES
        from guardian.core import enabled
        ids = [m.id for m in order(enabled(DEFAULT_MODULES.read_text(encoding="utf-8"), AVAILABLE))]
        self.assertLess(ids.index("M1.inventory"), ids.index("M7.scoring"))
        self.assertLess(ids.index("M7.scoring"), ids.index("M10.report"))

    def test_audit_log_is_append_only(self):
        m = Memory(Path(tempfile.mkdtemp()) / "g.db")
        m.decide("r1", "p", "actor", "d", "why")
        with self.assertRaises(sqlite3.DatabaseError):
            m.db.execute("UPDATE decisions SET actor='x'")
        with self.assertRaises(sqlite3.DatabaseError):
            m.db.execute("DELETE FROM decisions")


if __name__ == "__main__":
    unittest.main()
