import json
import tempfile
import unittest
from pathlib import Path

from guardian.agents import lead
from guardian.agents.change import lookalike
from guardian.core import Finding, RunContext
from guardian.memory import Memory
from guardian.modules import remediation, stretch, validation
from guardian.modules.history import SECRET_PATTERNS


class Lookalike(unittest.TestCase):
    def test_flags_lookalikes_not_real_names(self):
        self.assertEqual(lookalike("lodahs", "npm", {"lodash"}), "lodash")      # swapped letters, real one also in the tree
        self.assertEqual(lookalike("l0dash", "npm", set()), "lodash")           # homoglyph
        self.assertEqual(lookalike("crossenv", "npm", set()), "cross-env")      # punctuation only
        self.assertIsNone(lookalike("lodash", "npm", set()))
        self.assertIsNone(lookalike("express", "npm", set()))
        self.assertIsNone(lookalike("my-company-lib", "npm", set()))

    def test_scoped_packages_are_not_compared_by_their_bare_name(self):
        for legit in ("@simplewebauthn/server", "@ethersproject/hash", "@babel/parser", "@vitest/utils"):
            self.assertIsNone(lookalike(legit, "npm", set()), legit)      # found as false positives on Juice Shop
        for sibling in ("@types/jws", "@types/pug", "@peculiar/asn1-pkcs8"):
            self.assertIsNone(lookalike(sibling, "npm", set()), sibling)
        self.assertEqual(lookalike("@babe/parser", "npm", set()), "@babel/parser")   # a different scope imitating a real one is a squat   # a lookalike of a scoped name still is one


class ClaimCheck(unittest.TestCase):
    def test_false_positive_needs_a_real_citation(self):
        d = Path(tempfile.mkdtemp())
        (d / "a.js").write_text("one\ntwo\n", encoding="utf-8")
        bad = lead.verify_claim({"verdict": "likely_false_positive", "text": "harmless, see nothing.js:3"}, d)
        self.assertEqual((bad["final_verdict"], bad["is_evidence"]), ("unclear", False))
        good = lead.verify_claim({"verdict": "likely_false_positive", "text": "test code at a.js:2"}, d)
        self.assertEqual((good["final_verdict"], good["citation"]), ("likely_false_positive", "a.js:2"))

    def test_summary_numbers_come_from_data(self):
        legacy = [{"risk_level": "Critical", "score": 9.0, "title": "x", "id": "A"}, {"risk_level": "Low", "score": 1.0, "title": "y", "id": "B"}]
        s = lead.summary({"head_ref": "HEAD", "base_ref": "v1"}, legacy, [])
        self.assertIn("2 findings", s)
        self.assertIn("1 Critical", s)


class Policy(unittest.TestCase):
    def test_blocks_planted_attack_and_names_the_rule(self):
        fs = [{"type": "typosquat", "title": "t", "fingerprint": "f1", "severity": "critical", "fixed_versions": [], "advisory_ids": []},
              {"type": "known_vulnerability", "title": "v", "fingerprint": "f2", "severity": "critical", "fixed_versions": ["2"], "advisory_ids": ["GHSA-1"]}]
        self.assertEqual([v["rule"] for v in stretch.evaluate(fs, [{"advisory_ids": ["GHSA-1"]}])], ["deny_typosquat"])
        self.assertIn("deny_critical_with_fix_but_no_plan", [v["rule"] for v in stretch.evaluate(fs, [])])


class Gate(unittest.TestCase):
    RES = {"verdict": "verified", "verdict_reason": "ok", "before": {"count": 3}, "after": {"count": 1}, "introduced": []}

    def test_never_verified_without_container_or_with_failed_canary(self):
        self.assertEqual(validation.gate(dict(self.RES), False, True)[0], "verified")
        self.assertEqual(validation.gate(dict(self.RES), False, False)[0], "not-verified")
        self.assertEqual(validation.gate(dict(self.RES), True, True)[0], "not-verified")
        self.assertEqual(validation.gate(dict(self.RES, after={"count": 3}), False, True)[0], "not-verified")


class Approval(unittest.TestCase):
    def test_validate_refuses_without_named_human_approval(self):
        m = Memory(Path(tempfile.mkdtemp()) / "g.db")
        m.save_proposal({"id": "FIX-T", "project": "p", "run_id": "r", "finding_id": "f", "package": "x", "from": "1", "to": "2", "out_dir": "."})
        with self.assertRaises(PermissionError):
            validation.validate(m, "FIX-T")
        with self.assertRaises(ValueError):
            validation.approve(m, "FIX-T", "", "reason")          # no name
        with self.assertRaises(ValueError):
            validation.approve(m, "FIX-T", "Ada", "")             # no reason


class Plans(unittest.TestCase):
    def test_every_type_gets_a_plan_with_rollback(self):
        f = lambda t, **k: {"id": "X", "type": t, "risk_level": "Critical", "component": "npm:foo@1.0.0", "title": "t",
                            "verified_evidence": [], "location": {"file": "package-lock.json"}, **k}
        for t in ("typosquat", "integrity_change", "unpinned_action", "untrusted_image", "backdoor_signal", "weird"):
            p = remediation.recipe(f(t), {"base_ref": "v1", "findings": []}, {})
            self.assertTrue(p["rollback"] and p["action"] and p["needs_human"], t)
        self.assertEqual(remediation.recipe(f("known_vulnerability", fixed_versions=[]), {"findings": [f("known_vulnerability")], "run_id": "r", "project": "p"},
                                             {"packages": {}, "roots": {}, "graph": {}})["action"], "replace or isolate")


class Secrets(unittest.TestCase):
    def test_patterns_match(self):
        self.assertTrue(SECRET_PATTERNS["aws-access-key"].search("k = AKIAABCDEFGHIJKLMNOP"))
        self.assertFalse(SECRET_PATTERNS["aws-access-key"].search("AKIA short"))

    def test_emit_never_stores_the_value(self):
        c = RunContext(repo_path=Path("."), out_dir=Path(tempfile.mkdtemp()))
        c.emit([Finding(type="secret_exposed", title="possible aws-access-key (value masked)", detector="M18", location={"snippet": "<masked>"},
                        verdict="needs_validation", missing_fact="not verified")])
        self.assertNotIn("AKIA", json.dumps(c.findings[0].to_dict()))


class HtmlReport(unittest.TestCase):
    def test_repo_text_cannot_inject_markup(self):
        from guardian.modules.report import html_report
        evil = "<script>alert(1)</script>"
        f = Finding(type="typosquat", title=evil, detector="M3", severity="critical", score=9.0,
                    evidence=[{"kind": "tool_output", "ref": evil}], score_reasons=[evil]).to_dict()
        rep = {"base_ref": evil, "head_ref": "HEAD", "summary": {"packages": 1, "direct": 1, "workflow_steps": 0, "images": 0, "findings": 1, "by_severity": {}},
               "changes": {}, "findings": [f], "canary": [{"detector": evil, "caught": True, "detail": evil}], "incomplete": False,
               "coverage": {"gaps": [evil], "statement": evil}}
        out = html_report(rep)
        self.assertNotIn("<script>alert", out)
        self.assertIn("&lt;script&gt;", out)


if __name__ == "__main__":
    unittest.main()


class DockerRules(unittest.TestCase):
    def test_dockerfile_rules_hit_and_clean_file_passes(self):
        from guardian.modules.dockerchecks import check_dockerfile
        bad = "FROM node:latest\nENV API_KEY=abc123\nADD https://x.io/a.tgz /a\nRUN curl -s https://x.io/i.sh | sh\nRUN chmod -R 777 /app\nCOPY . .\nEXPOSE 9229\n"
        rules = {r for r, _ in check_dockerfile(bad, False)}
        self.assertEqual(rules, {"latest-tag", "secret-in-env", "add-url", "pipe-to-shell", "chmod-777", "copy-all-no-dockerignore", "debug-port", "no-user"})
        good = "FROM node:22-slim@sha256:abc\nARG VERSION=1\nCOPY . .\nUSER node\n"
        self.assertEqual(check_dockerfile(good, True), [])

    def test_compose_and_workflow_rules(self):
        from guardian.modules.dockerchecks import check_compose, check_workflow
        self.assertEqual({r for r, _ in check_compose("services:\n  a:\n    privileged: true\n    network_mode: host\n    volumes:\n      - /var/run/docker.sock:/var/run/docker.sock\n")},
                         {"privileged", "host-network", "docker-sock"})
        wf = "on: pull_request_target\npermissions: write-all\njobs:\n  b:\n    steps:\n      - uses: actions/checkout@v4\n        with:\n          ref: ${{ github.event.pull_request.head.sha }}\n      - run: echo ${{ github.event.pull_request.title }}\n"
        self.assertEqual({r for r, _ in check_workflow(wf)}, {"write-all", "prt-checkout", "expression-injection"})
        self.assertEqual(check_workflow("on: push\njobs:\n  b:\n    steps:\n      - run: echo hi\n"), [])


class FixerOverride(unittest.TestCase):
    def test_override_of_a_direct_dependency_bumps_it_and_points_the_override_at_it(self):
        from guardian.agents import fixer
        d = Path(tempfile.mkdtemp())
        (d / "package.json").write_text(json.dumps({"dependencies": {"jsonwebtoken": "0.4.0", "express": "^4"}}), encoding="utf-8")
        fixer.apply_edit({"kind": "override", "package": "jsonwebtoken", "from": "0.4.0", "to": "9.0.0", "file": "package.json"}, d)
        data = json.loads((d / "package.json").read_text(encoding="utf-8"))
        self.assertEqual((data["dependencies"]["jsonwebtoken"], data["overrides"]["jsonwebtoken"]), ("9.0.0", "$jsonwebtoken"))   # npm accepts this; a plain override gives EOVERRIDE
        (d / "package.json").write_text(json.dumps({"dependencies": {"express": "^4"}}), encoding="utf-8")
        fixer.apply_edit({"kind": "override", "package": "qs", "from": "1.0.0", "to": "6.0.0", "file": "package.json"}, d)
        self.assertEqual(json.loads((d / "package.json").read_text(encoding="utf-8"))["overrides"]["qs"], "6.0.0")           # purely transitive: plain override


def mem() -> Memory:
    return Memory(Path(tempfile.mkdtemp()) / "g.db")


class FixReport(unittest.TestCase):
    """OSV and Trivy first; the LLM only when a fix exists; an agentic workflow when none does."""

    def finding(self, name="foo", ver="1.0.0", typ="known_vulnerability"):
        return {"fingerprint": "f" * 64, "legacy_id": "X1", "title": f"{name} {ver}: CVE-1", "type": typ, "package": {"ecosystem": "npm", "name": name, "version": ver},
                "component_key": f"npm:{name}@{ver}", "location": {}, "evidence": []}

    def osv(self, vulns):
        return lambda payload: {"vulns": vulns}

    def test_fix_in_osv_calls_the_llm_and_picks_the_version_by_rule(self):
        from unittest import mock

        from guardian.agents import suggest
        vulns = [{"id": "GHSA-1", "summary": "bad", "affected": [{"package": {"name": "foo"}, "ranges": [{"events": [{"fixed": "1.2.0"}, {"fixed": "2.0.0"}]}]}]}]
        with mock.patch.object(suggest, "explain", return_value={"summary": "upgrade", "label": "AI inference, not evidence"}) as ex, \
                mock.patch.object(suggest.llm, "agentic_ok", return_value=True), mock.patch.object(suggest.config, "load", return_value={"llm": {"provider": "openai", "model": "m"}}):
            r = suggest.report(self.finding(), None, mem(), request=self.osv(vulns))
        self.assertEqual((r["fix_found"], r["recommended"]["version"], r["recommended"]["bump"], r["recommended"]["sources"]), (True, "1.2.0", "minor", ["OSV"]))   # same major wins
        self.assertEqual(ex.call_count, 1)
        self.assertIsNone(r["workflow"])
        self.assertEqual(r["checked"]["trivy"]["state"] in ("not_run", "failed", "ran"), True)   # Trivy is reported, never silently skipped

    def test_no_fix_means_no_llm_call_and_an_agentic_workflow(self):
        from unittest import mock

        from guardian.agents import suggest
        vulns = [{"id": "GHSA-2", "summary": "bad", "affected": [{"package": {"name": "foo"}, "ranges": [{"events": [{"introduced": "0"}]}]}]}]
        with mock.patch.object(suggest, "explain", side_effect=AssertionError("the LLM must not be called without a sourced fix")):
            r = suggest.report(self.finding(), None, mem(), request=self.osv(vulns))
        self.assertEqual((r["fix_found"], r["recommended"], r["llm"]), (False, None, None))
        self.assertFalse(r["workflow"]["executed"])                                      # a plan, nothing has been run
        self.assertEqual([s["agent"] for s in r["workflow"]["steps"]][-1], "People")
        self.assertTrue(r["workflow"]["stop_conditions"])

    def test_osv_down_is_a_visible_state_not_a_clean_answer(self):
        from guardian.agents import suggest

        def boom(_):
            raise OSError("down")
        r = suggest.report(self.finding(), None, mem(), request=boom)
        self.assertEqual(r["checked"]["osv"]["state"], "failed")
        self.assertFalse(r["fix_found"])

    def test_non_vulnerability_findings_skip_osv_and_get_a_workflow(self):
        from guardian.agents import suggest
        r = suggest.report(self.finding(typ="typosquat"), None, mem(), request=lambda p: self.fail("OSV is only for known vulnerabilities"))
        self.assertEqual(r["checked"]["osv"]["state"], "not_applicable")
        self.assertTrue(r["workflow"])

    def test_llm_versions_not_in_the_sources_are_flagged(self):
        from unittest import mock

        from guardian.agents import suggest
        with mock.patch.object(suggest.llm, "chat", return_value=({"content": '{"summary": "use 9.9.9", "why": "fixed in 1.2.0"}'}, "m")):
            out = suggest.explain("Fixed versions published: 1.2.0", {"llm": {"provider": "openai", "model": "m"}})
        self.assertEqual(out["unverified_versions"], ["9.9.9"])

    def test_truncated_llm_json_is_recovered_field_by_field(self):
        from unittest import mock

        from guardian.agents import suggest
        with mock.patch.object(suggest.llm, "chat", return_value=({"content": '{"summary": "Upgrade to 1.2.0.", "why": "It fixes the advisory.", "risk": "medium", "risk_re'}, "m")):
            out = suggest.explain("Fixed versions published: 1.2.0", {"llm": {"provider": "openai", "model": "m"}})
        self.assertEqual((out["summary"], out["risk"]), ("Upgrade to 1.2.0.", "medium"))


class FixerKeepsTheFileIntact(unittest.TestCase):
    """The patch must show only the change: line endings, formatting and every other byte stay as they were."""

    def edit(self, raw: bytes, kind="override", name="jsonwebtoken", old="0.4.0", new="9.0.0"):
        from guardian.agents import fixer
        d = Path(tempfile.mkdtemp())
        (d / "package.json").write_bytes(raw)
        fixer.apply_edit({"kind": kind, "package": name, "from": old, "to": new, "file": "package.json"}, d)
        return (d / "package.json").read_bytes()

    def test_crlf_and_non_utf8_bytes_survive_and_only_the_change_differs(self):
        raw = b'{\r\n  "name": "x",\r\n  "author": "Bj\xf6rn",\r\n  "dependencies": {\r\n    "jsonwebtoken": "0.4.0",\r\n    "express": "^4"\r\n  }\r\n}\r\n'
        out = self.edit(raw)
        self.assertNotIn(b"\n", out.replace(b"\r\n", b""))                         # every line ending is still CRLF
        self.assertIn(b"Bj\xf6rn", out)                                            # the byte that is not UTF-8 is untouched
        expected = (b'{\r\n  "name": "x",\r\n  "author": "Bj\xf6rn",\r\n  "dependencies": {\r\n    "jsonwebtoken": "9.0.0",\r\n    "express": "^4"\r\n  },\r\n'
                    b'  "overrides": {\r\n    "jsonwebtoken": "$jsonwebtoken"\r\n  }\r\n}\r\n')
        self.assertEqual(out, expected)                                            # exact: the dependency value changed, one block was added, nothing else

    def test_existing_overrides_block_gets_the_entry_and_keeps_its_others(self):
        raw = b'{\n  "dependencies": {"qs": "1.0.0", "jsonwebtoken": "0.4.0"},\n  "overrides": {\n    "other": "1.0.0"\n  }\n}\n'
        data = json.loads(self.edit(raw))
        self.assertEqual(data["overrides"], {"jsonwebtoken": "$jsonwebtoken", "other": "1.0.0"})

    def test_empty_overrides_block_and_same_name_replaced(self):
        self.assertEqual(json.loads(self.edit(b'{\n  "dependencies": {"jsonwebtoken": "0.4.0"},\n  "overrides": {}\n}\n'))["overrides"], {"jsonwebtoken": "$jsonwebtoken"})
        self.assertEqual(json.loads(self.edit(b'{\n  "dependencies": {"jsonwebtoken": "0.4.0"},\n  "overrides": {\n    "jsonwebtoken": "0.1.0"\n  }\n}\n'))["overrides"], {"jsonwebtoken": "$jsonwebtoken"})

    def test_purely_transitive_package_gets_a_plain_override_and_requirements_pin_is_exact(self):
        out = self.edit(b'{\n  "dependencies": {"express": "^4"}\n}\n', name="qs", old="1.0.0", new="6.0.0")
        self.assertEqual(json.loads(out)["overrides"], {"qs": "6.0.0"})
        from guardian.agents import fixer
        d = Path(tempfile.mkdtemp())
        (d / "requirements.txt").write_bytes(b"flask==1.0\r\nrequests==2.19.0\r\n")
        fixer.apply_edit({"kind": "requirements-pin", "package": "requests", "from": "2.19.0", "to": "2.32.0", "file": "requirements.txt"}, d)
        self.assertEqual((d / "requirements.txt").read_bytes(), b"flask==1.0\r\nrequests==2.32.0\r\n")


class TyposquatReputation(unittest.TestCase):
    """A lookalike name is a candidate; the registry decides whether it is an established package."""

    def candidate(self, name="prompt"):
        return {"type": "typosquat", "component": f"npm:{name}@1.0.0", "title": f"'{name}' looks like a typosquat of 'prompts'", "base_severity": 9.0, "verified_evidence": [], "confidence": "high"}

    def fake(self, created, versions, weekly):
        def fetch(url):
            if "downloads" in url:
                return {"downloads": weekly}
            return {"time": {"created": created}, "versions": {str(i): {} for i in range(versions)}}
        return fetch

    def test_popular_package_is_dropped_not_reported(self):
        from guardian.agents import reputation
        fs = [self.candidate()]
        counts = reputation.apply(fs, mem(), self.fake("2013-01-01T00:00:00.000Z", 38, 815140))
        self.assertEqual((counts["dropped"], fs), (1, []))

    def test_young_thin_package_stays_critical(self):
        from datetime import datetime, timedelta, timezone

        from guardian.agents import reputation
        f = self.candidate("lodahs")
        recent = (datetime.now(timezone.utc) - timedelta(days=12)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        counts = reputation.apply([f], mem(), self.fake(recent, 2, 31))
        self.assertEqual((counts["kept"], f["base_severity"]), (1, 9.0))
        self.assertIn("12 days ago", " ".join(f["verified_evidence"]))

    def test_registry_failure_is_needs_validation_not_a_guess(self):
        from guardian.agents import reputation

        def down(_):
            raise OSError("offline")
        f = self.candidate()
        counts = reputation.apply([f], mem(), down)
        self.assertEqual((counts["unverified"], f["verdict"], f["base_severity"]), (1, "needs_validation", 9.0))
        from guardian.core import Finding
        new = Finding.from_legacy({**f, "id": "X", "fingerprint": "fp", "detector": "change-agent", "risk_level": "Critical", "score": 9.0})
        self.assertEqual((new.verdict, bool(new.missing_fact)), ("needs_validation", True))      # the detector's verdict survives the conversion

    def test_answers_are_cached_so_a_rescan_does_not_hit_the_registry(self):
        from guardian.agents import reputation
        m, calls = mem(), []

        def fetch(url):
            calls.append(url)
            return {"time": {"created": "2013-01-01T00:00:00.000Z"}, "versions": {str(i): {} for i in range(9)}, "downloads": 5}
        reputation.lookup("npm", "utile", m, fetch)
        n = len(calls)
        reputation.lookup("npm", "utile", m, fetch)
        self.assertEqual(len(calls), n)


class FixerOtherDependents(unittest.TestCase):
    def test_a_direct_bump_also_overrides_when_another_package_depends_on_it(self):
        from guardian.agents import fixer
        pk = lambda n, v: {"ecosystem": "npm", "name": n, "version": v, "lockfiles": ["package-lock.json"], "scope": "runtime"}   # noqa: E731
        inv = {"packages": {"npm:body-parser@1.18.3": pk("body-parser", "1.18.3"), "npm:express@4.16.4": pk("express", "4.16.4")},
               "graph": {"app:package-lock.json": ["npm:body-parser@1.18.3", "npm:express@4.16.4"], "npm:express@4.16.4": ["npm:body-parser@1.18.3"]},
               "roots": {"app:package-lock.json": ["npm:body-parser@1.18.3", "npm:express@4.16.4"]}}
        f = {"id": "CVE-X", "type": "known_vulnerability", "component": "npm:body-parser@1.18.3", "risk_level": "Critical", "score": 9.0, "fixed_versions": ["1.20.3"],
             "advisory_ids": ["GHSA-1"], "dependency_paths": [["app:package-lock.json", "npm:body-parser@1.18.3"]]}
        p = fixer.propose({"run_id": "r", "project": "p", "head_ref": "HEAD", "findings": [f]}, inv, "CVE-X")
        self.assertEqual((p["kind"], p["also_override"]), ("dependency-bump", True))        # express would keep a nested 1.18.3 otherwise
        alone = {**inv, "graph": {"app:package-lock.json": ["npm:body-parser@1.18.3"]}}
        self.assertFalse(fixer.propose({"run_id": "r", "project": "p", "head_ref": "HEAD", "findings": [f]}, alone, "CVE-X")["also_override"])
