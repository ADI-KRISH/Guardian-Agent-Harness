﻿"""The publisher: refuses unless a named person approved and pushing is switched on; pushes only guardian/* branches; never merges; never leaks the token."""
import subprocess
import tempfile
import unittest
from pathlib import Path

from guardian.agents import publisher
from guardian.memory import Memory
from guardian.tools import ToolResult, git, run

TOKEN = "ghp_SECRET1234567890"
ENV = {"GUARDIAN_ALLOW_PUSH": "1", "GUARDIAN_GITHUB_TOKEN": TOKEN}
BRANCH = "guardian/fix-abc"


def make_sandbox(remote="https://github.com/acme/app.git"):
    d = Path(tempfile.mkdtemp(prefix="pub-"))
    g = lambda *a: subprocess.run(["git", "-C", str(d), "-c", "user.name=t", "-c", "user.email=t@t.t", *a], check=True, capture_output=True)   # noqa: E731
    g("init", "-q", "-b", "main")
    (d / "package.json").write_text('{"a": 1}\n')
    g("add", "-A"); g("commit", "-qm", "base")
    sha = git.resolve(d, "HEAD")
    g("checkout", "-q", "-b", BRANCH)
    (d / "package.json").write_text('{"a": 2}\n')
    g("add", "-A"); g("commit", "-qm", "fix")
    if remote:
        g("remote", "add", "origin", remote)
    return d, sha


class Fake:
    """Stands in for git push and the GitHub API; every other git command is real."""
    def __init__(self, push_ok=True, can_push=True, pr_status=201, repo_status=200):
        self.pushes, self.calls, self.push_ok, self.can_push, self.pr_status, self.repo_status = [], [], push_ok, can_push, pr_status, repo_status

    def runner(self, name, args, **kw):
        if "push" in args:
            self.pushes.append(list(args))
            return ToolResult("git", [name, *args], 0 if self.push_ok else 1, "", "" if self.push_ok else f"fatal: auth failed for {TOKEN}", self.push_ok)
        return run(name, args, **kw)

    def http(self, method, url, tok, payload=None):
        self.calls.append((method, url, payload))
        if method == "GET" and url.endswith("/pulls?head=acme:" + BRANCH + "&state=open"):
            return 200, [{"html_url": "https://github.com/acme/app/pull/7", "number": 7}]
        if method == "GET":
            return self.repo_status, {"default_branch": "main", "permissions": {"push": self.can_push}}
        if self.pr_status == 201:
            return 201, {"html_url": "https://github.com/acme/app/pull/9", "number": 9}
        return self.pr_status, {"message": "A pull request already exists" if self.pr_status == 422 else f"boom {TOKEN}"}


class PublisherTests(unittest.TestCase):
    def go(self, fake=None, env=ENV, branch=BRANCH, actor="Asha", reason="reviewed the diff", remote="https://github.com/acme/app.git", **kw):
        fake = fake or Fake()
        d, sha = make_sandbox(remote)
        mem = Memory(Path(tempfile.mkdtemp()) / "m.db")
        res = publisher.publish(d, branch, "t", "b", actor, reason, base_sha=sha, mem=mem, run_id="r", project="p", env=env, http=fake.http, runner=fake.runner, **kw)
        return res, fake, mem

    def refused(self, msg_part, **kw):
        fake = kw.pop("fake", None) or Fake()
        with self.assertRaises(publisher.PublishError) as cm:
            self.go(fake=fake, **kw)
        self.assertIn(msg_part, str(cm.exception))
        self.assertEqual(fake.pushes, [], "nothing may be pushed on a refusal")
        return cm.exception

    def test_happy_path_pushes_only_the_branch_and_opens_a_pr(self):
        res, fake, mem = self.go()
        self.assertEqual((res["repo"], res["branch"], res["base"], res["number"], res["draft"]), ("acme/app", BRANCH, "main", 9, True))
        self.assertEqual(res["files"], ["package.json"])
        push = fake.pushes[0]
        self.assertIn(f"refs/heads/{BRANCH}:refs/heads/{BRANCH}", push)
        self.assertFalse(any("force" in a or a.startswith("+") for a in push))
        self.assertNotIn(TOKEN, " ".join(a for a in push if "extraheader" not in a))
        pr = next(p for m, u, p in fake.calls if m == "POST")
        self.assertEqual((pr["head"], pr["base"], pr["draft"]), (BRANCH, "main", True))
        log = " | ".join(f"{x['actor']}: {x['decision']}" for x in mem.decisions("r"))
        self.assertIn("human:Asha: approved pushing", log)
        self.assertNotIn(TOKEN, str(mem.decisions("r")))

    def test_switched_off_by_default(self):
        self.refused("switched off", env={"GUARDIAN_GITHUB_TOKEN": TOKEN})

    def test_needs_a_named_approver_and_a_reason(self):
        self.refused("named approver", actor="")
        self.refused("named approver", reason="  ")

    def test_needs_a_token(self):
        self.refused("No GitHub token", env={"GUARDIAN_ALLOW_PUSH": "1"})

    def test_only_guardian_branches(self):
        for b in ("main", "feature/x", "guardian/../main", "guardian/"):
            self.refused("Only guardian/", branch=b)

    def test_token_without_push_rights_is_refused_with_the_fork_hint(self):
        e = self.refused("cannot push", fake=Fake(can_push=False))
        self.assertIn("fork", str(e))

    def test_unknown_repository(self):
        self.refused("does not exist", fake=Fake(repo_status=404))

    def test_not_a_github_remote(self):
        self.refused("not a github.com", remote="https://user:pw@github.com/acme/app.git")
        self.refused("not a github.com", remote="https://gitlab.com/acme/app.git")

    def test_remote_override_for_a_fork(self):
        res, fake, _ = self.go(env={**ENV, "GUARDIAN_PUSH_REMOTE": "https://github.com/me/fork"})
        self.assertEqual(res["repo"], "me/fork")
        self.assertIn("https://github.com/me/fork.git", fake.pushes[0])

    def test_push_failure_never_shows_the_token(self):
        with self.assertRaises(publisher.PublishError) as cm:
            self.go(fake=Fake(push_ok=False))
        self.assertIn("push failed", str(cm.exception))
        self.assertNotIn(TOKEN, str(cm.exception))

    def test_existing_pull_request_is_returned_not_duplicated(self):
        res, _, _ = self.go(fake=Fake(pr_status=422))
        self.assertEqual((res["number"], res["pull_request"]), (7, "https://github.com/acme/app/pull/7"))

    def test_refused_pull_request_says_the_branch_was_pushed_and_hides_the_token(self):
        with self.assertRaises(publisher.PublishError) as cm:
            self.go(fake=Fake(pr_status=403))
        self.assertIn("was pushed", str(cm.exception))
        self.assertNotIn(TOKEN, str(cm.exception))

    def test_parse_remote(self):
        self.assertEqual(publisher.parse_remote("git@github.com:acme/app.git"), ("acme", "app"))
        self.assertEqual(publisher.parse_remote("https://github.com/acme/app"), ("acme", "app"))
        self.assertIsNone(publisher.parse_remote("https://evil.com/github.com/acme/app"))

    def test_workflow_body_is_honest_about_limits(self):
        rec = {"package": {"name": "marsdb", "version": "0.6.11"}, "strategy": "isolate",
               "steps": [{"agent": "Investigator", "output": {"advisory": {"id": "GHSA-1", "summary": "inj"}, "feature_hits": [{"file": "a.js", "line": 3, "text": "x"}]}},
                         {"agent": "Strategist", "ai": True, "output": {"reason": "reachable"}}]}
        body = publisher.workflow_body(rec, "Asha", "ok", "diff --git a b")
        for part in ("a.js:3", "mitigation, not a resolution", "NOT built or tested", "AI inference", "Asha", "diff --git"):
            self.assertIn(part, body)


if __name__ == "__main__":
    unittest.main()
