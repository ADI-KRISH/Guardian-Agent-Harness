"""Guardian API: one test per endpoint against the saved Juice Shop demo scan, plus the request-hardening checks."""
import http.client
import json
import threading
import unittest

from guardian.api.server import make_backend, serve


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.backend = make_backend(True)
        started = threading.Event()
        holder = {}

        def ready(server):
            holder["server"] = server
            started.set()
        cls.thread = threading.Thread(target=serve, args=(0, cls.backend, ready), daemon=True)
        cls.thread.start()
        assert started.wait(10)
        cls.server = holder["server"]
        cls.port = cls.server.server_address[1]
        cls.token = cls.server.guardian_token
        cls.sid = cls.backend.list_scans()[0]["id"]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def call(self, method, path, body=None, token=True, host=None, origin=None, raw=None):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=30)
        headers = {"Host": host or f"127.0.0.1:{self.port}"}
        if token:
            headers["X-Guardian-Token"] = self.token
        if origin:
            headers["Origin"] = origin
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        if data is not None:
            headers["Content-Type"] = "application/json"
        c.request(method, path, body=data, headers=headers)
        r = c.getresponse()
        payload = r.read()
        c.close()
        try:
            return r.status, json.loads(payload), r
        except ValueError:
            return r.status, payload, r

    # ---------------------------------------------------------------- hardening
    def test_session_token_and_security_headers(self):
        st, body, r = self.call("GET", "/session")
        self.assertEqual((st, body["token"] == self.token), (200, True))
        self.assertEqual(r.getheader("Cache-Control"), "no-store")
        self.assertEqual(r.getheader("X-Content-Type-Options"), "nosniff")
        self.assertIn("default-src 'none'", r.getheader("Content-Security-Policy"))

    def test_bad_host_is_rejected(self):
        self.assertEqual(self.call("GET", "/scans", host="evil.example:80")[0], 403)

    def test_write_needs_token_same_origin_and_small_json_object(self):
        good = {"scan_id": self.sid, "finding_id": "x", "status": "confirmed", "actor": "A", "reason": "r"}
        self.assertEqual(self.call("POST", "/review", good, token=False)[0], 403)
        self.assertEqual(self.call("POST", "/review", good, origin="http://evil.example")[0], 403)
        try:
            self.assertEqual(self.call("POST", "/review", raw=b"x" * 70000)[0], 400)       # 64 KB cap
        except ConnectionError:
            pass                                                                             # the server may drop the connection before the body is sent (Windows reports an abort)
        self.assertEqual(self.call("POST", "/review", raw=b"[1,2]")[0], 400)               # must be a JSON object

    # ---------------------------------------------------------------- reads, one per endpoint
    def test_scans_and_summary(self):
        self.assertEqual(self.call("GET", "/scans")[1][0]["id"], self.sid)
        st, s, _ = self.call("GET", f"/scans/{self.sid}/summary")
        self.assertEqual(st, 200)
        self.assertGreater(s["stats"]["components"], 1000)
        self.assertIn("needs_validation", s["severity"])
        self.assertTrue(s["selfcheck"] is not None and "gaps" in s)

    def test_inventory_component_sbom(self):
        inv = self.call("GET", f"/scans/{self.sid}/inventory")[1]
        self.assertGreater(len(inv["components"]), 1000)
        key = next(c["key"] for c in inv["components"] if c["direct"])
        st, comp, _ = self.call("GET", f"/scans/{self.sid}/components/{key.replace(':', '%3A').replace('@', '%40').replace('/', '%2F')}")
        self.assertEqual((st, comp["key"]), (200, key))
        for fmt, marker in (("cyclonedx", b"CycloneDX"), ("spdx", b"spdxVersion")):
            st, data, _ = self.call("GET", f"/scans/{self.sid}/sbom?format={fmt}")
            self.assertEqual(st, 200)
            self.assertIn(marker, json.dumps(data).encode() if not isinstance(data, bytes) else data)
        self.assertEqual(self.call("GET", f"/scans/{self.sid}/sbom?format=xml")[0], 400)

    def test_graph_views(self):
        risk = self.call("GET", f"/scans/{self.sid}/graph?view=risk")[1]
        kinds = {n["data"]["kind"] for n in risk["elements"]["nodes"]}
        self.assertTrue({"app", "package", "finding"} <= kinds)
        full = self.call("GET", f"/scans/{self.sid}/graph?view=full")[1]
        self.assertLessEqual(full["shown"], 301)
        self.assertIn("showing", full["note"])
        name = next(n["data"]["id"] for n in risk["elements"]["nodes"] if n["data"]["kind"] == "package")
        trace = self.call("GET", f"/scans/{self.sid}/graph?view=trace&node={name.replace(':', '%3A').replace('@', '%40').replace('/', '%2F')}")
        self.assertEqual(trace[0], 200)
        self.assertEqual(self.call("GET", f"/scans/{self.sid}/graph?view=trace")[0], 400)
        self.assertEqual(self.call("GET", f"/scans/{self.sid}/graph?view=nope")[0], 400)

    def test_changes_findings_detail(self):
        self.assertEqual(self.call("GET", f"/scans/{self.sid}/changes")[0], 200)
        fs = self.call("GET", f"/scans/{self.sid}/findings")[1]
        self.assertGreater(len(fs["findings"]), 100)
        high = self.call("GET", f"/scans/{self.sid}/findings?severity=high")[1]["findings"]
        self.assertTrue(high and all(f["severity"] == "high" for f in high))
        fp = fs["findings"][0]["fingerprint"]
        st, one, _ = self.call("GET", f"/scans/{self.sid}/findings/{fp}")
        self.assertEqual((st, one["fingerprint"]), (200, fp))
        self.assertIn("decision_trail", one)
        self.assertEqual(self.call("GET", f"/scans/{self.sid}/findings/{'0' * 64}")[0], 404)

    def test_honesty_rules_in_the_payload(self):
        for f in self.call("GET", f"/scans/{self.sid}/findings")[1]["findings"]:
            if f["verdict"] == "needs_validation":
                self.assertIsNone(f["severity_badge"])                 # no severity badge without validation
                self.assertEqual(f["badge"], "Needs validation")
            if f["severity"] == "unknown":
                self.assertEqual(f["severity_badge"], "Unknown")       # never Low
            if f.get("ai_investigation"):
                self.assertEqual(f["ai_investigation"]["label"], "AI inference, not evidence")
        text = json.dumps(self.call("GET", "/models/status")[1]).lower()
        self.assertNotIn("api_key", text)                              # keys and environment variables never leave the server

    def test_plans_audit_report_and_view(self):
        self.assertTrue(self.call("GET", f"/scans/{self.sid}/plans")[1]["plans"])
        self.assertIn("entries", self.call("GET", f"/scans/{self.sid}/audit")[1])
        for fmt in ("html", "md", "json", "sarif"):
            self.assertEqual(self.call("GET", f"/scans/{self.sid}/report?format={fmt}")[0], 200, fmt)
        view = self.call("GET", f"/scans/{self.sid}/report-view")[1]
        for section in ("summary", "sbom", "evidence_ledger", "changes", "fixes", "remaining", "limitations", "audit"):
            self.assertIn(section, view)
        self.assertIn("Absence of findings is not absence of a backdoor.", view["limitations"])

    def test_review_queue_evaluation_scoreboard_learning_models_jobs(self):
        q = self.call("GET", "/review-items")[1]
        self.assertGreater(q["count"], 0)
        self.assertEqual(set(q["gates"]), {"1", "2", "4", "5", "6", "7", "8", "9"})
        self.assertEqual(q["items"][0]["gate"] if any(i["gate"] == 9 for i in q["items"]) else 9, 9)       # gate 9 is pinned first
        self.assertTrue(all(i["gate"] == 2 for i in self.call("GET", "/review-items?gate=2")[1]["items"]))
        ev = self.call("GET", "/evaluation")[1]
        self.assertEqual((ev["passed"], ev["passing"] == ev["total"]), (True, True))
        self.assertIn("regression", self.call("GET", "/scoreboard")[1])
        self.assertIn("lessons", self.call("GET", "/learning")[1])
        self.assertIn("endpoints", self.call("GET", "/models/status")[1])
        self.assertEqual(self.call("GET", "/jobs/nope")[0], 404)
        self.assertEqual(self.call("GET", "/scans/..%2Fetc/summary")[0], 404)                               # no path traversal through ids

    # ---------------------------------------------------------------- writes
    def test_review_needs_name_and_reason_and_records_to_audit(self):
        f = next(x for x in self.call("GET", f"/scans/{self.sid}/findings?severity=medium")[1]["findings"] if x["type"] not in ("typosquat", "integrity_change", "backdoor_signal"))
        body = {"scan_id": self.sid, "finding_id": f["fingerprint"], "status": "confirmed", "actor": "", "reason": "x"}
        self.assertEqual(self.call("POST", "/review", body)[0], 400)
        body.update(actor="Ada Lovelace", reason="checked the lockfile")
        self.assertEqual(self.call("POST", "/review", body)[0], 200)
        shown = self.call("GET", f"/scans/{self.sid}/findings/{f['fingerprint']}")[1]
        self.assertEqual(shown["review"]["actor"], "Ada Lovelace")
        trail = self.call("GET", f"/scans/{self.sid}/audit")[1]["entries"]
        self.assertTrue(any("review" in e["decision"] and e["actor"].startswith("human:Ada") for e in trail))

    def test_accepting_a_risk_records_an_expiry(self):
        f = self.call("GET", f"/scans/{self.sid}/findings?severity=low")[1]["findings"][0]
        st, res, _ = self.call("POST", "/review", {"scan_id": self.sid, "finding_id": f["fingerprint"], "status": "accepted", "actor": "Bo", "reason": "internal tool", "days": 14})
        self.assertEqual(st, 200)
        self.assertTrue(res["expires"])

    def test_protected_false_positive_needs_a_detailed_reason(self):
        prot = next((x for x in self.call("GET", f"/scans/{self.sid}/findings")[1]["findings"] if x["type"] == "backdoor_signal"), None)
        if prot:
            st, _, _ = self.call("POST", "/review", {"scan_id": self.sid, "finding_id": prot["fingerprint"], "status": "false_positive", "actor": "Bo", "reason": "noise"})
            self.assertEqual(st, 400)

    def test_lessons_flow_proposed_then_evaluated_then_active(self):
        fs = self.call("GET", f"/scans/{self.sid}/findings")[1]["findings"]
        f = next(x for x in fs if x["rule"] not in ("exec-encoded",) and x["type"] in ("workflow_issue", "unpinned_action", "dockerfile_issue", "untrusted_image", "history_anomaly"))
        st, res, _ = self.call("POST", "/review", {"scan_id": self.sid, "finding_id": f["fingerprint"], "status": "false_positive", "actor": "Cy", "reason": "test fixture, not shipped"})
        self.assertEqual(st, 200)
        lessons = self.call("GET", "/learning")[1]["lessons"]
        proposed = [l for l in lessons["proposed"]]
        if res["lesson_proposed"]:
            self.assertTrue(proposed)
            lid = res["lesson_proposed"]
            st, out, _ = self.call("POST", f"/lessons/{lid}/decision", {"choice": "reject", "actor": "Cy", "reason": "decided against it"})
            self.assertEqual(st, 200)
        self.assertEqual(self.call("POST", "/lessons/999999/decision", {"choice": "approve", "actor": "", "reason": ""})[0], 400)

    def test_baseline_refuses_unreviewed_criticals(self):
        st, body, _ = self.call("POST", "/baseline", {"scan_id": self.sid, "actor": "Di", "reason": "looks fine"})
        crit = self.call("GET", f"/scans/{self.sid}/summary")[1]["severity"]["critical"]
        if crit:
            self.assertEqual(st, 400)
            self.assertIn("Critical", body["error"])

    def test_plan_validation_needs_approval_first(self):
        plan = next(p for p in self.call("GET", f"/scans/{self.sid}/plans")[1]["plans"] if p["automatic"])
        st, body, _ = self.call("POST", f"/plans/{plan['finding_id']}/validate", {"scan_id": self.sid})
        self.assertEqual(st, 409)                                       # gate 5 first: no build before a named human approves
        self.assertEqual(self.call("POST", f"/plans/{plan['finding_id']}/approve", {"scan_id": self.sid, "actor": "", "reason": ""})[0] in (400, 409), True)

    def test_scan_cannot_start_in_demo_mode_and_unknown_route_is_404(self):
        self.assertEqual(self.call("POST", "/scans", {"source": "https://github.com/juice-shop/juice-shop"})[0], 409)
        self.assertEqual(self.call("GET", "/nothing")[0], 404)


if __name__ == "__main__":
    unittest.main()
