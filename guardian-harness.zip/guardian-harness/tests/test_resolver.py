"""Lockfile resolution on Windows, exact pins without a lockfile, and honest vulnerability coverage (DVNA regression)."""
import json
import os
import shutil
import socket
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from guardian.agents import discovery, vuln
from guardian.memory import Memory

DVNA = Path(__file__).parent / "fixtures" / "dvna" / "package.json"


def mem() -> Memory:
    return Memory(Path(tempfile.mkdtemp()) / "g.db")


def dvna_tree() -> Path:
    d = Path(tempfile.mkdtemp())
    shutil.copy(DVNA, d / "package.json")
    return d


def online() -> bool:
    try:
        for host in ("registry.npmjs.org", "api.osv.dev"):
            socket.create_connection((host, 443), timeout=5).close()
        return bool(shutil.which("node"))
    except OSError:
        return False


class ResolverEnvironment(unittest.TestCase):
    def test_environment_is_an_allowlist_inside_the_temp_folder(self):
        tmp = Path(tempfile.mkdtemp())
        with mock.patch.dict(os.environ, {"GITHUB_TOKEN": "x", "NPM_TOKEN": "y", "AWS_SECRET_ACCESS_KEY": "z"}):
            env = discovery.resolver_env(tmp, r"C:\nodejs" if os.name == "nt" else "/opt/node/bin")
        self.assertFalse({"GITHUB_TOKEN", "NPM_TOKEN", "AWS_SECRET_ACCESS_KEY"} & set(env))
        self.assertEqual(env["GIT_CONFIG_GLOBAL"], os.devnull)
        self.assertEqual(env["npm_config_ignore_scripts"], "true")
        if os.name == "nt":
            for k in ("APPDATA", "LOCALAPPDATA", "USERPROFILE", "TEMP", "TMP"):
                self.assertEqual(env[k], str(tmp), k)
            self.assertIn("SystemRoot", env)
            self.assertTrue(env["PATH"].startswith(r"C:\nodejs"))
            self.assertFalse(any("/usr" in v or "/dev/null" in v for v in env.values()))
            self.assertEqual(os.devnull.lower(), "nul")

    @unittest.skipUnless(shutil.which("node"), "node not installed")
    def test_npm_command_runs_without_a_shell(self):
        cmd = discovery.npm_command()
        if os.name == "nt":
            self.assertTrue(cmd[0].lower().endswith("node.exe") and cmd[1].endswith("npm-cli.js"), cmd)
        r = subprocess.run([*cmd, "--version"], capture_output=True, text=True, timeout=60, shell=False,
                           env=discovery.resolver_env(Path(tempfile.mkdtemp()), str(Path(cmd[0]).parent)))
        self.assertEqual(r.returncode, 0, r.stderr)


class ExactPins(unittest.TestCase):
    def test_without_a_lockfile_exact_pins_are_components_and_ranges_are_not_checked(self):
        s = discovery.snapshot(dvna_tree(), run_syft=False, generate_locks=False)
        self.assertIn("npm:mathjs@3.10.1", s["packages"])
        self.assertIn("npm:node-serialize@0.0.4", s["packages"])
        self.assertTrue(s["packages"]["npm:mathjs@3.10.1"]["exact_pin"])
        self.assertIn({"component": "npm:libxmljs@^0.19.1", "reason": "not checked: range"}, s["unchecked"])

    def test_pins_failed_resolution_and_ranges_make_the_check_incomplete_not_clean(self):
        d = dvna_tree()
        with mock.patch.object(discovery, "_resolve_lock", side_effect=ValueError("npm failed: ENOTFOUND")):
            s = discovery.snapshot(d, run_syft=False)
        self.assertEqual(s["resolution"][0]["status"], "failed")
        asked = []

        def fake(payload):
            asked.append(payload["package"]["name"])
            return {"vulns": [{"id": "GHSA-x", "summary": "bad", "aliases": ["CVE-1"]}]} if payload["package"]["name"] == "mathjs" else {}
        with mock.patch.object(vuln, "scan", return_value=([], {"rc": 0})):
            fs, cov = vuln.scan_all(d, s, None, mem(), request=fake)
        self.assertEqual(sorted(asked), ["express-flash", "mathjs", "node-serialize"])                  # only exact pins are queried
        self.assertEqual([f["component"] for f in fs], ["npm:mathjs@3.10.1"])
        self.assertFalse(cov["complete"])
        self.assertLess(cov["checked"], cov["total"])
        self.assertIn("lockfile resolution failed for . (npm failed: ENOTFOUND)", cov["reason"])
        self.assertIn("not checked: range", cov["reason"])

    def test_scanner_that_did_not_run_is_a_gap_not_zero_findings(self):
        d = tempfile.mkdtemp()
        head = {"packages": {"npm:a@1.0.0": {"ecosystem": "npm", "name": "a", "version": "1.0.0", "lockfiles": ["package-lock.json"]}},
                "graph": {}, "roots": {}}
        with mock.patch.object(vuln, "scan", return_value=([], {"rc": 128, "stderr_tail": "no package sources found"})):
            _, cov = vuln.scan_all(Path(d), head, None, mem(), request=lambda p: {})
        self.assertTrue(cov["complete"])                                               # API answered every component
        with mock.patch.object(vuln, "scan", return_value=([], {"rc": 128, "stderr_tail": "x"})):
            _, cov = vuln.scan_all(Path(d), head, None, mem(), offline=True, request=lambda p: self.fail("offline"))
        self.assertFalse(cov["complete"])
        self.assertIn("offline mode", cov["reason"])

    def test_m4_with_a_coverage_gap_is_partial_not_ok(self):
        from guardian.core import RunContext, run_all
        from guardian.modules.detectors import Vulnerabilities
        ctx = RunContext(repo_path=Path("."), out_dir=Path(tempfile.mkdtemp()), project="p", run_id="r", memory=mem(),
                         snapshot_head={"packages": {}, "graph": {}, "roots": {}}, snapshot_base=None)
        gap = {"complete": False, "checked": 1, "total": 2, "percent": 50, "reason": "1 component(s) not checked: range", "not_checked": []}
        with mock.patch.object(vuln, "scan_all", return_value=([], gap)):
            m = Vulnerabilities()
            m.needs = []
            status = run_all([m], ctx)
        self.assertTrue(status["M4.vuln"].startswith("partial"), status)

    def test_full_coverage_is_complete(self):
        head = {"packages": {"npm:a@1.0.0": {"ecosystem": "npm", "name": "a", "version": "1.0.0", "lockfiles": ["package-lock.json"]}}, "graph": {}, "roots": {}}
        with mock.patch.object(vuln, "scan", return_value=([], {"rc": 0})):
            _, cov = vuln.scan_all(Path("."), head, None, mem())
        self.assertEqual((cov["complete"], cov["percent"], cov["reason"]), (True, 100, ""))


@unittest.skipUnless(online(), "needs node, registry.npmjs.org and api.osv.dev")
class DvnaRegression(unittest.TestCase):
    def test_dvna_manifest_yields_lockfile_and_the_known_advisories(self):
        d = dvna_tree()
        head = discovery.snapshot(d, run_syft=False)
        self.assertEqual(head["resolution"][0]["status"], "resolved", head["resolution"])
        self.assertTrue((d / "package-lock.json").exists())
        fs, cov = vuln.scan_all(d, head, None, mem())
        names = {f["component"].split("@")[0] for f in fs}
        for pkg in ("npm:mathjs", "npm:node-serialize", "npm:libxmljs"):
            self.assertIn(pkg, names)
        self.assertTrue(cov["complete"], cov["reason"])
        self.assertGreaterEqual(len([f for f in fs if f["base_severity"] >= 9]), 10)


if __name__ == "__main__":
    unittest.main()
