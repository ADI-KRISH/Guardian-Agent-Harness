"""The no-fix agentic workflow: real steps, strict limits on what the AI may touch, stop conditions, honest records."""
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from guardian.agents import nofix
from guardian.memory import Memory
from guardian.tools import git

ADVISORY = {"id": "GHSA-5mrr", "summary": "Command Injection in marsdb",
            "details": "In the `DocumentMatcher` class, selectors on `$where` clauses are passed to a Function constructor unsanitized."}
VULN_LINE = "  db.reviews.find({ $where: 'this.product == ' + id }).then(show)"


def make_repo(extra: dict | None = None, vulnerable=True) -> tuple[Path, str]:
    d = Path(tempfile.mkdtemp(prefix="nofix-"))
    files = {"data/db.js": "const MarsDB = require('marsdb')\nexports.reviews = new MarsDB.Collection('posts')\n",
             "routes/show.js": "module.exports = (db, id) => {\n" + (VULN_LINE if vulnerable else "  db.reviews.find({ product: id }).then(show)") + "\n}\n"}
    files.update(extra or {})
    for rel, text in files.items():
        (d / rel).parent.mkdir(parents=True, exist_ok=True)
        (d / rel).write_text(text, encoding="utf-8")
    run = lambda *a: subprocess.run(["git", "-C", str(d), "-c", "user.name=t", "-c", "user.email=t@t.t", *a], check=True, capture_output=True)   # noqa: E731
    run("init", "-q")
    run("add", "-A")
    run("commit", "-qm", "c")
    return d, git.resolve(d, "HEAD")


def finding():
    return {"fingerprint": "f" * 64, "legacy_id": "GHSA-5mrr", "component_key": "npm:marsdb@0.6.11", "package": {"ecosystem": "npm", "name": "marsdb", "version": "0.6.11"}}


def search(*objs):
    return lambda url: {"objects": [{"package": {"name": n, "version": v, "date": "2026-01-01T00:00:00Z", "description": "d"}} for n, v in objs]}


def chat_script(*answers):
    it = iter(answers)

    def chat(system, user):
        a = next(it)
        if isinstance(a, Exception):
            raise a
        return a if isinstance(a, str) else json.dumps(a)
    return chat


GOOD_STRATEGY = {"strategy": "isolate", "reason": "the feature is reachable", "risk": "queries change"}
GOOD_EDIT = {"edits": [{"file": "routes/show.js", "line": 2, "old": VULN_LINE.strip(), "new": "db.reviews.find({ product: Number(id) }).then(show)"}]}


def go(repo, sha, chat, fetch=None, osv=None, **kw):
    sandbox = Path(tempfile.mkdtemp(prefix="nofix-sb-"))
    return nofix.run(finding(), repo, repo, sha, ADVISORY, Memory(Path(tempfile.mkdtemp()) / "m.db"), "run1", "p", fetch=fetch or search(("alt-db", "1.0.0")), chat=chat,
                     sandbox_root=sandbox, osv=osv or (lambda eco, name, ver, mem: ([], "live")), **kw)


class Investigator(unittest.TestCase):
    def test_feature_tokens_come_from_the_advisory_in_backticks(self):
        self.assertEqual(nofix.feature_tokens(ADVISORY["details"], "marsdb"), ["DocumentMatcher", "$where"])
        self.assertEqual(nofix.feature_tokens("`marsdb` is bad", "marsdb"), [])            # the package's own name is not a feature

    def test_sites_cite_file_and_line(self):
        d, _ = make_repo()
        imports, hits = nofix.find_sites(d, "npm", "marsdb", ["$where"])
        self.assertEqual([(i["file"], i["line"]) for i in imports], [("data/db.js", 1)])
        self.assertEqual([(h["file"], h["line"]) for h in hits], [("routes/show.js", 2)])


class Workflow(unittest.TestCase):
    def test_happy_path_drafts_one_line_patch_and_verifies_it(self):
        d, sha = make_repo()
        rec = go(d, sha, chat_script(GOOD_STRATEGY, GOOD_EDIT))
        self.assertEqual((rec["outcome"], rec["strategy"], rec["executed"]), ("patch-drafted", "isolate", True))
        self.assertEqual([(s["agent"], s["ai"]) for s in rec["steps"]], [("Investigator", False), ("Alternatives scout", False), ("Strategist", True), ("Patch author", True), ("Verifier", False), ("Human gates", False)])
        changed = [l for l in rec["patch"].splitlines() if l[:1] in "+-" and l[:3] not in ("+++", "---")]
        self.assertEqual(len(changed), 2)                                                  # one line out, one line in: nothing else
        self.assertNotIn("$where", "\n".join(l for l in changed if l.startswith("+")))
        self.assertEqual(rec["steps"][4]["status"], "done")
        self.assertTrue(any("Gate 7" in g for g in rec["human_gates"]))                    # gates are written down, never taken
        self.assertIn("not runtime-validated", rec["recommendation"])

    def test_unused_package_stops_early_without_asking_the_model(self):
        d, sha = make_repo(vulnerable=False)
        (d / "data" / "db.js").write_text("// nothing imports the package\n", encoding="utf-8")
        rec = go(d, sha, chat_script(RuntimeError("the model must not be called for an unused package")))
        self.assertEqual(rec["outcome"], "unused")
        self.assertIn("remove", rec["recommendation"])

    def test_an_edit_outside_the_lines_the_investigator_found_is_refused_twice_then_the_run_stops(self):
        d, sha = make_repo()
        bad = {"edits": [{"file": "data/db.js", "line": 1, "old": "const MarsDB = require('marsdb')", "new": "const MarsDB = {}"}]}
        rec = go(d, sha, chat_script(GOOD_STRATEGY, bad, bad))
        self.assertEqual(rec["outcome"], "stopped")
        self.assertIn("failed twice", rec["stop_reason"])
        self.assertNotIn("Verifier", [s["agent"] for s in rec["steps"]])                   # nothing was applied

    def test_an_edit_whose_old_text_is_not_the_real_line_is_refused(self):
        d, sha = make_repo()
        lie = {"edits": [{"file": "routes/show.js", "line": 2, "old": "something else entirely", "new": "x"}]}
        self.assertEqual(go(d, sha, chat_script(GOOD_STRATEGY, lie, lie))["outcome"], "stopped")

    def test_the_verifier_rejects_a_draft_that_keeps_the_vulnerable_feature(self):
        d, sha = make_repo()
        keeps = {"edits": [{"file": "routes/show.js", "line": 2, "old": VULN_LINE.strip(), "new": "db.reviews.find({ $where: 'this.product == 1' }).then(show)"}]}
        rec = go(d, sha, chat_script(GOOD_STRATEGY, keeps))
        self.assertEqual(rec["outcome"], "stopped")
        self.assertEqual(rec["steps"][-1]["status"], "rejected")

    def test_without_a_model_a_fixed_rule_picks_the_strategy_and_the_run_says_so(self):
        d, sha = make_repo()
        rec = go(d, sha, chat_script(*[RuntimeError("no AI model is configured")] * 4))
        strat = next(s for s in rec["steps"] if s["agent"] == "Strategist")
        self.assertEqual((strat["ai"], strat["output"]["strategy"]), (False, "isolate"))
        self.assertIn("fixed rule", strat["output"]["reason"])
        self.assertEqual(rec["outcome"], "stopped")                                        # the patch author needs a model; it says so rather than guessing

    def test_replace_strategy_hands_candidates_to_a_person(self):
        d, sha = make_repo()
        rec = go(d, sha, chat_script({"strategy": "replace", "reason": "maintained alternative", "risk": "API differs"}))
        self.assertEqual(rec["outcome"], "replacement-candidates")
        self.assertIn("alt-db", rec["recommendation"])
        self.assertEqual(next(s for s in rec["steps"] if s["agent"] == "Patch author")["status"], "skipped")

    def test_candidates_with_their_own_advisory_are_dropped(self):
        d, sha = make_repo()
        osv = lambda eco, name, ver, mem: ([{"id": "GHSA-bad"}] if name == "risky-db" else [], "live")      # noqa: E731
        sc = nofix.scout("npm", "marsdb", None, search(("risky-db", "2.0.0"), ("safe-db", "3.0.0")), osv)
        self.assertEqual([c["name"] for c in sc["candidates"]], ["safe-db"])
        self.assertIn("risky-db", sc["dropped"][0]["name"])
        self.assertEqual(nofix.scout("PyPI", "x", None)["state"], "not_run")               # honest about what is not implemented

    def test_every_step_is_written_to_the_audit_log(self):
        d, sha = make_repo()
        mem = Memory(Path(tempfile.mkdtemp()) / "a.db")
        nofix.run(finding(), d, d, sha, ADVISORY, mem, "run1", "p", fetch=search(("alt-db", "1.0.0")), chat=chat_script(GOOD_STRATEGY, GOOD_EDIT),
                  sandbox_root=Path(tempfile.mkdtemp(prefix="nofix-sb-")), osv=lambda *a: ([], "live"))
        actors = [e["actor"] for e in mem.decisions("run1")]
        for a in ("nofix:Investigator", "nofix:Strategist", "nofix:Patch author", "nofix:Verifier"):
            self.assertIn(a, actors)


if __name__ == "__main__":
    unittest.main()


class TokenBudget(unittest.TestCase):
    def test_a_caller_can_raise_the_token_budget_per_call(self):
        from unittest import mock

        from guardian.agents import llm
        seen = {}

        def fake_post(cfg, body, timeout, **kw):
            seen["n"] = body["max_completion_tokens"]
            return {"choices": [{"message": {"role": "assistant", "content": "{}"}}], "model": "m"}, "m", 1
        cfg = {"llm": {"provider": "openai", "model": "m", "base_url": "http://x", "max_tokens": 8000}}
        with mock.patch.object(llm, "post_openai", fake_post):
            llm.chat(cfg, [{"role": "user", "content": "x"}], None)
        self.assertEqual(seen["n"], 8000)


class ScoutSearchesByPurpose(unittest.TestCase):
    def test_search_is_by_keywords_and_add_ons_of_the_package_are_excluded(self):
        urls = []

        def fetch(url):
            urls.append(url)
            if url.endswith("/latest"):
                return {"keywords": ["mongo", "in-memory", "database"], "description": "a Mongo-like database"}
            return {"objects": [{"package": {"name": "marsdb-angular", "version": "1.0.0", "date": "2026-01-01T00:00:00Z", "description": "marsdb bindings"}},
                                {"package": {"name": "lokijs", "version": "1.5.12", "date": "2026-01-01T00:00:00Z", "description": "in-memory db"}},
                                {"package": {"name": "mingo", "version": "6.0.0", "date": "2026-01-01T00:00:00Z", "description": "marsdb-compatible queries"}}]}
        sc = nofix.scout("npm", "marsdb", None, fetch, lambda *a: ([], "live"))
        self.assertIn("mongo%20in-memory%20database", urls[1])                              # searched by purpose, not by the name "marsdb"
        self.assertEqual([c["name"] for c in sc["candidates"]], ["lokijs"])
        self.assertEqual(sorted(d["name"] for d in sc["dropped"]), ["marsdb-angular", "mingo"])
